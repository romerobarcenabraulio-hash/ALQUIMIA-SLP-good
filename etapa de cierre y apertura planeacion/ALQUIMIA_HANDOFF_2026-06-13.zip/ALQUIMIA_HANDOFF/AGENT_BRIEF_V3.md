# AGENT BRIEF V3 · Modo dual del sistema · Adaptación a iniciativas existentes y circularidad integral municipal

**Fecha:** 30 mayo 2026
**Para:** Agente que ya leyó V1 (arquitectura y operación) y V2 (función general y motor de digestión)
**Propósito:** documentar la capacidad de modo dual del sistema y la expansión de RSU a circularidad integral municipal con adendos cruzados a múltiples reglamentos
**Estado:** este insight se cristalizó en el último turno de la sesión de planeación. Es expansión major del producto que NO está construido todavía. Es hoja de ruta de mediano plazo, no scope del MVP inicial.

---

## Por qué existe este V3

Durante la sesión de planeación con el founder se cristalizó tardíamente una capacidad crítica del producto que NO estaba documentada en V1 ni V2: el sistema debe poder operar en dos modos según el contexto del cliente municipal.

**Modo A · Diagnóstico desde cero.** El cliente no tiene iniciativa publicada vigente. Alquimia arma diagnóstico → propuesta → plan desde cero usando los 10 módulos M00-M15 documentados en V1 y V2. Este es el modo del MVP inicial.

**Modo B · Adaptación a iniciativa existente.** El cliente tiene iniciativa publicada vigente (decreto estatal, ley estatal, programa federal). Alquimia digiere esa iniciativa y se vuelve mecanismo de consultoría para implementación local. NO genera diagnóstico desde cero; adapta su lógica a las obligaciones derivadas de la iniciativa existente.

El caso disparador fue: hoy se publicó en Periódico Oficial de Nuevo León un documento (no compartido todavía con el sistema por límite de sesión) que ejemplifica este patrón. Basándose en documentos de este tipo, el sistema podría mapear la circularidad general de un municipio usando base de datos de empresas y actividades existentes, hacer tracking general, y crear propuestas escalonadas donde el municipio decide qué fracciones implementar.

Este V3 documenta la arquitectura del modo dual y los componentes técnicos requeridos.

---

## SECCIÓN 1 · Modo A vs Modo B · Distinción operativa

| Aspecto | Modo A · Diagnóstico desde cero | Modo B · Adaptación a iniciativa |
|---|---|---|
| Punto de partida | Sin iniciativa estatal/federal vigente | Con iniciativa publicada que el municipio debe implementar |
| Pregunta central | ¿Cómo construye este municipio circularidad? | ¿Cómo implementa este municipio la iniciativa X? |
| Módulo M00B | Antecedentes generales del municipio | Antecedentes + análisis de iniciativa aplicable |
| Módulo M01 | Diagnóstico RSU base | Mapeo de circularidad según fracciones de la iniciativa |
| Módulo M03 | Marco normativo aplicable general | Marco normativo de la iniciativa + obligaciones derivadas |
| Módulo M03B | Reforma reglamentaria propuesta libre | Adendos cruzados a reglamentos afectados por la iniciativa |
| Módulo M13 | Escenarios financieros del programa propio | Escenarios financieros del plan de implementación |
| Módulo M15 | Borrador de expediente Cabildo | Plan de implementación con cronograma de cumplimiento |

**Activación del modo:** durante el onboarding de un tenant, el founder decide en Plataforma 0 si activa Modo A o Modo B. Si elige Modo B, debe subir el documento de la iniciativa publicada como primer paso. ARCHIVO digiere la iniciativa y configura el resto del flujo.

**Coexistencia de modos:** un tenant puede operar en Modo A para algunas fracciones y Modo B para otras. Ejemplo: si la iniciativa estatal solo cubre RSU pero el municipio quiere ampliar a RCD, RSU es Modo B y RCD es Modo A.

---

## SECCIÓN 2 · Mapa de circularidad municipal

El sistema construye y mantiene un mapa de circularidad por tenant que combina datos de empresas, actividades económicas y flujos materiales.

**Inputs del mapa:**

1. **DENUE (INEGI Directorio Estadístico Nacional de Unidades Económicas).** Semilla base con todas las unidades económicas registradas en el municipio, su giro, tamaño, ubicación georreferenciada.

2. **Censos Económicos INEGI.** Datos quinquenales con producción, consumo de insumos, generación de residuos por sector.

3. **Padrones municipales.** Padrón de licencias de funcionamiento, padrón de proveedores, padrón de generadores de residuos especiales si existe.

4. **Registros estatales.** Padrón estatal de empresas en SEMARNAT, registro de generadores de residuos peligrosos.

5. **Documentos aportados por el cliente.** Concesiones, convenios con cámaras empresariales, estudios sectoriales locales.

**Estructura del mapa:**

```typescript
interface CircularityMap {
  id: string
  tenant_id: string
  
  // Universo de actores
  economic_units: EconomicUnit[]      // empresas y unidades económicas
  sectors: SectorActivity[]            // sectores agregados con sus flujos
  generators: WasteGenerator[]         // generadores identificados
  collectors: WasteCollector[]         // recolectores formales
  processors: WasteProcessor[]         // procesadores y recicladoras
  buyers: AnchorBuyer[]                // compradores anchor de materiales
  
  // Flujos materiales
  material_flows: MaterialFlow[]       // origen → destino con tonelajes y materiales
  
  // Brechas identificadas
  gaps: CircularityGap[]              // dónde se rompe la circularidad y qué falta
  
  // Metadata
  last_updated_at: Date
  data_completeness_pct: number       // qué porcentaje del mapa está poblado
  evidence_levels: Record<string, 'A' | 'B' | 'C' | 'D'>  // por componente
}

interface EconomicUnit {
  id: string
  denue_id?: string                    // referencia DENUE si existe
  name: string
  scian_code: string                   // código SCIAN INEGI
  size_class: 'micro' | 'pequena' | 'mediana' | 'grande'
  location: GeoPoint
  estimated_waste_generation: {
    rsu_kg_day?: number
    rcd_kg_day?: number
    industrial_kg_day?: number
    evidence_level: 'A' | 'B' | 'C' | 'D'
  }
  data_category: DataCategory  // de la jerarquía de 7+1
}

interface MaterialFlow {
  id: string
  from_actor_id: string
  to_actor_id: string
  material: string                     // ej: "PET", "cartón", "RCD inerte"
  volume_tons_per_year: number
  evidence_level: 'A' | 'B' | 'C' | 'D'
  formality: 'formal' | 'informal' | 'mixed'
}
```

**Mantenimiento del mapa:**

El mapa NO es estático. Es output del motor de digestión continua. Cada vez que llega documento nuevo del tenant (padrón actualizado, censo nuevo, estudio sectorial), el motor identifica claims que enriquecen el mapa y los integra.

**Visualización para el cliente:**

Vista de red dirigida con nodos (actores) y aristas (flujos materiales). Filtros por sector, por tamaño de generador, por material. Brechas visualizadas con marca específica de qué falta para cerrarlas.

**Visualización para el founder:**

Dashboard cross-tenant que muestra patrones comunes entre municipios comparables. Esto alimenta NOUS para aprendizaje generalizable sin compartir data específica.

---

## SECCIÓN 3 · Sistema de fracciones modulares

El sistema soporta múltiples fracciones de circularidad, no solo RSU. Cada fracción tiene su set de módulos especializado y sus adendos reglamentarios propios.

**Fracciones que el sistema soporta (catálogo):**

| ID | Fracción | Reglamento principal afectado | Estado en MVP |
|---|---|---|---|
| RSU | Residuos sólidos urbanos | Reglamento de Limpia o Aseo Público | ✅ MVP |
| RCD | Residuos de construcción y demolición | Reglamento de Construcción | ⏳ Sprint 12+ |
| ENV | Envases y empaques | Reglamento de Comercio | ⏳ Sprint 14+ |
| RC | Residuos comerciales | Reglamento de Comercio + Mercados | ⏳ Sprint 14+ |
| RI | Residuos industriales especiales | Reglamento de Industria + estatal SEMARNAT | ⏳ Sprint 16+ |
| AGUA | Aguas residuales y reúso | Reglamento de Servicios de Agua | ⏳ Mes 12+ |
| ENE | Eficiencia energética municipal | Reglamento de Construcción + tarifas | ⏳ Mes 18+ |

**Configuración por tenant:**

```typescript
interface TenantConfiguration {
  tenant_id: string
  active_fractions: FractionId[]       // qué fracciones tiene activas
  fraction_modes: Record<FractionId, 'A' | 'B'>  // modo por fracción
  fraction_initiatives: Record<FractionId, MunicipalInitiative[]>  // iniciativas aplicables
}
```

**Implicación para los módulos:**

Los módulos M00B a M15 que tenemos especificados para RSU son template. Cada fracción tiene su variante de módulos. M01-RSU es distinto a M01-RCD aunque comparten estructura. El sistema renderiza la variante correspondiente según la fracción activa.

**Implicación para la navegación:**

El sidebar del cliente muestra árbol con fracciones activas como ramas. Click en una rama despliega los módulos de esa fracción. Esto reemplaza la lista plana actual de 10 módulos.

```
Validación
├── RSU (fracción activa)
│   ├── M00 Cómo leer
│   ├── M00B Antecedentes
│   ├── M01 Diagnóstico RSU
│   ├── ...
│   └── M15 Borrador expediente RSU
└── RCD (fracción activa)
    ├── M00 Cómo leer (compartido)
    ├── M00B Antecedentes (compartido)
    ├── M01 Diagnóstico RCD (específico)
    ├── ...
    └── M15 Borrador expediente RCD
```

Algunos módulos son compartidos entre fracciones (M00B antecedentes generales del municipio se llena una vez). Otros son específicos por fracción.

---

## SECCIÓN 4 · Adendos cruzados a múltiples reglamentos

Cuando el sistema opera con múltiples fracciones activas, debe generar adendos cruzados que toquen diferentes reglamentos municipales.

**Ejemplo concreto:**

Un municipio activa fracción RSU + fracción RCD + fracción ENV. El sistema identifica que la implementación coherente requiere modificar:

- Reglamento de Limpia (RSU): separación en origen, sanciones, incentivos
- Reglamento de Construcción (RCD): obligación de plan de manejo de RCD por proyecto, registro de transportistas autorizados, sitios de disposición específicos
- Reglamento de Comercio (ENV): obligación de retornables en comercios grandes, sistema de depósito-reembolso para envases
- Reglamento de Mercados (RC): separación en mercados públicos, gestión de orgánicos en centrales de abasto
- Reglamento de Servicios Públicos (general): coordinación interinstitucional del programa de circularidad

**Schema de adendos cruzados:**

```typescript
interface CrossRegulationAmendment {
  id: string
  tenant_id: string
  
  // El paquete normativo completo
  package_name: string                 // ej: "Paquete de Circularidad Municipal 2026"
  affected_regulations: RegulationAmendment[]
  
  // Justificación integrada
  rationale: string
  applicable_fractions: FractionId[]   // qué fracciones se cubren
  expected_outcomes: ExpectedOutcome[]
  
  // Trazabilidad
  derived_from_initiative_id?: string  // si Modo B, qué iniciativa lo origina
  
  // Estado
  status: 'draft' | 'reviewed_by_founder' | 'ready_for_cabildo' | 'approved' | 'published'
}

interface RegulationAmendment {
  regulation_name: string              // ej: "Reglamento de Construcción de [Municipio]"
  regulation_evidence_level: 'A' | 'B' | 'C' | 'D'  // qué tan bien tenemos el reglamento vigente
  current_version_uploaded: boolean    // ¿el cliente subió el reglamento vigente?
  
  // Análisis de brechas
  gaps_identified: RegulationGap[]
  
  // Adendos propuestos
  proposed_articles: ProposedArticle[]
  
  // Justificación específica
  technical_justification: string
  legal_precedents: string[]           // precedentes en otros municipios
  financial_implications: FinancialImplication[]
}

interface ProposedArticle {
  article_number: string
  text: string                         // texto exacto propuesto
  amendment_type: 'addition' | 'modification' | 'deletion'
  related_article_in_current?: string  // si modifica algo existente
  
  // Trazabilidad de la justificación
  derived_from_claims: string[]       // IDs de claims del Evidence Registry
  citations: Citation[]                // referencias verificables
}
```

**Generación automática del paquete:**

Cuando el cliente tiene varias fracciones activas y completa los módulos correspondientes, el sistema genera el paquete cruzado automáticamente con todas las modificaciones reglamentarias coordinadas. AUDITOR verifica que no haya contradicciones entre los adendos a distintos reglamentos antes de marcarlo como `ready_for_cabildo`.

---

## SECCIÓN 5 · Modo B en detalle · Digestión de iniciativa publicada

Cuando un tenant activa Modo B, el flujo cambia significativamente.

**Paso 1 · Subida de la iniciativa.**
El founder o el cliente sube el documento de la iniciativa (decreto estatal, ley estatal, programa federal, NOM nueva). ARCHIVO la procesa con OCR/extracción.

**Paso 2 · Identificación de obligaciones municipales derivadas.**
El sistema extrae claims atomicos de la iniciativa y los clasifica específicamente como "obligaciones municipales." Cada obligación lleva:

```typescript
interface MunicipalObligation {
  id: string
  initiative_id: string
  obligation_text: string              // texto literal de la iniciativa
  obligation_type: 'mandatory' | 'recommended' | 'aspirational'
  deadline?: Date                      // si la iniciativa establece plazo
  affected_fractions: FractionId[]
  cross_regulation_implications: string[]  // qué reglamentos municipales se ven afectados
  compliance_indicators: ComplianceIndicator[]  // cómo se mide cumplimiento
}
```

**Paso 3 · Mapeo a fracciones y reglamentos.**
El sistema sugiere al founder qué fracciones activar para cumplir con las obligaciones. El founder decide cuáles aplicar (puede ser que el municipio quiera ir más allá de lo que exige la iniciativa, agregando fracciones voluntarias).

**Paso 4 · Adaptación de los módulos.**
Los módulos M00B-M15 se adaptan para reflejar el contexto de la iniciativa:

- M00B agrega sección dedicada a la iniciativa con su análisis
- M01 se enfoca en el diagnóstico de las fracciones que la iniciativa obliga
- M03 incorpora el marco legal de la iniciativa como capa adicional
- M03B genera adendos cruzados específicos para cumplir con la iniciativa
- M13 calcula escenarios financieros del plan de implementación, no del programa propio
- M14 incluye riesgo de incumplimiento de la iniciativa con multas asociadas
- M15 produce plan de implementación, no expediente de iniciativa propia

**Paso 5 · Tracking de cumplimiento.**
En Plataforma 3 (Ejecución) los reportes ESG trimestrales incluyen sección específica de avance contra obligaciones derivadas de la iniciativa, no solo del programa interno.

---

## SECCIÓN 6 · Catálogo nacional de iniciativas digeridas

Conforme el sistema digiere iniciativas para distintos tenants, construye catálogo nacional reutilizable.

**Por qué importa:**

Si SLP digiere una iniciativa estatal de SLP, ese trabajo de digestión se reutiliza para cualquier otro municipio de SLP que active el mismo Modo B. Si Monterrey digiere una iniciativa estatal de Nuevo León, sirve para Apodaca, Guadalupe, San Pedro, etc.

**Schema del catálogo:**

```typescript
interface MunicipalInitiative {
  id: string
  
  // Identificación
  title: string
  level: 'federal' | 'state' | 'metropolitan'
  state?: string                       // si aplica a un estado específico
  applicable_municipalities: string[]  // INEGI codes de municipios donde aplica
  
  // Publicación
  publication_source: string           // ej: "Periódico Oficial del Estado de Nuevo León"
  publication_date: Date
  effective_date: Date
  
  // Contenido digerido
  full_text_url: string
  obligations_extracted: MunicipalObligation[]
  affected_fractions: FractionId[]
  
  // Metadata
  digested_at: Date
  digested_by_tenant_id?: string       // qué tenant lo subió primero
  digestion_status: 'pending' | 'in_progress' | 'completed' | 'verified'
  verified_by_founder: boolean
  
  // Uso
  used_by_tenants: string[]           // tenants que están activando Modo B con esta iniciativa
}
```

**Beneficio competitivo:**

Después de 12 meses operando, el catálogo nacional de iniciativas digeridas se vuelve activo estratégico único. Ningún competidor tiene esa base de conocimiento. Conforme se acumulan iniciativas digeridas, el onboarding de nuevos tenants en Modo B se vuelve casi instantáneo.

---

## SECCIÓN 7 · Implicación en módulos existentes

Los módulos M00B a M15 documentados en `MODULES_OPERATIONAL_SPECS_VALIDATION.md` requieren extensión para soportar Modo B.

**M00B · Antecedentes del municipio.** Agregar nueva sección 7: "Iniciativas estatales o federales aplicables." Si el tenant activó Modo B, esta sección lista las iniciativas digeridas que aplican a este municipio con sus obligaciones derivadas. Si está en Modo A, esta sección queda como informativa con búsqueda automática vía Perplexity de iniciativas que podrían aplicar.

**M01 · Diagnóstico.** Variante por fracción. Si hay múltiples fracciones activas, M01 se renderiza N veces (M01-RSU, M01-RCD, etc.).

**M02 · Mapa social.** Extender con mapa de circularidad municipal (sección 2 de este V3) cuando hay datos suficientes.

**M03 · Capacidad institucional.** Agregar análisis de marco legal de iniciativa aplicable cuando hay Modo B.

**M03B · Reforma reglamentaria.** Generalizar para producir adendos cruzados a múltiples reglamentos según fracciones activas.

**M13 · Escenarios financieros.** Si Modo B, calcular costo de cumplir vs costo de incumplir (multas) además de los escenarios del programa.

**M14 · Riesgos.** Agregar categoría "incumplimiento de iniciativa" con probabilidades calibradas.

**M15 · Documento final.** Si Modo A, expediente Cabildo del programa propio. Si Modo B, plan de implementación de la iniciativa con cronograma de cumplimiento.

---

## SECCIÓN 8 · Hoja de ruta del modo dual

**No se construye en el MVP inicial.** La hoja de ruta de las 8 semanas documentada en V2 sección 8 sigue vigente para Modo A únicamente.

**Sprint 9-10 · Fundamentos del Modo B (mes 3):**
- Schema `MunicipalInitiative` y `MunicipalObligation`
- Endpoint para subir iniciativas
- ARCHIVO extendido para digerir iniciativas (extracción de obligaciones)
- UI básica de selección de modo durante onboarding

**Sprint 11-12 · Fracciones modulares (mes 3-4):**
- Catálogo de fracciones
- Configuración `TenantConfiguration` con fracciones activas
- Sidebar con árbol de fracciones
- Variantes de M00-M15 por fracción (empezando con RCD como segunda fracción)

**Sprint 13-14 · Adendos cruzados (mes 4):**
- Schema `CrossRegulationAmendment`
- Generación automática de paquete cruzado
- AUDITOR de no-contradicciones entre adendos
- UI de revisión del paquete por el founder

**Sprint 15-16 · Mapa de circularidad (mes 5):**
- Schema `CircularityMap` y entidades relacionadas
- Integración con DENUE INEGI
- Importación de padrones municipales
- Visualización de red dirigida con D3

**Sprint 17-18 · Catálogo nacional (mes 6):**
- Repositorio de iniciativas digeridas reutilizable cross-tenant
- Recomendador determinístico de iniciativas aplicables a un nuevo tenant
- Versionado de iniciativas (cuando se reforman)

**Mes 7+:** expansión a fracciones ENV, RC, RI, AGUA, ENE.

---

## SECCIÓN 9 · Por qué este modo dual es crítico estratégicamente

Cuatro razones que vale verbalizar para que el agente nuevo lo entienda:

**Razón 1 · Convierte Alquimia de "RSU especializada" a "circularidad integral municipal."**
El producto se vuelve multi-vertical sin perder enfoque. La base es la misma plataforma; las fracciones son módulos especializados que se agregan según contexto del cliente.

**Razón 2 · Adapta al contexto real mexicano.**
Estados publican iniciativas con frecuencia (Plan Estatal de Desarrollo, decretos ambientales, programas sectoriales). Los municipios deben implementar pero no tienen herramientas. Alquimia se posiciona como herramienta natural de implementación.

**Razón 3 · Expande el mercado direccionable.**
Modo A limita el mercado a municipios que quieren construir programa propio (minoría). Modo B abre el mercado a municipios que deben implementar iniciativa existente (mayoría). Y los dos modos coexisten sin canibalizarse.

**Razón 4 · Construye activos defensivos únicos.**
El catálogo nacional de iniciativas digeridas + el mapa de circularidad por municipio + la red de adendos cruzados validados son tres activos que ningún competidor tiene. Conforme el sistema opera, estos activos se profundizan.

---

## SECCIÓN 10 · Lo que el founder necesita hacer pronto

**Acción 1 · Compartir el documento del Periódico Oficial de Nuevo León.**
Cuando puedas, sube el documento que se publicó hoy. Sirve como caso de prueba para la digestión de iniciativas. ARCHIVO puede procesarlo y el sistema puede empezar a construir el catálogo nacional con su primera entrada.

**Acción 2 · Validar la arquitectura del Modo B.**
Antes de Sprint 9, revisar este V3 con cabeza descansada y confirmar si el modelo conceptual se sostiene o requiere ajustes. Sprint 9 es a 12 semanas vista, no urgente, pero la validación arquitectónica conviene hacerla antes.

**Acción 3 · Validar la lista de fracciones del catálogo.**
La sección 3 enumera 7 fracciones. Confirmar si esa lista es completa o falta alguna. Sectores no listados que podrían ser fracciones: residuos electrónicos (RAEE), residuos médicos, residuos agrícolas en municipios rurales.

**Acción 4 · Decidir orden de implementación de fracciones después de RSU.**
RCD es la sugerencia natural porque mucho municipio tiene problema visible con escombros, pero podría ser ENV si Modo B llega con iniciativa de envases. Decisión a tomar cuando el primer cliente de Modo B se materialice.

---

## SECCIÓN 11 · Próximos pasos del agente nuevo respecto a este V3

**Sesión inicial:** leer V3 después de V1 y V2. Confirmar al founder que entiende los tres briefs en su conjunto.

**Durante Sprints 2-8 (MVP de Modo A):** mantener V3 como referencia, no construir nada de Modo B todavía. Pero al diseñar schemas y arquitecturas, dejarlas extensibles para acomodar Modo B en Sprint 9+. Por ejemplo, el schema de `tenant_state` debe tener campo `active_mode` aunque por ahora siempre sea `mode_a`.

**Pregunta concreta al diseñar:** "¿Esta decisión arquitectónica que voy a tomar hoy me bloquea o complica la implementación de Modo B en Sprint 9?" Si la respuesta es sí, replantear.

**No agregar funcionalidad de Modo B en MVP.** Es tentador empezar a construir pequeñas piezas, pero el MVP debe demostrar Modo A funcionando perfectamente antes de expandir. Modo B viene después.

---

*AGENT BRIEF V3 · Alquimia · 30 mayo 2026 · Modo dual y circularidad integral*
