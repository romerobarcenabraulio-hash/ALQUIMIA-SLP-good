# 04 · DIAGNÓSTICO · Motor de contabilización + Paquete comercial + Reformas normativas

**Fecha:** 13 junio 2026
**Alcance:** ESTO ES DIAGNÓSTICO. Medir, cuantificar, mapear, detectar brechas. Nada de orquestación de programa (eso es planeación / Supermind).
**Propósito:** cerrar el cómo se justifica la generación de residuos sin inventar, cómo se empaqueta como oferta, y cómo se aterrizan las reformas normativas.

---

## PARTE A · Motor de contabilización de residuos (cómo se justifica la cifra)

### El método madre: factor × conteo

La generación de un municipio por tipo de actividad se estima, de forma defendible, así:

```
Generación estimada del giro = Σ (establecimientos del giro × factor de generación del giro)
```

Cada número apunta a una fuente. Cero invención.

### Los cuatro insumos

1. **Universo de establecimientos (DENUE INEGI).** Público y legítimo. Da, por municipio: cuántos establecimientos, de qué giro (SCIAN) y de qué tamaño (estrato de empleados). Ya lo scrapeas.

2. **Catálogo de factores de generación por giro SCIAN.** *Esta es la pieza central que falta.* Una tabla que, por giro, da el factor de generación con su unidad correcta y su fuente citada:
   - Oficinas / comercio → kg por empleado por día
   - Hospital → kg por cama por día
   - Construcción → kg de RCD por m² de obra
   - Restaurante → kg por comensal o por m²
   - Escuela → kg por alumno por día
   - Industria → kg por empleado o por unidad de producción según subsector
   - Fuentes citables: SEMARNAT, manuales SEDATU, Banco Mundial (What a Waste), literatura de ingeniería ambiental, normas.

3. **Mapeo SCIAN → factor.** Lógica de resolución: si el giro tiene factor directo, úsalo. Si no, usa el del giro comparable más cercano (etiquetado "comparable"). Si no hay comparable razonable, márcalo pendiente. Nunca inventes el factor.

4. **Banda de confianza.** Cada estimación lleva intervalo (baja/media/alta) según la calidad de la fuente del factor y la representatividad para ese municipio.

### La encuesta calibra, no funda

La cifra municipal existe desde el día cero solo con factor × DENUE. La encuesta entra a **subir la confianza**:
- Empresa participa con consentimiento, a cambio de su mini-diagnóstico gratis (valor a cambio = ética + tasa de respuesta).
- Su dato real reemplaza el factor estimado para ESE establecimiento.
- Y corrige el factor local para giros similares en ese municipio.
- Trazabilidad como gradiente: un medidor de "calidad del diagnóstico" sube conforme entran respuestas. Le da al municipio una razón visible para empujar participación.

### Distribución de la encuesta (la versión que no te explota)

- Universo de contacto: empresas que **optan por participar**, no correos raspados.
- Canal: email (a quien opta) y, post-piloto, WhatsApp con plantillas aprobadas.
- Consentimiento explícito al inicio (LFPDPPP): qué se recolecta, para qué, quién lo ve. Aceptación registrada con timestamp.
- Cero "enviar hasta que conteste". Recordatorio razonable, opción de baja respetada.

### Composición física — el dato rey que te diferencia

El estudio de cuarteo (NMX-AA-015 y NMX-AA-022) es el dato más fuerte en residuos. Aunque el municipio no lo tenga:
- Estructura el módulo para capturarlo cuando exista.
- Mientras tanto, estima composición con benchmark nacional + perfil industrial del municipio.
- El que tiene cuarteo manda; el que no, se estima y se etiqueta. Trazabilidad pura.

---

## PARTE B · Paquete comercial por áreas (cómo se vende)

### La lógica de oferta

El cliente elige en qué áreas quiere circularidad; se le arma el paquete con precio derivado del estudio.

```
Áreas disponibles (fracciones):
  RSU domiciliario
  RCD (construcción y demolición)
  Residuos de servicios (hospitales, escuelas)
  Residuos comerciales
  Residuos industriales (no peligrosos)
  Orgánicos / compostaje

El cliente arma su paquete eligiendo áreas →
  cada área activa su set de módulos de diagnóstico →
  el precio se deriva del alcance del estudio (núm. de áreas,
  tamaño del municipio, profundidad de trazabilidad solicitada)
```

### Principio de precio

El precio no es un número de catálogo: se deriva del estudio (cuántas áreas, cuántos establecimientos, qué tan profunda la trazabilidad). Mix de precios de materiales = fijo por ciudad, configurado por founder, defendible (Beta-PERT / LogNormal / Triangular), nunca slider del cliente.

### Lo que el cliente recibe en diagnóstico (por área)

Generación estimada y trazable, composición, costo actual del servicio, potencial de valorización, brecha normativa, línea base de emisiones, índice de criticidad (semáforo), y la lista de datos faltantes (que es tu siguiente venta).

---

## PARTE C · Reformas normativas por tipo de inmueble (homologación)

### El concepto

Un paquete entero de circularidad implica reformas a múltiples reglamentos. El entregable de diagnóstico-hacia-reforma es una **matriz de obligaciones por tipo de generador**, derivada de las normas madre y aterrizada al reglamento local.

### La matriz (qué exige por tipo de inmueble)

Por cada tipo de generador —construcción, hospital, escuela, comercio, industria, mercado— se define:
- Separación obligatoria (qué fracciones)
- Contenedores requeridos (tipo, código de color, número)
- Frecuencia de entrega
- Plan de manejo (¿requiere? ¿bajo qué umbral?)
- Norma madre que lo respalda (cita)

### Cero invención también aquí

Tú no inventas el requisito. Lo cosechas de la norma madre (NOM-161 para planes de manejo de RME, NOM-052 si hay peligrosos, reglamentos estatales, NOM por giro) y lo homologas al reglamento municipal. El entregable es el diagnóstico de brecha: "esto dice tu reglamento hoy, esto debería decir, esta es la cita que lo respalda."

### Frontera importante

Diagnóstico produce la **matriz de brecha y la propuesta de texto**. La adopción formal (que el Cabildo lo apruebe) y la orquestación de la implementación son planeación/ejecución, no diagnóstico.

---

## Lo que falta integrar (resumen accionable de diagnóstico)

| Pieza | Estado | Prioridad |
|---|---|---|
| Catálogo de factores de generación por giro SCIAN | No existe — pieza madre | 🔴 |
| Mapeo SCIAN → factor con fallback a comparable/pendiente | No existe | 🔴 |
| Banda de confianza por estimación | Parcial | 🟡 |
| Encuesta con consentimiento + mini-diagnóstico de retorno | Decision-tree existe, falta wrapper | 🟡 |
| Medidor de "calidad del diagnóstico" (gradiente de trazabilidad) | No existe | 🟡 |
| Módulo de cuarteo (captura + estimación fallback) | No existe | 🟡 |
| Costo real del servicio actual de limpia | Probablemente falta | 🟡 |
| Índice de criticidad / semáforo municipal | No existe | 🟡 |
| Matriz de obligaciones normativas por tipo de inmueble | No existe | 🟡 |
| Paquete comercial por áreas con precio derivado | Propuesta engine existe, falta el armador por áreas | 🟡 |

---

*04 · DIAGNÓSTICO · Alquimia · 13 junio 2026*
