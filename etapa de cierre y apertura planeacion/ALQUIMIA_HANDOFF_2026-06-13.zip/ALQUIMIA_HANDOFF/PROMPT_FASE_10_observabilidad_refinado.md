Trabaja en /Users/braulioromerobarcena/Documents/alquimia-slp.

FASE 10 · Observabilidad y operación post-release

Tipo de agente recomendado para Cursor Rules:
Ejecutar en cuatro pasadas secuenciales, no en paralelo. El orden importa:
  1. BIOS define qué se observa y la matriz de severidad.
  2. KRONOS implementa health checks y smoke tests backend.
  3. POLIS implementa regresión visual y verificaciones de CSS.
  4. AUDITOR cierra con la firma final y la decisión binaria.
Si dos agentes corren en paralelo van a chocar en los mismos archivos
(matriz de severidad, bitácora, smoke tests). Por eso secuencial.

Contexto:
Fase 9 dejó una decisión de release: listo, staging only o bloqueado.
Si el release fue aprobado o enviado a staging, ahora toca asegurar
que ALQUIMIA pueda operar sin degradarse silenciosamente. Esta fase
no agrega features ni rediseños — instala los controles mínimos para
que el founder no tenga que cuidar la plataforma manualmente.

Objetivo:
Instalar controles mínimos para detectar errores reales después de
publicar: acceso, datos, exports, regresiones visuales, tenant_state,
gates contractuales del cliente y módulos críticos.

Alcance estricto

1. Definir checklist post-release ejecutable en menos de 10 minutos
   por el founder o por un operador. Sin checklist no hay release.

2. Crear health checks automáticos cada 5 minutos para:
   - backend (endpoints /api/health, /api/tenants/health)
   - frontend (load time < 3s en las tres plataformas)
   - tenant_state (lectura de current_stage funcional)
   - capability_registry (archivo accesible y parseable)
   - Plataforma 0 (auth doble factor responde)
   - export/documentos (generación PDF de un módulo pilar funciona)

3. Crear smoke tests recurrentes que corren:
   - al desplegar (obligatorio antes de declarar release exitoso)
   - diariamente a las 06:00 hora SLP (antes de que cualquier cliente
     abra la plataforma)
   Los smoke tests cubren:
   - tenant validation → /v carga sin error y muestra módulos correctos
   - tenant planning → /p carga sin error
   - tenant execution → /e carga sin error
   - acceso indebido devuelve 403 (tenant en validation accediendo a /p)
   - SLP carga sin pérdida visible de datos
   - Transición G1 → G2 con evidencia subida activa Plataforma 2 sin
     pérdida de estado del tenant
   - Transición G2 → G3 con evidencia subida activa Plataforma 3 sin
     pérdida de estado del tenant
   - El botón de rollback de un click en Plataforma 0 sigue funcional
     (no solo en desarrollo, también en producción)

4. Crear control de regresión visual automatizado, ejecución semanal
   los domingos a las 22:00 hora SLP:
   - desktop ancho (1920px)
   - laptop (1440px)
   - mobile (375px)
   - módulos principales: M00, M01, M03B, M04, M13, M14, M15, M16,
     M17, M18, M21 y las tres portadas de plataforma
   Cualquier diff visual mayor al 2% abre ticket P2 automático.

5. Crear control de regresión editorial dividido en dos capas:
   Capa automática (POLIS verifica en cada release):
   - cifras con jerarquía clara (font-size mayor para la cifra ancla)
   - color tipográfico controlado (variables CSS, no hex hardcoded)
   - no hay text-shadow ni gradientes en tipografía
   Capa manual (founder verifica en los módulos pilar al hacer release):
   - conclusión primero en M01, M13, M14, M18, M21
   - sin bloques anidados de más de dos niveles
   Esta segunda capa no se automatiza. Es checklist humano del founder
   en cada release de un módulo pilar.

6. Crear bitácora de incidentes en /docs/incidents/incidents_log.md
   con formato:
   - timestamp
   - severidad P0/P1/P2/P3
   - sistema afectado
   - tenant afectado (si aplica)
   - descripción del síntoma
   - acción tomada
   - tiempo de resolución
   - root cause documentado
   - prevención futura

7. Crear procedimiento de rollback en /docs/runbooks/rollback.md:
   - condiciones que disparan rollback automático versus manual
   - pasos exactos para rollback de un click desde Plataforma 0
   - verificación post-rollback (los mismos smoke tests del punto 3)
   - comunicación al cliente afectado
   - documentación del incidente que disparó el rollback

8. Crear protocolo de hotfix mínimo en /docs/runbooks/hotfix.md:
   - cuándo aplica hotfix versus rollback (P0 con root cause claro
     y fix < 30 min va por hotfix; el resto va por rollback)
   - quién autoriza el hotfix (siempre el founder, sin excepción)
   - verificación post-hotfix
   - documentación obligatoria

9. Documentar qué señales bloquean producción (criterios P0):
   - acceso por etapa rompe: tenant ve plataforma equivocada
   - SLP pierde datos o muestra datos incorrectos
   - export sale como correcto con advertencias bloqueantes ocultas
   - Plataforma 0 inaccesible para el founder
   - cualquier gate G1-G5 falla al cerrarse con evidencia válida
   - capability_registry no parseable

10. Documentar qué señales permiten seguir operando con monitoreo
    elevado (P1, P2, P3):
    - P1: degradación parcial (un módulo no carga pero el resto sí)
    - P2: problema visual sin impacto funcional
    - P3: pulido editorial o cosmético

Matriz de severidad declarada explícitamente

P0 (bloquea producción, rollback inmediato):
- Acceso indebido entre plataformas (tenant ve plataforma equivocada)
- Pérdida o corrupción de datos de cualquier tenant
- Plataforma 0 inaccesible para el founder
- Gate contractual G1-G5 falla al cerrarse con evidencia válida
- Export con advertencias bloqueantes que el cliente no ve
- capability_registry corrupto o inaccesible

P1 (degradación significativa, hotfix en menos de 24 horas):
- Un módulo pilar (M01, M13, M14, M18, M21) no carga
- Health check falla en uno de los seis sistemas monitoreados
- Smoke test diario falla en cualquier punto

P2 (visual o funcional menor, fix en próximo sprint):
- Regresión visual mayor al 2% en algún módulo
- Tiempo de carga entre 3 y 5 segundos
- Módulo no pilar con bug funcional menor

P3 (cosmético o editorial, backlog):
- Pulido editorial pendiente
- Inconsistencia tipográfica menor
- Mejora de copy no urgente

Frecuencia de ejecución declarada

- Health checks: cada 5 minutos, 24/7
- Smoke tests: al desplegar + diariamente 06:00 hora SLP
- Regresión visual: semanal, domingos 22:00 hora SLP
- Auditoría editorial manual: por release de módulo pilar
- Verificación de rollback funcional: mensualmente
- Revisión de bitácora de incidentes: founder, viernes 17:00

Sin frecuencia declarada, "recurrente" se traduce en "nunca".

No implementes
- features nuevas
- rediseños
- automatización compleja con orquestadores externos
- dashboards que nadie va a mirar
- alertas ruidosas que se ignoran después de tres días
- cambios comerciales

Reglas críticas
- Si algo rompe acceso por etapa, es incidente crítico P0.
- Si SLP pierde datos o muestra datos incorrectos, es incidente P0.
- Si un export sale como correcto con advertencias bloqueantes ocultas,
  es incidente P0.
- Si Plataforma 0 cae, es incidente P0 aunque las plataformas-cliente
  sigan vivas — el founder no puede administrar tenants y el negocio
  se detiene.
- Si un gate contractual G1-G5 falla al cerrarse con evidencia válida,
  es incidente P0 porque bloquea la facturación del tier siguiente.
- Si una página se ve fea pero funciona, clasificar como P2 o P3.
- No esconder warnings.
- No permitir que la operación dependa de memoria humana.
- El botón de rollback funciona en producción, no solo en desarrollo.
  Verificación mensual obligatoria.

Criterio binario de cierre

Fase 10 solo queda cerrada si existe:
1. Checklist post-release ejecutable en menos de 10 minutos.
2. Smoke tests documentados y automatizados con frecuencia declarada.
3. Health checks básicos corriendo cada 5 minutos.
4. Protocolo de rollback con verificación de que el botón funciona
   en producción.
5. Bitácora de incidentes vacía o poblada con incidentes documentados.
6. Matriz P0/P1/P2/P3 con ejemplos concretos por nivel.
7. Control visual semanal y editorial automatizado activo.
8. Evidencia de que /v, /p, /e y /admin siguen vivos hoy.
9. Evidencia de que SLP sigue íntegro hoy.
10. Verificación explícita de que los gates G1-G5 contractuales del
    cliente operan sin pérdida de estado en transiciones.
11. Estado final declarado: cerrado, parcial o bloqueado.

Entrega requerida
- Archivos modificados o creados con paths absolutos.
- Checklist post-release publicado en /docs/runbooks/post_release.md
- Smoke tests creados en /tests/smoke/ o documentados si son manuales.
- Protocolo de rollback en /docs/runbooks/rollback.md
- Matriz de severidad en /docs/runbooks/severity_matrix.md
- Bitácora inicial en /docs/incidents/incidents_log.md
- Resultado de pruebas ejecutadas hoy.
- Pendientes operativos clasificados por severidad.
- Firma final del AUDITOR con decisión binaria de cierre.

Orden de pasadas explícito

Pasada 1 (BIOS): define matriz de severidad, checklist post-release,
estructura de bitácora de incidentes, qué se observa y dónde se
documenta. No implementa nada todavía.

Pasada 2 (KRONOS): implementa health checks de los seis sistemas y
los smoke tests automatizados. Verifica que el botón de rollback de
Plataforma 0 funciona en producción.

Pasada 3 (POLIS): implementa regresión visual semanal en los tres
viewports y la verificación automática de CSS (jerarquía tipográfica,
variables CSS no hex, ausencia de text-shadow y gradientes).

Pasada 4 (AUDITOR): verifica que las tres pasadas anteriores cumplen
sus criterios, ejecuta los smoke tests completos, confirma estado
de SLP, firma decisión binaria de cierre, documenta pendientes.

Sin estas cuatro pasadas en este orden, la fase no cierra.
