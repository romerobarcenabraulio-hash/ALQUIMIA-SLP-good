# 03 · ALQUIMIA · ROADMAP (Día 1 → Día 1000)

**Fecha:** 13 junio 2026
**Propósito:** la ruta de qué construir, en orden, con la entrevista-orquestador y la naturaleza-con-estándar integradas. Hitos de COBRAR, no de "MVP para inversionistas".
**Filosofía de ritmo:** angosto pero impecable. Un cliente que paga y ve algo roto hace más daño que tres meses de espera.

---

## El principio que ordena todo el roadmap

No construyes features. Construyes **un camino end-to-end que se pueda cobrar**, y lo vas ensanchando. En cada fase, la pregunta no es "¿qué más agrego?" sino "¿qué hace que el siguiente cliente pague y no se rompa?".

---

## FASE 0 · Días 1-10 (tú solo, vibe coding) · "Blindar y profundizar"

Objetivo: que lo que ya existe sea defendible y seguro, no más ancho.

1. Rate limiting en endpoints públicos (slowapi) + disciplina de secretos.
2. Aislamiento de tenants verificado con un test que intenta acceso cross-tenant y DEBE fallar.
3. Reproducibilidad de cálculos: cada cifra calculada guarda inputs + versión de fórmula + timestamp.
4. Sellos de origen visibles en UI (investigado/calculado/cliente/pendiente) — tu filosofía hecha visible.
5. Cola async (Celery) lista para cuando llegue volumen.
6. Cierre estético: quitar cajas, rejilla 8px, paleta restringida, skeleton loaders. Verificar cold start de Render (si duerme, plan que no duerma).

**Hito de fin de fase:** un consultor externo navega el flujo completo de un municipio demo sin encontrar nada roto ni nada que se vea amateur.

---

## FASE 1 · Semanas 2-6 · "El primero que paga" (circularidad)

Objetivo: cerrar el primer contrato cobrable de diagnóstico, con los cálculos inatacables.

1. FOD IPCC para emisiones (numpy) — tu carbono deja de ser factor plano.
2. Monte Carlo en financieros (P10/P50/P90) — credibilidad ante banca.
3. Dimensionamiento de flota y personal — la pregunta #1 del director de servicios públicos.
4. Sankey de flujo de materiales — tu gráfica de portada.
5. WeasyPrint: expediente Cabildo y propuesta en PDF de calidad imprenta.
6. Encuesta de empresas con pantalla de consentimiento (envuelve el decision-tree que ya existe) + agregación al municipio.

**Hito de cobro:** primer municipio o consultor firma y paga Tier Diagnóstico. End-to-end impecable, aunque angosto.

---

## FASE 2 · Meses 2-3 · "El motor vivo" (la entrevista-orquestador)

Aquí entra el corazón de tu visión: la entrevista que arma la UI y el plan que reacciona a campo.

### 2A · La entrevista-orquestador (LISTENER_ORCHESTRATOR)
- El usuario responde un árbol de decisión; el orquestador interpreta cada respuesta contra el **catálogo de módulos prefabricados (Sector Packs)**.
- Si existe el pack para esa operación → lo monta. Si no existe → compone desde **primitivas tipadas** (no improvisa código libre).
- **Naturaleza-con-estándar:** cada pack/primitiva nace con su estándar embebido (GRI/ISO/NOM) como parte heredada NO editable. El usuario configura lo configurable; el estándar no se toca. (Ver doc 04 para por qué esto es lo que lo hace auditable.)

### 2B · El motor de eventos de campo (el plan vivo)
- Capa de eventos: "la pipa no llegó", "camión descompuesto", "ruta incompleta".
- Entrada por voz (transcripción) → evento estructurado.
- El evento invalida un supuesto del plan → OR-Tools recalcula ruta crítica + se actualiza el Gantt y el EVM → alerta + propuesta de reacomodo.
- **Determinista y explicable.** Cuando preguntan "por qué cambió el plan", la respuesta es "porque la pipa no llegó y eso retrasó X dos días", no "la red lo decidió".

### 2C · Voz de rol (ElevenLabs)
- Voces CEO/CFO/COO que guían la construcción del management operativo, pantalla por pantalla.

**Hito de cobro:** el cliente de Fase 1 sube a Tier Implementación (plan vivo), o entra el segundo cliente con la experiencia completa.

---

## FASE 3 · Meses 4-6 · "Replicar al privado" (piloto Supermind dentro del producto)

La misma entrevista-orquestador, ahora apuntada a la empresa privada — pero todavía dentro del producto unificado, no un segundo producto.

- Sector Packs privados (empezar con 1-2 giros, no todos).
- La empresa puede meter su ERP (conectar, no reemplazar) — pero el valor es el coaching, no el ERP.
- Coach transparente: nudges que SIEMPRE dicen su porqué citado al estándar. (Ver doc 04.)
- Detección de cambios normativos que afectan a un tenant → alerta. (Killer feature de "política viva".)

**Hito de cobro:** primera empresa privada paga por su workspace generado.

---

## FASE 4 · Meses 6-18 · "Red económica" (la visión amplia, con disciplina)

Solo cuando las fases anteriores cobran y no se rompen:
- Más Sector Packs (expansión = autoría de packs, la plataforma no cambia).
- Mapa de circularidad agregado anónimo (activo de datos único).
- pgvector / búsqueda semántica sobre el Evidence Registry nacional.
- Pagos/facturación (Stripe/Facturapi/Mifiel) cuando el volumen lo justifique.
- Catálogo nacional de iniciativas digeridas reutilizable cross-tenant.

**Hito:** 10+ tenants pagando, NRR positivo, decisión sobre levantar capital si las métricas lo justifican.

---

## Lo que NO se construye (de Supermind), marcado explícito

El documento `ECONOMY_SUPERMIND_FULL_SYSTEM` describe reemplazar SAP, Oracle, CRMs, marketplaces, legal y contabilidad de toda la economía. **Eso es visión de horizonte, NO scope de construcción.** De Supermind tomamos hoy SOLO: el LISTENER_ORCHESTRATOR (entrevista), el patrón Sector Pack (módulos prefabricados con estándar embebido), y el Universal Spine (contrato de razonamiento). El resto queda parqueado hasta que el producto cobre de forma estable. Cualquier programador que abra Supermind y quiera construir "el reemplazo de SAP" está fuera de scope.

---

## La apuesta frágil, nombrada (para que la construyan sabiéndola)

Tu propia intuición lo dijo: meterle inherente la naturaleza-con-estándar a cada agente "quizá llegue a fallar". Aquí está por qué puede fallar y cómo se evita: falla si el agente **genera** el estándar (lo inventa o lo interpreta libre). No falla si el estándar **vive en el pack como dato citado** y el agente solo lo **aplica**. La diferencia es template-con-contrato vs. improvisación. Doc 04 lo detalla. Constrúyelo así y la apuesta se sostiene.

---

*03 · ROADMAP · Alquimia · 13 junio 2026*
