# 05 · OPS DE EJECUCIÓN Y GOBERNANZA · Cómo programamos sin volver al enredo

**Fecha:** 13 junio 2026
**Para:** founder (solo ahora) + 1-2 programadores cuando entren.
**Propósito:** las reglas de cómo se construye con Claude Code + Codex + un agente auditor, sin repetir el enredo de GitHub — y la frontera diagnóstico/planeación para que nadie construya Supermind antes de tiempo.

---

## La regla #1 que evita el enredo (la más importante)

**Una sola compuerta de merge a `main`.** Mientras vas solo, esa compuerta eres tú. Cuando entren programadores, sigue siendo UNA persona designada. Claude Code y Codex pueden construir todo lo que quieran, pero nadie mergea a `main` sin pasar por la compuerta única.

El enredo de GitHub que ya viviste pasa cuando dos fuentes escriben a main sin compuerta. Multiplicado por dos agentes + dos programadores = caos a cuádruple velocidad. La compuerta única lo previene de raíz.

---

## Setup de agentes

### Quién construye
- **Claude Code:** constructor principal. Features, módulos, modelos.
- **Codex:** constructor secundario en paralelo, o auditor (ver abajo). No los dos roles a la vez en la misma pieza.

### Quién audita
- **Un agente auditor con contrato de 3 reglas.** No escribe features; revisa PRs. Puede ser Codex revisando lo de Claude Code, o al revés. La regla inviolable: **quien construye no es quien aprueba.**

### El contrato del auditor (sus 3 checks por cada PR)
1. **Cero invención:** toda cifra nueva tiene fuente/fórmula citada. Si encuentra un número hardcoded sin origen, rechaza.
2. **Aislamiento de tenants:** ninguna query nueva filtra datos cross-tenant. Si un endpoint olvida el filtro tenant_id, rechaza.
3. **Lint + build + test pasan:** si rompe el build o baja cobertura crítica, rechaza.

Si los 3 pasan, aprueba. Si uno falla, rechaza con la razón específica. No negocia.

---

## Estrategia de branches

```
main                    ← solo la compuerta mergea aquí. Siempre desplegable.
  └── feature/<nombre>   ← Claude Code o Codex construyen aquí
  └── fix/<nombre>       ← correcciones
  └── audit/<nombre>     ← si el auditor necesita proponer cambios
```

Reglas:
- Una feature = un branch = un PR. Nada de branches gigantes con 20 cosas.
- El branch se borra después de mergear. Cero branches zombies (como los `codex/rescue-*` que quedaron del enredo anterior — archívalos).
- Nadie commitea directo a main. Ni tú. Todo pasa por PR aunque seas el único.

---

## Manejo de secretos (inviolable)

- Todas las keys (ElevenLabs, transcripción, LLM, SES, Clerk, etc.) en variables de entorno de Render/Vercel.
- Un `.env.example` en el repo con los NOMBRES de las variables, sin valores.
- Valores reales SOLO en el dashboard del proveedor. Nunca en el repo, nunca en un commit, nunca en un mensaje de chat con un agente.
- Si una key se filtra a un commit: rotar inmediato, no "luego".

---

## Sonatype / seguridad de dependencias

- Cada `pip install` o `npm install` nuevo pasa por escaneo de vulnerabilidades.
- Sonatype OSS Index (tier gratis) o, como mínimo equivalente, GitHub Dependabot + `pip-audit` / `npm audit`.
- Crítico cuando entren los 2 programadores metiendo deps rápido en vibe coding. Una librería con CVE crítico en tu backend de gobierno es inaceptable.
- Regla: el auditor verifica que ninguna dep nueva traiga CVE crítico antes de aprobar el PR.

---

## El ritmo de trabajo (vibe coding sano)

1. Tomas UNA tarea del roadmap (doc 03) o del backlog de diagnóstico (doc 04).
2. Branch nuevo.
3. Claude Code construye.
4. Verificas visualmente en Chrome incognito.
5. PR → auditor corre sus 3 checks.
6. Compuerta mergea a main.
7. Deploy. Verificas en producción.
8. Borras el branch. Siguiente tarea.

Una tarea cerrada de principio a fin vale más que cinco a medias. Angosto pero impecable.

---

## LA FRONTERA · Diagnóstico vs Planeación (para que ningún agente se adelante)

Esto es regla de scope, no sugerencia.

**Diagnóstico (estos días, lo que se cobra primero):**
medir, cuantificar, mapear, detectar brechas. Factores SCIAN, cuarteo, costo del servicio, valorización, emisiones línea base, matriz normativa de brecha, índice de criticidad, propuesta y precio.

**Planeación (la "nueva aplicación", DESPUÉS):**
es un ejecutor con anatomía propia — agentes nuevos, módulos nuevos de front y back. Aquí entra el esqueleto de Supermind: LISTENER_ORCHESTRATOR (la entrevista que arma la UI), Sector Packs (módulos prefabricados con estándar embebido), Universal Spine (contrato de razonamiento), el motor de eventos de campo (el plan vivo), las voces de rol. Y de esta anatomía, una vez probada en circularidad, se replica al sector privado.

**Regla para todos los agentes:** ningún agente empieza a construir nada de planeación/Supermind hasta que diagnóstico esté cerrado y verificado. Cualquier agente que abra `ECONOMY_SUPERMIND_FULL_SYSTEM` y quiera construir "el reemplazo de SAP" o el orquestador está fuera de scope. Supermind es el motor de PLANEACIÓN, no de diagnóstico, y planeación viene después de cobrar el primer diagnóstico.

---

## Por qué planeación es, correctamente, "otra aplicación"

Tienes razón en nombrarla así. Diagnóstico observa y mide; planeación ejecuta y orquesta. Son dos naturalezas distintas:
- Diagnóstico es mayormente lectura + cálculo determinista. Bajo riesgo, alta defendibilidad, se cobra solo.
- Planeación es escritura de estado operativo + orquestación de agentes + reacción a campo. Más compleja, más riesgosa, requiere el diagnóstico ya validado como base.

Construir planeación encima de un diagnóstico a medias es construir sobre arena. Por eso el orden importa, y por eso esta frontera es regla, no preferencia.

---

*05 · OPS DE EJECUCIÓN Y GOBERNANZA · Alquimia · 13 junio 2026*
