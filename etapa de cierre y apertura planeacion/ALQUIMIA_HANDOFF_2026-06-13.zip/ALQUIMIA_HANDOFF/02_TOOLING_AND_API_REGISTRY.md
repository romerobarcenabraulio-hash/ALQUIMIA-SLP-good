# 02 · ALQUIMIA · TOOLING & API REGISTRY (Lo que debes instalar)

**Fecha:** 13 junio 2026
**Propósito:** catálogo exacto de herramientas y APIs a instalar, con para-qué, qué la dispara, y límite de uso. Cero ambigüedad para vibe coding.

---

## Cómo usar esto

Cada entrada dice: **qué es**, **para qué en Alquimia**, **qué la dispara**, **límite/costo**, y **prioridad** (🔴 antes de cobrar · 🟡 piloto · 🟢 después). No instales todo de golpe. Instala por prioridad.

Regla de oro de vibe coding: **una API nueva = una variable de entorno + un wrapper aislado + un límite de uso documentado.** Nunca llames una API de pago directo desde un endpoint público sin rate limit.

---

## A · Cálculo y modelado (cierran tu profundidad defendible)

### A1 · Google OR-Tools — 🔴
- **Qué es:** solver open source de optimización (VRP, scheduling, asignación). Estándar mundial.
- **Para qué:** optimización de rutas de recolección + reacomodo del Gantt cuando hay un evento de campo. Reemplaza cualquier intento casero de ruteo.
- **Dispara:** cliente pide plan de rutas; o evento de campo invalida el plan vigente.
- **Límite/costo:** gratis, corre en tu backend Python. Cuidar tiempo de cómputo (timeout por job).
- **Instala:** `pip install ortools`

### A2 · numpy / scipy — 🔴
- **Qué es:** cómputo numérico Python.
- **Para qué:** Monte Carlo en escenarios financieros (P10/P50/P90), FOD IPCC para emisiones, dimensionamiento de flota.
- **Dispara:** generación de escenarios financieros / cálculo de carbono.
- **Límite/costo:** gratis. Guarda TODAS las corridas para auditoría (cero invención).
- **Instala:** `pip install numpy scipy`

---

## B · Documentos y datos

### B3 · WeasyPrint — 🔴
- **Qué es:** HTML/CSS → PDF de calidad imprenta.
- **Para qué:** expediente Cabildo, reporte ESG, propuestas. Reemplaza el HTML report casero.
- **Dispara:** export formal de cualquier documento.
- **Límite/costo:** gratis. Necesita dependencias del sistema (libpango). Documentar en el Dockerfile de Render.
- **Instala:** `pip install weasyprint`

### B4 · pgvector — 🟡
- **Qué es:** extensión de Postgres para búsqueda vectorial. Vive en tu Neon actual.
- **Para qué:** búsqueda semántica sobre el Evidence Registry y documentos del tenant.
- **Dispara:** usuario busca "qué dice el reglamento sobre X".
- **Límite/costo:** gratis (extensión). Embeddings sí cuestan (ver C7).
- **Instala:** `CREATE EXTENSION vector;` en Neon + columna vector.

### B5 · Celery + Redis (broker) — 🔴
- **Qué es:** cola de tareas asíncronas. Ya tienes Redis.
- **Para qué:** procesar PDFs/OCR en background. SIN esto, una campaña masiva de encuestas tumba el backend el día 1.
- **Dispara:** upload de documento; campaña de encuestas.
- **Límite/costo:** gratis (usa tu Redis). Cuidar concurrencia.
- **Instala:** `pip install celery`

---

## C · IA y voz

### C6 · ElevenLabs — 🟡
- **Qué es:** síntesis de voz (TTS). El sistema HABLA.
- **Para qué:** voces de rol (CEO/CFO/COO) que guían al usuario a construir su management operativo. Salida de voz, no entrada.
- **Dispara:** onboarding guiado por voz; coach hablando.
- **Límite/costo:** de pago por caracteres. ⚠️ pon límite por usuario/sesión o te dispara la factura. Cachea audios repetidos.
- **Instala:** API REST, `ELEVENLABS_API_KEY`.

### C7 · Transcripción (Whisper API o Deepgram) — 🟡
- **Qué es:** voz → texto. El sistema ESCUCHA. (ElevenLabs NO hace esto.)
- **Para qué:** entrada de campo. Supervisor dice "la pipa no llegó" → texto → evento estructurado.
- **Dispara:** reporte de campo por voz.
- **Límite/costo:** de pago por minuto. Whisper (OpenAI) o Deepgram. Límite por sesión.
- **Instala:** API REST, key correspondiente.

### C8 · Embeddings (OpenAI o local) — 🟡
- **Qué es:** texto → vector, para pgvector.
- **Para qué:** alimentar B4.
- **Dispara:** indexado de documento nuevo.
- **Límite/costo:** de pago por token (barato). O modelo local si quieres cero costo.

### C9 · LLM gateway / Model Router — 🟡
- **Qué es:** capa que rutea a Claude/GPT/Gemini según tarea. (El "Universal Spine" de Supermind nace aquí.)
- **Para qué:** el orquestador de la entrevista y los agentes razonan a través de esto, model-agnostic.
- **Dispara:** cualquier razonamiento de agente.
- **Límite/costo:** de pago por token del modelo elegido. Presupuesto por tenant.
- **Nota:** no sobre-ingenierar. Empieza con un proveedor, abstrae la llamada para poder cambiar.

---

## D · Distribución

### D10 · Amazon SES (o Resend Broadcasts) — 🟡
- **Qué es:** email a escala. Separado del transaccional.
- **Para qué:** campañas de encuesta a empresas. Resend queda para magic links.
- **Dispara:** campaña masiva.
- **Límite/costo:** SES barato a escala. Cuidar reputación de dominio (warm-up, SPF/DKIM/DMARC).

### D11 · WhatsApp Business API — 🟢
- **Qué es:** mensajería WhatsApp oficial.
- **Para qué:** distribución de encuesta por WhatsApp.
- **Dispara:** campaña.
- **Límite/costo:** de pago por conversación + aprobación de plantillas Meta. Post-piloto.

---

## E · Visualización (frontend)

### E12 · Plotly o d3-sankey — 🟡
- **Para qué:** Sankey de flujo de materiales (tu gráfica de portada). recharts no lo hace bien.

### E13 · Leaflet — 🟡
- **Para qué:** mapa de calor georreferenciado con Marco Geoestadístico INEGI.

---

## F · Seguridad y gobernanza (de gestión, no de features)

### F14 · Sonatype (OSS Index / Nexus Lifecycle) — 🟡
- **Qué es:** seguridad de cadena de suministro de software. Escanea dependencias por vulnerabilidades (SCA).
- **Para qué:** que ninguna librería que metas en vibe coding traiga un CVE crítico. Crítico cuando entren 2 programadores metiendo deps rápido.
- **Dispara:** cada PR / cada `pip install` o `npm install` nuevo.
- **Límite/costo:** OSS Index tiene tier gratis; Nexus Lifecycle es de pago. Empieza con el gratis.
- **Nota:** alternativa gratis equivalente: GitHub Dependabot + `npm audit` / `pip-audit`. Si Sonatype te complica, Dependabot cubre el 80%.

### F15 · slowapi (rate limiting FastAPI) — 🔴
- **Para qué:** proteger endpoints públicos (preview de propuesta, encuesta) de abuso y de disparar tus APIs de pago.
- **Instala:** `pip install slowapi`

### F16 · Gestión de secretos — 🔴
- **Qué:** todas las keys (ElevenLabs, Whisper, LLM, SES) en variables de entorno de Render/Vercel, NUNCA en el repo.
- **Regla:** un `.env.example` sin valores en el repo; valores reales solo en el dashboard del proveedor.

---

## Orden de instalación recomendado (para tus 10 días solo)

**Bloque 1 — protege y profundiza (esta semana):**
1. F15 slowapi (rate limiting) — antes que nada, estás expuesto
2. F16 disciplina de secretos
3. A1 OR-Tools + A2 numpy/scipy (rutas, Monte Carlo, IPCC)
4. B5 Celery (cola async) — antes de cualquier campaña

**Bloque 2 — el piloto de la entrevista:**
5. C9 LLM gateway (el orquestador razona aquí)
6. C6 ElevenLabs (voces de rol)
7. C7 transcripción (entrada de campo)

**Bloque 3 — calidad visible:**
8. B3 WeasyPrint (PDF serio)
9. E12 Sankey + E13 Leaflet
10. B4 pgvector + C8 embeddings

**Cuando entren los 2 programadores:**
11. F14 Sonatype (o Dependabot como mínimo) — el día que dejas de ser el único tocando deps

---

## La regla que te ahorra el caos

Cada API de pago (ElevenLabs, transcripción, LLM, SES) lleva tres cosas obligatorias antes de ir a producción: **límite de uso por usuario/sesión**, **caché de respuestas repetidas**, y **un wrapper único** (todo el código llama a TU función, no a la API directo). Sin esto, el primer día de tráfico real te llega una factura que no esperabas.

---

*02 · TOOLING & API REGISTRY · Alquimia · 13 junio 2026*
