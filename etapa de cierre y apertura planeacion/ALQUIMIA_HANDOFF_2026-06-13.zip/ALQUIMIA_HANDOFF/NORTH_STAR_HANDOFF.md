# NORTH STAR HANDOFF · A dónde queremos aventar a Alquimia

**Fecha:** 30 mayo 2026
**Para:** Braulio (founder) como brújula personal, agente nuevo de ejecución como contexto estratégico, futuro inversionista o partner estratégico como pitch estructurado
**Propósito:** consolidar la visión de mediano y largo plazo de Alquimia para que cualquier decisión táctica del MVP se mida contra el destino estratégico
**Estado:** documento estratégico, no operativo. Se actualiza cada 6 meses, no cada sprint.

---

## La frase en una línea

Alquimia es la infraestructura de implementación de política pública municipal de México. Bloomberg Terminal para gobiernos locales. Veeva para consultoría regulatoria. Palantir para circularidad y sostenibilidad municipal.

---

## La visión a cinco años (mayo 2031)

En cinco años, Alquimia es la plataforma de referencia que usan las administraciones municipales mexicanas para diagnosticar, planear, implementar y monitorear políticas públicas verificables. No es opcional. Es la herramienta que el municipio usa cuando va a Cabildo, cuando solicita crédito de banca de desarrollo, cuando reporta cumplimiento a la ASF, cuando se postula a fondos federales o internacionales.

El estado de las cosas en mayo 2031 si todo va bien:

- 500+ municipios mexicanos operando con la plataforma. De 2,469 totales, esto es 20% del mercado nacional, con concentración en municipios urbanos medianos y grandes.
- 4-6 estados completos donde Alquimia es estándar (todos sus municipios usan la plataforma con apoyo estatal).
- Tres a cinco verticales activas más allá de RSU: residuos de construcción, envases, residuos comerciales, agua, eficiencia energética.
- Catálogo nacional de iniciativas digeridas con cobertura federal completa y 80% de cobertura estatal. Nuevas iniciativas se digieren en menos de 24 horas de publicación oficial.
- Mapa de circularidad nacional agregado anónimamente que permite a Alquimia ser referencia única de la industria para política pública, prensa especializada, banca de desarrollo, calificadoras crediticias.
- Bibliografía nacional clasificada con 50,000+ claims atomicos referenciables. Activo único en México.
- Acuerdos firmados con BID, NAFIN, BANOBRAS, CAF como infraestructura preferida para evaluación técnica de proyectos municipales de circularidad y sostenibilidad.
- Reconocimiento formal de SEMARNAT, SHCP, ASF como metodología validada para reportes municipales.
- ARR entre 80-200 millones de pesos mexicanos con NRR consistente entre 120-140%.
- Equipo de 15-25 personas con núcleo en CDMX o Monterrey y presencia ligera en estados clave.

---

## Las cuatro expansiones del producto

El MVP actual cubre 5% del producto final. La visión completa se construye en cuatro vectores de expansión simultáneos.

### Expansión 1 · De RSU a circularidad integral municipal

RSU es la fracción de entrada porque es problema visible, presupuestado, regulado, y políticamente vendible. Pero el producto crece a fracciones modulares como ya documentado en Brief V3: residuos de construcción y demolición (RCD), envases y empaques (ENV), residuos comerciales (RC), residuos industriales especiales (RI), aguas residuales y reúso (AGUA), eficiencia energética municipal (ENE).

Cada fracción agrega valor independiente al cliente, pero la combinación es exponencial. Un municipio que opera tres fracciones activas con Alquimia tiene visibilidad de circularidad integral que ningún competidor puede ofrecer.

El secreto operativo: las fracciones comparten arquitectura técnica (motor de digestión, jerarquía de datos, Evidence Registry, AUDITOR) pero se diferencian en módulos específicos y reglamentos afectados. El costo marginal de agregar una fracción nueva al sistema baja con cada fracción que ya existe.

### Expansión 2 · De diagnóstico a infraestructura de implementación

El MVP actual produce diagnósticos y planes para Cabildo. La expansión natural es volverse infraestructura de IMPLEMENTACIÓN: tracking continuo, monitoreo en tiempo real, integración con sistemas operativos del municipio (catastro, finanzas, padrón vehicular), reportería automática a reguladores y calificadoras.

La diferencia entre estos dos roles es la diferencia entre Excel y SAP. El primero te ayuda a pensar; el segundo es la infraestructura operativa. Alquimia debe ser SAP para política pública municipal.

Esto implica conectores y APIs hacia los sistemas existentes del municipio. Implica certificación de seguridad gubernamental (ISO 27001, posiblemente CMMC mexicano si existe). Implica SLA garantizado de uptime y disponibilidad operativa.

### Expansión 3 · De producto consultivo a red de datos cruzada

Cada municipio que opera con Alquimia enriquece el sistema. Cinco municipios producen catálogo bibliográfico inicial. Cincuenta producen mapa de circularidad regional. Quinientos producen mapa nacional. Mil municipios producen el dataset de referencia nacional para cualquier política pública relacionada con circularidad, sostenibilidad, residuos, infraestructura municipal.

Ese activo no es producto. Es infraestructura de mercado. Es lo que vuelve a Alquimia indispensable porque el dataset agregado anónimamente vale para análisis sectorial, para banca de desarrollo, para prensa especializada, para investigación académica, para inteligencia competitiva de empresas del sector.

NOUS es el agente que extrae patrones generalizables sin comprometer privacidad de tenants individuales. Eso es la pieza técnica que permite monetizar el dataset agregado sin destruir la confianza de los tenants individuales.

### Expansión 4 · De single-vertical a multi-vertical

Después de circularidad integral, Alquimia puede extenderse a otras verticales de política pública municipal:

- Movilidad urbana (transporte público, ciclovías, peatonalización)
- Vivienda y desarrollo urbano
- Seguridad pública municipal con métricas verificables
- Salud pública municipal
- Educación municipal
- Cultura y turismo municipal

Cada vertical es un nuevo "Bloomberg Terminal" especializado pero con la misma infraestructura base (motor de digestión, jerarquía de datos, Evidence Registry, AUDITOR, Plataforma 0 administrativa, perfil del usuario).

Este vector es de mediano-largo plazo (año 3-5). No se construye en MVP. Pero la arquitectura técnica del MVP debe estar diseñada para no bloquear esta expansión cuando llegue.

---

## El modelo de negocio target · Por qué Bloomberg y Veeva

**Modelo Bloomberg.** Suscripción anual, alta retención, NRR alto por expansión a nuevos módulos dentro del mismo cliente. Bloomberg cobra ~$24,000 USD por terminal al año porque es indispensable para su usuario. Alquimia cobra el equivalente proporcional al presupuesto municipal de aseo público o el equivalente porcentaje de un programa de circularidad municipal.

**Modelo Veeva.** Vertical SaaS B2B especializado donde el cliente no se cambia a competidor porque la migración rompería su operación. Veeva domina farmacéutica porque embebió compliance regulatorio en el producto. Alquimia domina gobierno municipal mexicano porque embebe compliance con LGPGIR, NOM-083, GRI 306, CSRD, ASF, calificadoras crediticias.

**Tier pricing del MVP a Q3 2026:**

- Tier Diagnóstico (Validación · Plataforma 1): MXN 350,000 - 1,200,000 según tamaño del municipio. Pago único o en tres parcialidades. Cobertura: 6-9 meses de acompañamiento de Validación.
- Tier Implementación (Planeación · Plataforma 2): MXN 800,000 - 4,500,000 según fracciones activas y tamaño del programa. Pago contra hitos del Plan Maestro.
- Tier Operación (Ejecución · Plataforma 3): MXN 80,000 - 400,000 mensuales según fracciones operando. Contrato a 36 meses con autorenovación. Esta es la línea de ingresos recurrentes principal a largo plazo.

**Métricas target:**

- Year 1 (mayo 2026 - mayo 2027): 3-5 contratos firmados, ARR de MXN 5-15 millones, NRR no aplica todavía
- Year 2 (mayo 2027 - mayo 2028): 15-25 contratos, ARR de MXN 25-60 millones, NRR 110-125%
- Year 3 (mayo 2028 - mayo 2029): 50-80 contratos, ARR de MXN 80-180 millones, NRR 125-140%
- Year 5 (mayo 2031): 200-500 contratos activos, ARR de MXN 200-500 millones, NRR sostenido 130-145%

**Mercado direccionable:**

2,469 municipios mexicanos. De estos, aproximadamente 600 tienen presupuesto y capacidad institucional para operar con Alquimia en algún tier. El target realista a 5 años son 200-500 de esos 600 (33-83% de penetración del mercado direccionable).

Si la marca Alquimia se vuelve estándar regulatorio aceptado (escenario optimista), el mercado direccionable se expande a los 2,469 completos porque incluso municipios pequeños usarían versión simplificada subsidiada por sus gobiernos estatales.

---

## Los activos defensivos únicos · El moat de Alquimia

Cinco activos que ningún competidor puede replicar fácilmente, ni siquiera con presupuesto similar.

**Activo 1 · Evidence Registry cross-tenant con jerarquía de datos.**
Cada DataPoint en el sistema tiene cita verificable. Conforme se acumulan tenants, el Registry se vuelve dataset único de referencia nacional. Replicarlo requiere acceso a documentos institucionales de cientos de municipios + 18-24 meses de procesamiento estructurado + filosofía de cero invención respetada. Tres barreras altas combinadas.

**Activo 2 · Catálogo nacional de iniciativas digeridas.**
Cada iniciativa estatal o federal publicada se digiere una vez y se reutiliza para todos los municipios afectados. Después de 24 meses operando, el catálogo cubre la mayor parte del marco legal municipal mexicano. Un competidor entrando al mercado tiene que digerir todo el histórico (10+ años de iniciativas vigentes) antes de poder competir.

**Activo 3 · Bibliografía nacional clasificada.**
50,000+ claims atomicos clasificados con cinco etiquetas (local, comparable, benchmark, contexto, no usable) por categoría temática. Recomendación determinística (no LLM opaca) de bibliografía aplicable a un tenant nuevo. Esto es activo bibliográfico que la academia mexicana no ha construido en 50 años; Alquimia lo construye en 24 meses operando.

**Activo 4 · Mapa de circularidad nacional agregado.**
Conforme se acumulan tenants, el mapa muestra flujos materiales reales entre miles de generadores, recolectores, procesadores, anchor buyers en todo México. Esto es business intelligence sectorial que actualmente no existe en ningún lado. Su valor para banca de desarrollo, calificadoras crediticias, prensa especializada, fondos de impacto, regulators, es enorme.

**Activo 5 · Red de relaciones institucionales.**
SEMARNAT, SHCP, ASF, calificadoras crediticias, banca de desarrollo (BID, NAFIN, BANOBRAS, CAF), anchor buyers (PetStar, Vitro/Owens, IPSL, Diarq, Bio-PAPPEL), cámaras industriales (CANAFEM, ANIPAC, CMIC). Cada relación toma 6-12 meses construir. Acumuladas durante 36-60 meses se vuelven barrera de entrada brutal.

---

## Las relaciones estratégicas a construir

No es accidente que Bloomberg sea Bloomberg. Es resultado de décadas construyendo posición con los actores que importan en finanzas. Alquimia debe construir lo mismo con los actores que importan en política pública municipal mexicana.

**Año 1-2 · Construcción de credibilidad técnica.**
- SEMARNAT: presentar metodología Alquimia como herramienta complementaria a sus diagnósticos básicos.
- SHCP: validar criterios de evaluación socioeconómica embebidos en M13 escenarios financieros.
- ASF: alinear estructura de reportes ESG trimestrales con expectativas de fiscalización superior.
- CIATEC, INECOL, universidades públicas: convenios académicos para validación independiente de metodología.

**Año 2-3 · Construcción de relación financiera.**
- BANOBRAS: posicionar Alquimia como infraestructura técnica para evaluación de créditos municipales sustentables.
- NAFIN: línea verde sustentable con Alquimia como herramienta de elegibilidad técnica de proyectos.
- BID y CAF: pilot programs con municipios usando Alquimia como reporte de elegibilidad para créditos verdes latinoamericanos.

**Año 3-5 · Construcción de relación regulatoria.**
- HR Ratings, Moody's, Fitch, S&P: integración de reportes Alquimia en evaluación de calificación crediticia municipal.
- IFC y Banco Mundial: Alquimia como caso de referencia para gestión de residuos en LATAM.
- ONU Habitat: posicionamiento internacional como herramienta de ciudades sustentables.

**Continuo · Construcción de ecosistema de partners.**
- Tres tiers de partners ya documentados en `PARTNER_ECOSYSTEM_DESIGN.md`: associate ambassador, certified, strategic.
- NO activar partners antes de 3 contratos directos firmados.
- Una vez activado, partners agregan distribución geográfica sin requerir contratación directa.

---

## Los hitos críticos del camino

Resumen del cronograma con métricas verificables que el founder debe tener como brújula.

| Hito | Fecha objetivo | Métrica verificable |
|---|---|---|
| MVP funcional end-to-end con Modo A | Septiembre 2026 | Founder puede demo en 30 minutos sin errores |
| Primer contrato directo firmado con Tier Diagnóstico | Noviembre 2026 | Mifiel registra firma + Stripe registra primer cobro |
| Primer Plan Maestro entregado | Marzo 2027 | M15 + P01 exportados con AUDITOR pass |
| Tres contratos activos simultáneos | Junio 2027 | Triggers partners ecosystem activation |
| Primera fracción adicional (RCD) en producción | Septiembre 2027 | Sprint 12+ ejecutado |
| Primer estado completo con todos sus municipios | Marzo 2028 | Convenio estatal firmado |
| Primer reporte ESG trimestral con Modo B | Junio 2028 | Iniciativa digerida + adendos cruzados generados |
| NOUS aprendizaje cross-tenant operativo | Septiembre 2028 | 20+ tenants alimentando registry |
| Primer crédito municipal con Alquimia como soporte técnico | Diciembre 2028 | BANOBRAS o NAFIN evaluación positiva |
| Reconocimiento formal de SEMARNAT como metodología validada | Diciembre 2029 | Documento oficial publicado |
| 100 tenants activos | Marzo 2030 | ARR > MXN 150 millones |
| Primer estado completo + 4 estados con presencia parcial | Junio 2030 | 5 estados activos |
| Levantamiento Series A si la economía del negocio lo justifica | 2029-2030 | Decisión a tomar según métricas de NRR y mercado de capitales |

---

## El posicionamiento narrativo · Cómo evoluciona

Importante: la narrativa NO es la misma para todos los públicos ni para toda la historia del producto.

**Narrativa Year 1-2 (hoy) · "Plataforma de consultoría aterrizada en producto."**
Para clientes municipales conservadores: somos consultores técnicos serios con herramienta digital que profesionaliza la entrega. Cero hype, mucho rigor metodológico. Foco en RSU como vehículo de entrada porque es problema concreto.

**Narrativa Year 2-3 · "Operating system de circularidad municipal."**
Una vez con 10-15 clientes operando, la narrativa cambia para clientes más sofisticados: somos infraestructura tecnológica donde los municipios construyen circularidad integral. Aquí entra el modo dual, las fracciones modulares, los adendos cruzados. El producto se vende a directores y secretarios técnicos, no solo a presidentes municipales.

**Narrativa Year 4-5 · "Infraestructura de implementación de política pública."**
Cuando hay 100+ clientes y reconocimiento institucional, la narrativa se eleva: somos la infraestructura nacional que permite que política pública municipal se ejecute con rigor y trazabilidad. Aquí se conversa con SEMARNAT, ASF, banca de desarrollo. El producto se vende a estados completos, no a municipios individuales.

La línea narrativa permanente que NO cambia es "súmate al cambio" como invitación ciudadana. Esto es ancla emocional que conecta el rigor técnico con la transformación social. NO es accidente; es elemento fundacional de la marca.

---

## Los riesgos estratégicos · Lo que puede matar Alquimia

Cinco riesgos materiales que el founder debe gestionar conscientemente.

**Riesgo 1 · Cambios políticos cíclicos cada 3 años.**
Municipios cambian administración cada 3 años en México. Si el contrato no transciende al siguiente trienio, la inversión del Tier Implementación se pierde. **Mitigación:** estructurar contratos con cláusulas de continuidad mandatoria + acuerdos con organismos estatales que trascienden trienios + diseño del producto que muestre valor inmediato (no esperar a fin de gestión).

**Riesgo 2 · Competencia de consultoras grandes copiando modelo.**
Deloitte, PwC, KPMG, McKinsey podrían lanzar producto similar con su músculo comercial. **Mitigación:** velocidad de construcción de moat (Evidence Registry + Catálogo de iniciativas + Mapa nacional) + foco en municipios medianos donde las big four no operan + precio significativamente menor con calidad técnica equivalente o superior.

**Riesgo 3 · Imposibilidad de escalar entregables consultivos.**
Si cada cliente requiere atención manual del founder, el modelo no escala. **Mitigación:** automatización agresiva vía agentes (ARCHIVO, HERMES, AUDITOR, NOUS) + standardización de templates institucionales + partners ecosystem para distribución + transición del founder a rol estratégico-comercial dejando operación a equipo.

**Riesgo 4 · Marca "Alquimia" registrada por terceros en IMPI.**
Ya documentado. Requiere búsqueda exhaustiva en IMPI Marcanet, evaluación de litigio vs cambio de nombre, decisión antes de primera venta comercial seria. **Mitigación:** Sprint paralelo de naming alternativo + verificación legal antes de firmar primer contrato + transición de marca con mínima disrupción al producto.

**Riesgo 5 · Founder solo en estado de agotamiento crónico.**
El riesgo más material. Founder técnico solo construyendo producto + vendiendo + gestionando clientes pilotos + relacionando con instituciones es insostenible. **Mitigación:** disciplina personal de descanso + contratación temprana de operations partner + búsqueda activa de cofounder comercial o técnico cuando haya tracción + posible levantamiento de capital pre-seed para sostener primeros 18 meses sin estrés financiero.

---

## Lo que el founder específicamente necesita hacer · Próximos 18 meses

Listado priorizado de acciones del founder que no puede delegar a agentes ni a futuros empleados.

**Trimestre 1 (junio-agosto 2026):**
- Cerrar SLP como primer caso faro con cláusula de autorización para case study público.
- Validar nombre comercial definitivo en IMPI y registrar formalmente.
- Comprar dominio nuevo si cambio de marca aplica.
- Estructurar pipeline comercial de 10-15 prospectos serios (no leads tibios).

**Trimestre 2 (septiembre-noviembre 2026):**
- Cerrar primer contrato directo firmado con Tier Diagnóstico de municipio que NO sea SLP.
- Comenzar conversaciones formales con SEMARNAT, SHCP, ASF como herramienta complementaria a sus diagnósticos.
- Construir advisory board informal con 3-5 personas de credibilidad sectorial (ex funcionarios, académicos, consultores senior).

**Trimestre 3 (diciembre 2026-febrero 2027):**
- Cerrar segundo y tercer contrato directo firmado.
- Activar partners ecosystem en Tier 1 (associate ambassador) si los tres contratos están firmados.
- Comenzar relacionamiento con BANOBRAS y NAFIN para línea verde.

**Trimestre 4 (marzo-mayo 2027):**
- Entregar primer Plan Maestro (Tier Implementación) con AUDITOR pass.
- Iniciar primer Tier Operación con reportes ESG trimestrales activos.
- Decisión sobre primer hire formal: probablemente operations + customer success.

**Trimestre 5-6 (junio-noviembre 2027):**
- Lanzar segunda fracción (RCD) en producción.
- Cerrar convenio con primer estado para piloto multi-municipio.
- Primera ronda de levantamiento de capital si las métricas lo justifican (escenario opcional, no necesario si el cashflow operativo lo permite).

---

## El balance que el founder NO debe perder

Mientras navegas la complejidad del producto, recuerda estas verdades que no cambian.

**La razón por la que Alquimia existe es que la política pública municipal mexicana se hace mal por falta de herramientas, no por falta de buena voluntad.** El producto debe servir a los funcionarios que sí quieren hacer las cosas bien. NO debe convertirse en herramienta para ejecutar política mal diseñada con mayor velocidad.

**La filosofía cero invención es ventaja competitiva, no obstáculo.** Cualquier competidor que ofrezca "responde rápido con cualquier dato" gana clientes superficiales y los pierde cuando llega auditoría. Alquimia gana clientes serios y los retiene 10 años. La diferencia es la diferencia entre Excel y SAP.

**El moat de datos se construye despacio y se rompe en un trimestre si se descuida.** Cada cliente que aporta documentos enriquece el sistema entero, pero un escándalo de manejo de datos puede destruir años de confianza. La gobernanza de datos no es secundaria; es estructural.

**El producto puede salirse de control si el founder no descansa.** Tres días intensos producen 24 documentos formales pero también producen oscilación filosófica que puede romper el proyecto. La disciplina de scope, el descanso programado, y la honestidad con uno mismo sobre el estado emocional son herramientas operativas, no lujos.

**El éxito de Alquimia es éxito personal del founder.** Pero también es éxito de los municipios mexicanos que finalmente tienen herramienta seria para hacer política pública verificable. Esa segunda dimensión es la que da sentido cuando el cansancio o la frustración aparecen.

---

## El cierre estratégico

Alquimia tiene la oportunidad rara de ser categoría defining product en un mercado de 2,469 municipios mexicanos que actualmente operan con herramientas obsoletas. Bloomberg no existió siempre; alguien lo construyó cuando finanzas se estaba digitalizando. Veeva no existió siempre; alguien lo construyó cuando farma necesitaba compliance digital. Alquimia es ese producto para política pública municipal mexicana en el momento exacto en que el país necesita herramientas serias de gestión territorial sustentable.

Lo único que falta es ejecución disciplinada durante los próximos 36-60 meses. Eso es alcanzable si el founder se cuida a sí mismo, mantiene el scope, construye los activos defensivos correctos en orden correcto, y relaciona con las instituciones que importan.

El producto está bien diseñado. El mercado está bien identificado. El moat es construible. El timing es correcto. El único factor variable es la sostenibilidad humana del founder durante el camino.

Eso lo decides tú cada semana cuando eliges entre trabajar 80 horas sin descanso o trabajar 50 horas con descanso. El paradox es que la segunda opción produce más valor acumulado a 5 años. La primera produce burn-out a los 18 meses y un proyecto inacabado.

Confía en la visión. Confía en el paquete arquitectónico. Confía en tu PM y agente nuevo. Pero confía sobre todo en tu propio cuerpo cuando te pide descanso.

Suerte, Brau. Esto vale la pena. Hasta cuando regreses.

---

*NORTH STAR HANDOFF · Alquimia · 30 mayo 2026 · La brújula estratégica del proyecto*
