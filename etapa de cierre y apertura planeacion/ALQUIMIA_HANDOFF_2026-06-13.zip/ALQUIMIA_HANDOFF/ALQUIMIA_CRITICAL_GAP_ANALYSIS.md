# ALQUIMIA · CRITICAL GAP ANALYSIS · Lo que no sabías que faltaba

**Fecha:** 10 junio 2026
**Modo:** partner técnico, no consultor. Crítica directa + solución por cada hueco.
**Base:** verificado contra deployment real (Sprints 7-53 shipped: simulador con versionado, logística con LogisticsDailySummary, HERMES, capabilities por tenant, residue tracking, scrapers, NOUS, partners, BANOBRAS, propuesta engine).

---

## Cómo leer esto

Cada hueco tiene tres partes: **qué falta**, **por qué importa** (la crítica), y **la solución** (qué construir o qué herramienta sustituir). Donde una herramienta externa hace el trabajo mejor que lo casero, te lo digo y marco lo casero como "ilustrativo hasta que se reemplace."

Prioridad: 🔴 crítico para credibilidad técnica · 🟡 importante, diferenciador · 🟢 mejora, no urgente.

---

## BLOQUE A · Cálculos y modelos que faltan

### A1 · 🔴 Factor de emisión GEI con metodología IPCC formal
**Qué falta:** tienes cálculo de CO2e evitado, pero no veo el modelo de emisiones de metano del relleno con el First Order Decay (FOD) del IPCC 2006/2019. Estás calculando con un factor plano.
**Por qué importa:** un factor plano es atacable. BANOBRAS, un perito ambiental, o un regidor técnico te van a pedir el FOD. Sin él, tu cifra de carbono es "ilustrativa," no defendible. Y el carbono es tu gancho ESG.
**Solución:** implementa FOD del IPCC con sus parámetros (k de degradación por tipo de residuo, DOC, DOCf, MCF por tipo de sitio). Es una fórmula determinística, no ML. Inputs: composición (ya la tienes en M01) + clima regional + tipo de sitio. Output: curva de emisiones a 20 años, no un número plano. Cítalo a IPCC 2019 Refinement, Volume 5, Chapter 3.

### A2 · 🔴 Análisis de sensibilidad / Monte Carlo en los escenarios financieros
**Qué falta:** TIR/VPN como punto único. No veo bandas de incertidumbre.
**Por qué importa:** un solo número de TIR es una mentira estadística. La realidad tiene rangos. Banca de desarrollo evalúa proyectos por su distribución de resultados, no por el caso base. Sin sensibilidad, tu modelo financiero parece de estudiante.
**Solución:** Monte Carlo determinístico y auditable sobre 3-4 variables clave (precio de materiales, tasa de captura, CAPEX real vs estimado, costo de oportunidad). Corre 10,000 iteraciones, muestra P10/P50/P90. Crítico: muestra TODAS las corridas descargables, no solo el output, para mantener "cero invención." Librería: usa `numpy` en el backend Python que ya tienes, no inventes un motor.

### A3 · 🟡 Modelo de eficiencia de rutas (lo que mencionaste)
**Qué falta:** tienes LogisticsDailySummary (tracking) pero no veo optimización de rutas real. Estás contabilizando, no optimizando.
**Por qué importa:** "te digo cuánto recolectaste" es commodity. "Te digo cómo recolectar 18% más barato" es lo que vende. La optimización es donde está el ahorro que justifica tu fee.
**Solución — y aquí sustituye herramienta:** NO construyas un solver de VRP (Vehicle Routing Problem) casero. Es un agujero negro de ingeniería. Usa **OR-Tools de Google** (gratis, open source, es el estándar mundial para VRP) o **VROOM** (open source) corriendo en tu backend. Tu trabajo es alimentarlo con los datos del tenant (puntos de recolección, capacidad de flota, ventanas horarias) y mostrar el output. Lo que tienes hoy de logística déjalo como capa de tracking/contabilización ilustrativa, y el módulo de optimización que sea descargable específicamente para tracking y vinculación de unidades, como dijiste. La optimización vive en OR-Tools, no en código tuyo.

### A4 · 🟡 Modelo de dimensionamiento de flota y personal
**Qué falta:** dado X toneladas y Y cobertura, ¿cuántos camiones y cuántas personas necesita el municipio? No lo veo.
**Por qué importa:** es la pregunta #1 que hace un director de servicios públicos. Si no la respondes, no eres su herramienta operativa.
**Solución:** modelo paramétrico simple: toneladas/día ÷ (capacidad_camión × viajes_día × factor_compactación) = flota mínima. Personal por turno según rutas. Todo con benchmarks citables (manuales SEDATU, GIZ waste management). Determinístico, defendible.

### A5 · 🟡 Curva de proyección de generación a 10-20 años
**Qué falta:** proyección de residuos atada a crecimiento poblacional Y crecimiento económico (no solo lineal).
**Por qué importa:** la generación per cápita SUBE con el PIB per cápita. Una proyección solo-poblacional subestima. Esto afecta el dimensionamiento del relleno y el CAPEX.
**Solución:** modelo de dos factores (población CONAPO + elasticidad ingreso-generación con coeficiente del Banco Mundial). Output: banda de proyección, no línea.

### A6 · 🟢 Análisis de punto de equilibrio de la valorización
**Qué falta:** ¿a qué precio de material y qué tasa de captura el programa se paga solo?
**Solución:** break-even chart simple. Precio de material en eje X, margen neto en eje Y, línea de equilibrio. Determinístico.

---

## BLOQUE B · Gráficas y visualizaciones que faltan

### B1 · 🔴 Diagrama de Sankey de flujo de materiales
**Qué falta:** el flujo de residuos (generación → recolección → separación → valorización/disposición) en un Sankey.
**Por qué importa:** es LA gráfica de economía circular. Cuando un funcionario ve su Sankey, entiende su municipio en 5 segundos. Es tu gráfica de portada. Sin ella te ves como software genérico.
**Solución:** `recharts` no hace Sankey bien. Usa **`d3-sankey`** (la librería específica) o **Plotly** (que ya está en tu stack de artifacts y tiene Sankey nativo). Solo se renderiza con datos reales del tenant; sin datos, placeholder honesto.

### B2 · 🟡 Mapa de calor georreferenciado de generación
**Qué falta:** mapa del municipio con intensidad de generación por colonia/zona.
**Por qué importa:** conecta el dato con el territorio. Un presidente municipal piensa en colonias, no en toneladas abstractas.
**Solución:** **Leaflet** (open source, gratis) + datos de INEGI Marco Geoestadístico que ya scrapeas. Capa de calor con los WasteGenerator georreferenciados.

### B3 · 🟡 Matriz de Mendelow (poder/interés) de actores
**Qué falta:** la visualización del mapa social de M02 como matriz 2x2.
**Solución:** scatter plot simple en recharts, eje poder vs interés, cada actor un punto. Trivial de construir, alto impacto visual.

### B4 · 🟢 Gauges de cumplimiento por estándar
**Qué falta:** medidores visuales de % cumplimiento GRI 306 / NOM-083 / etc.
**Solución:** radial gauges. recharts los hace. Conecta a tu AUDITOR.

### B5 · 🟢 Waterfall del costo de no actuar
**Qué falta:** gráfica de cascada que muestra cómo se acumula el costo año a año.
**Solución:** waterfall chart, recharts o Plotly.

---

## BLOQUE C · Herramientas que deberías sustituir o agregar

### C1 · 🔴 Generación de PDF — sustituir
**Qué tienes:** report generation en HTML/JSON casero (Sprint 8).
**Crítica:** HTML-to-PDF casero produce documentos que se ven amateur y se rompen con contenido variable. Tu producto vende rigor institucional; un PDF mal maquetado mata la percepción.
**Solución:** para los documentos formales (expediente Cabildo, reporte ESG) usa los templates docx que ya generamos + una librería seria. En Python: **WeasyPrint** (HTML/CSS a PDF, calidad de imprenta) o **docxtpl** para los Word. Deja el HTML report actual como "vista rápida ilustrativa" y el PDF formal que salga del pipeline serio.

### C2 · 🟡 Búsqueda y recuperación de evidencia — agregar
**Qué falta:** cuando tengas miles de claims y documentos, ¿cómo los buscas semánticamente?
**Crítica:** búsqueda por keyword no escala para tu Evidence Registry. Un usuario va a preguntar "qué dice el reglamento sobre separación" y necesita respuesta semántica.
**Solución:** vector search. **pgvector** (extensión de Postgres — ya tienes Neon Postgres, solo actívala) + embeddings. No montes una base vectorial aparte; pgvector vive en tu DB actual.

### C3 · 🟡 Cola de procesamiento de documentos — agregar
**Qué falta:** cuando 50 empresas suban documentos a la vez, el OCR síncrono va a colapsar tu backend.
**Crítica:** procesar PDFs en el request HTTP es una bomba de tiempo. El primer día de campaña masiva de encuestas, se cae.
**Solución:** cola asíncrona. **Celery + Redis** (ya tienes Redis del Sprint 19) o **Inngest** si quieres algo más moderno. El upload responde inmediato, el procesamiento ocurre en background, notificas al terminar.

### C4 · 🟡 Email transaccional a escala — verificar límite
**Qué tienes:** Resend.
**Crítica:** Resend es excelente pero tiene límites de envío. Una campaña a miles de empresas los excede y te marca como spam.
**Solución:** para campañas masivas usa un canal distinto al transaccional. **Amazon SES** (barato a escala) o **Resend Broadcasts** con dominio caliente y warm-up. Separa: Resend para transaccional (magic links), SES/Broadcasts para campañas de encuesta.

### C5 · 🟢 Feature flags — agregar
**Qué falta:** forma de prender/apagar features por tenant sin deploy.
**Solución:** ya tienes capabilities por tenant (TenantCapability). Extiéndelo a feature flags. No necesitas herramienta externa.

---

## BLOQUE D · Huecos de producto que no consideraste

### D1 · 🔴 Reproducibilidad de cálculos (calculation provenance)
**Qué falta:** cuando una cifra calculada cambia porque cambió un input, ¿puedes reconstruir exactamente cómo se calculó en una fecha pasada?
**Por qué importa:** auditoría. La ASF o un perito te va a preguntar "¿cómo llegaste a esta cifra el 15 de marzo?" Si no puedes reproducir el cálculo con los inputs y la versión de fórmula de esa fecha, tu "cero invención" se cae.
**Solución:** cada DataPoint calculado guarda snapshot de sus inputs + versión de fórmula + timestamp. Inmutable. Ya tienes audit logging; extiéndelo a calculation provenance.

### D2 · 🔴 Versionado de metodología
**Qué falta:** cuando mejores una fórmula (ej: cambias el factor de emisión), ¿qué pasa con los diagnósticos ya emitidos con la fórmula vieja?
**Por qué importa:** si un municipio firmó un expediente con la fórmula v1 y tú la cambias a v2, su documento legal debe seguir reproducible con v1. Sin versionado de metodología, rompes documentos firmados.
**Solución:** la memoria metodológica se versiona (ya lo documentamos). Cada documento emitido registra qué versión de metodología usó. Cálculos viejos se reproducen con su versión.

### D3 · 🟡 Estado offline / degradación elegante
**Qué falta:** los scrapers dependen de sitios de gobierno que se caen seguido (DOF, periódicos oficiales mexicanos son notoriamente inestables).
**Por qué importa:** si tu "política viva" depende de scrapers y la fuente está caída, ¿el sistema miente o avisa?
**Solución:** cada dato scrapeado tiene timestamp de "última verificación exitosa." Si la fuente lleva caída N días, el sistema lo muestra explícitamente ("último dato confirmado hace 5 días"), no finge frescura. Esto refuerza tu filosofía.

### D4 · 🟡 Detección de cambios normativos (no solo scraping)
**Qué falta:** scrapeas DOF/SEMARNAT, pero ¿detectas cuando un documento nuevo AFECTA a un tenant existente?
**Por qué importa:** ese es el verdadero valor de "política viva." No es scrapear; es alertar a Monterrey que salió una norma que les cambia una obligación.
**Solución:** motor de matching entre documento scrapeado nuevo y tenants afectados (por estado, por fracción, por giro). Cuando hay match, alerta al tenant. Esto es tu killer feature de Modo B y casi no cuesta más sobre lo que ya scrapeas.

### D5 · 🟡 Conciliación de datos contradictorios entre fuentes
**Qué falta:** si INEGI dice una población y el municipio dice otra en su documento, ¿qué hace el sistema?
**Por qué importa:** va a pasar constantemente. Tu jerarquía de datos resuelve la prioridad, pero el usuario necesita VER el conflicto, no que se resuelva silenciosamente.
**Solución:** UI de conflicto explícito (ya lo documentamos como EvidenceConflict). Muestra ambos valores, su jerarquía, deja al founder/cliente resolver. Verifica que esté construido.

### D6 · 🟢 Onboarding guiado del primer uso
**Qué falta:** un consultor que entra por primera vez, ¿sabe qué hacer?
**Solución:** tienes el help system del Sprint 8. Conviértelo en un tour guiado de primera sesión (paso a paso contextual), no solo un modal de ayuda pasivo.

---

## BLOQUE E · Huecos de confianza y seguridad

### E1 · 🔴 Aislamiento de tenants — verificar a nivel query
**Qué falta:** confirmar que NINGÚN endpoint filtra datos cross-tenant por un bug de query.
**Por qué importa:** un solo endpoint que olvide filtrar por tenant_id expone datos de un municipio a otro. Con gobierno, eso es catastrófico y posiblemente delito.
**Solución:** middleware que inyecta el filtro tenant_id a nivel ORM, no a nivel endpoint manual. Audita cada query. Test automatizado que intenta acceso cross-tenant y verifica que falla.

### E2 · 🔴 Rate limiting en endpoints públicos
**Qué falta:** tu preview público de propuesta (`/propuesta/public/{nombre}`) y la encuesta de empresas son endpoints sin auth. ¿Tienen rate limit?
**Por qué importa:** sin rate limit, alguien te tira el backend o te dispara la cuenta de OCR/APIs con un script.
**Solución:** rate limiting por IP. **slowapi** (para FastAPI, trivial de agregar) o a nivel de Vercel/Cloudflare.

### E3 · 🟡 Encriptación de documentos sensibles en reposo
**Qué falta:** los documentos institucionales que suben los municipios, ¿están encriptados en storage?
**Solución:** encriptación en reposo a nivel de bucket (S3 SSE o equivalente). Verifica que esté activo.

---

## BLOQUE F · Lo que sustituirías por algo mejor (resumen de swaps)

| Función | Lo casero (déjalo ilustrativo) | Sustitución profesional |
|---|---|---|
| Optimización de rutas | LogisticsDailySummary tracking | **Google OR-Tools** o **VROOM** (VRP solver) |
| PDF formal | HTML report casero | **WeasyPrint** + **docxtpl** |
| Búsqueda de evidencia | keyword search | **pgvector** en tu Neon Postgres |
| Procesamiento de docs | OCR síncrono | **Celery + Redis** (ya tienes Redis) |
| Email masivo | Resend transaccional | **Amazon SES** / Resend Broadcasts (separado del transaccional) |
| Sankey y mapas | recharts | **d3-sankey / Plotly** (Sankey) + **Leaflet** (mapas) |
| Monte Carlo | punto único TIR | **numpy** en backend (ya tienes Python) |
| Emisiones GEI | factor plano | **FOD IPCC 2019** (fórmula, no librería) |

---

## Prioridad de ataque · Lo que yo haría en este orden

**Antes de lanzar (esta semana):**
1. E1 aislamiento de tenants — verificar a nivel query (no negociable con gobierno)
2. E2 rate limiting en endpoints públicos
3. D1 + D2 reproducibilidad y versionado de cálculos (es tu "cero invención" en serio)
4. C3 cola asíncrona de documentos (o la campaña masiva te tumba el backend día uno)

**Semana 2-3 (diferenciadores que venden):**
5. B1 Sankey de flujo de materiales (tu gráfica de portada)
6. A1 FOD IPCC para emisiones (tu gancho ESG defendible)
7. A2 Monte Carlo en financieros (credibilidad ante banca)
8. D4 detección de cambios normativos que afectan tenants (killer feature de política viva)

**Mes 2 (la herramienta operativa real):**
9. A3 optimización de rutas con OR-Tools (descargable, tracking + vinculación de unidades)
10. A4 dimensionamiento de flota y personal
11. B2 mapa de calor georreferenciado
12. C2 pgvector para búsqueda semántica

**Continuo:**
13. Todo lo 🟢 conforme haya tracción.

---

## La crítica de fondo, como partner

Tu sistema tiene una columna vertebral impresionante para un founder solo: simulador, logística, scrapers, NOUS, partners, BANOBRAS, admin table con virtual scrolling. Eso es real y es mucho.

Donde estás expuesto no es en cantidad de features — es en **profundidad defendible de los cálculos**. Ahora mismo tienes amplitud (muchos módulos) con profundidad variable (algunos cálculos son plano-ilustrativos). Tu cliente conservador no necesita más módulos; necesita que los tres o cuatro cálculos que importan (carbono, finanzas, rutas, dimensionamiento) sean inatacables. Un perito que rompe UNA de tus cifras rompe la confianza en TODAS.

Mi consejo de partner: antes de agregar más superficie, vuelve inatacables los cuatro cálculos que un técnico de banca de desarrollo o un regidor de oposición va a auditar primero. Profundidad sobre amplitud. Eso es lo que separa "software bonito" de "infraestructura que el gobierno no puede cuestionar."

---

*ALQUIMIA CRITICAL GAP ANALYSIS · 10 junio 2026*
