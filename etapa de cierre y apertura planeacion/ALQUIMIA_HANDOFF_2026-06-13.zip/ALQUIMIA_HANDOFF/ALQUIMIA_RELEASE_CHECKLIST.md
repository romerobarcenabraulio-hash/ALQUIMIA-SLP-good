# ALQUIMIA RELEASE CHECKLIST · Verificación de visión completa para lanzamiento

**Fecha:** 10 junio 2026
**Estado del deployment:** producción READY, commit `b3bcde9` (demo seed script)
**Objetivo:** lanzamiento la próxima semana
**Uso:** marca cada ítem como ✅ verificado / ⚠️ parcial / ❌ falta. Lo que quede en ❌ o ⚠️ define el trabajo restante antes de lanzar.

---

## Cómo usar este checklist

Cada sección corresponde a una capa de tu visión. Cada ítem es verificable en Chrome incognito contra `alquimiaplatform.com` o en el código. No marques ✅ por fe; marca ✅ solo si lo viste funcionar. Lo que no puedas verificar visualmente, déjalo en ⚠️ hasta que lo pruebes.

Prioridad de lanzamiento: los ítems marcados **[BLOQUEA LANZAMIENTO]** deben estar en ✅ antes de mostrar la plataforma a un consultor o municipio real. Los marcados **[POST-LANZAMIENTO]** pueden quedar pendientes sin frenar el lanzamiento.

---

## 1 · Frontend · Experiencia visible

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 1.1 | Landing pública `/` carga sin errores de consola | ☐ | [BLOQUEA] |
| 1.2 | Narrativa "súmate al cambio" / consultoría de política pública presente, cero copy viejo | ☐ | [BLOQUEA] |
| 1.3 | CTA de registro institucional visible y funcional | ☐ | [BLOQUEA] |
| 1.4 | Página `/comenzar/propuesta` muestra propuesta personalizada por municipio | ☐ | Ya shipped (Sprint 24), verificar |
| 1.5 | `/metodologia` publica la filosofía cero invención | ☐ | [BLOQUEA] credibilidad |
| 1.6 | Diseño consistente: sin bordes innecesarios, tipografía institucional uniforme | ☐ | |
| 1.7 | Responsive en móvil para las pantallas críticas | ☐ | [POST-LANZAMIENTO] aceptable parcial |
| 1.8 | Cero links muertos (`href=''`) en hub y navegación | ☐ | Hubo fix de "Ver propuesta", reverificar |

---

## 2 · Autenticación e identidad

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 2.1 | Login Clerk magic link funcional | ☐ | [BLOQUEA] |
| 2.2 | TOTP activable desde perfil | ☐ | |
| 2.3 | Bridge Clerk→backend JWT funcional (`/auth/clerk-exchange`) | ☐ | Shipped commit c592588, verificar |
| 2.4 | `/hub`, `/perfil`, `/notifications` cargan sin redirigir a sign-in | ☐ | [BLOQUEA] |
| 2.5 | Email admin recibe rol admin automáticamente | ☐ | |
| 2.6 | Filtro institucional: `.gob.mx` automático, genéricos a validación manual | ☐ | Verificar si shipped |
| 2.7 | `CLERK_SECRET_KEY` configurada en Render | ☐ | [BLOQUEA] sin esto el bridge falla |

---

## 3 · Plataforma del cliente · Validación (Plataforma 1)

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 3.1 | Módulos navegables cargan con datos del tenant, no hardcoded SLP | ☐ | [BLOQUEA] filosofía |
| 3.2 | Progresión: módulos se desbloquean al completar el anterior | ☐ | |
| 3.3 | Reglamento municipal como único bloqueador formal implementado | ☐ | |
| 3.4 | Cada cifra muestra sello de origen (investigado/calculado/cliente/pendiente) | ☐ | [BLOQUEA] es el diferenciador |
| 3.5 | Campos sin dato muestran "pendiente + qué falta", no placeholder inventado | ☐ | [BLOQUEA] filosofía |
| 3.6 | Watermark "[N] de [M] módulos completos" | ☐ | |
| 3.7 | Export de módulo a PDF con cita al pie | ☐ | [POST-LANZAMIENTO] si export básico funciona |

---

## 4 · Motor de digestión de evidencia

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 4.1 | Upload de documento desde el módulo funciona | ☐ | [BLOQUEA] es tu herramienta más potente |
| 4.2 | ARCHIVO procesa PDF (OCR/extracción) y devuelve texto | ☐ | |
| 4.3 | Cifras extraídas se integran al módulo con sello "de tu documento" | ☐ | |
| 4.4 | Cálculos dependientes se recalculan al cambiar un input | ☐ | [POST-LANZAMIENTO] si la base funciona |
| 4.5 | Notificación al usuario de qué campos cambiaron tras subir doc | ☐ | [POST-LANZAMIENTO] |
| 4.6 | Outlier detection (IQR + Z-score) corre sobre residue records | ☐ | Shipped Phase D, verificar |

---

## 5 · Scraping de fuentes públicas · "Política viva"

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 5.1 | Scrapers DOF, SEMARNAT, COFEMER, INEGI, ASF corren sin crash | ☐ | Shipped, verificar que NO fallen en prod |
| 5.2 | Scheduler dispara jobs según frecuencia (daily/weekly/monthly) | ☐ | |
| 5.3 | Deduplicación por hash de PDF funciona | ☐ | |
| 5.4 | Retry con backoff exponencial, disable tras 3 fallos | ☐ | |
| 5.5 | Documentos scrapeados aparecen en alguna vista del admin | ☐ | [BLOQUEA] si no se ven, no sirven |
| 5.6 | **Confirmado: scrapers solo tocan fuentes públicas de gobierno** | ☐ | [BLOQUEA legal] no scrapear privados sin consentimiento |

---

## 6 · Encuesta de empresas · Contabilización de residuos (NUEVO)

Este es el componente nuevo que pediste. Está especificado aquí para construir, no verificar (probablemente aún no existe).

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 6.1 | Formulario de encuesta accesible por link único por empresa | ☐ | A construir |
| 6.2 | **Pantalla de consentimiento explícito al inicio**: qué se recolecta, para qué, quién lo ve | ☐ | [BLOQUEA legal] LFPDPPP |
| 6.3 | Decision-tree de clasificación sectorial (ISIC) ya existe, reutilizar | ☐ | Shipped Sprint 50, conectar |
| 6.4 | Captura: giro, tamaño, núm. empleados, operaciones, generación de residuos por fracción | ☐ | A construir |
| 6.5 | Estimación de residuos con material breakdown + confidence score | ☐ | Motor ya existe, conectar |
| 6.6 | Guarda como `WasteGenerator` vinculado al municipio | ☐ | Modelo Generador ya existe |
| 6.7 | La empresa recibe algo de valor a cambio (su propio mini-diagnóstico) | ☐ | Hace ética y retención la encuesta |
| 6.8 | Datos de la encuesta alimentan la agregación municipal | ☐ | Aggregator ya existe, conectar |
| 6.9 | **Aviso de privacidad enlazado y aceptación registrada con timestamp** | ☐ | [BLOQUEA legal] |

---

## 7 · Distribución masiva · WhatsApp y Email

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 7.1 | Lista de empresas objetivo importable (desde DENUE o CSV) | ☐ | A construir |
| 7.2 | Envío de email con link único de encuesta por empresa | ☐ | Resend ya operativo, extender |
| 7.3 | Envío WhatsApp (Business API o proveedor) con link | ☐ | [POST-LANZAMIENTO] email primero |
| 7.4 | **Mensajes identifican claramente al emisor (Alquimia) y el propósito** | ☐ | [BLOQUEA legal] anti-spam, transparencia |
| 7.5 | Opción de baja / no contactar respetada | ☐ | [BLOQUEA legal] |
| 7.6 | Tracking de quién abrió, respondió, completó | ☐ | [POST-LANZAMIENTO] |

---

## 8 · Plataforma 0 · Administrativa (founder)

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 8.1 | `/admin` carga con tabla maestra de tenants | ☐ | AdminMasterTable existe, verificar |
| 8.2 | Columnas: municipio, etapa, usuarios, avance, documentos | ☐ | |
| 8.3 | Drawer del tenant abre con detalle | ☐ | AdminTenantDrawer shipped |
| 8.4 | Founder puede invitar usuarios al tenant | ☐ | Shipped Sprint 21, verificar |
| 8.5 | Founder puede subir PDF manualmente por tenant | ☐ | |
| 8.6 | Vista de documentos scrapeados / generados | ☐ | |
| 8.7 | "Asumir identidad / ver como" con registro | ☐ | [POST-LANZAMIENTO] |

---

## 9 · Inteligencia · Propuesta, NOUS, partners, BANOBRAS

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 9.1 | Motor de propuesta personalizada por municipio funciona | ☐ | Shipped Sprint 24 |
| 9.2 | Preview público sin auth `/propuesta/public/{nombre}` | ☐ | Verificar |
| 9.3 | NOUS genera insights (6 patrones rule-based) | ☐ | Shipped, verificar que no inventen cifras |
| 9.4 | Partners: registro recicladoras/compradores ancla SLP ZM | ☐ | Shipped Sprint 46-48 |
| 9.5 | Evaluación BANOBRAS (7 criterios → score 0-100) | ☐ | Shipped, verificar |
| 9.6 | **Todo insight/propuesta es trazable, cero cifra sin fuente** | ☐ | [BLOQUEA] filosofía |

---

## 10 · Datos, seed y pruebas end-to-end

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 10.1 | `seed_db.py` crea generadores demo con 30 días de registros | ☐ | Shipped commit b3bcde9 |
| 10.2 | Flujo end-to-end completo: registro → módulos → upload → export | ☐ | [BLOQUEA] probarlo entero una vez |
| 10.3 | Municipio Demo navegable sin datos reales de otros tenants | ☐ | |
| 10.4 | Aislamiento de tenants verificado (cliente A no ve datos de B) | ☐ | [BLOQUEA] seguridad |
| 10.5 | Backup de DB configurado (Neon) | ☐ | [BLOQUEA] antes de datos reales |

---

## 11 · Legal y cumplimiento antes de tocar datos reales

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 11.1 | Aviso de privacidad publicado (LFPDPPP) | ☐ | [BLOQUEA] |
| 11.2 | Términos de servicio publicados | ☐ | [BLOQUEA] |
| 11.3 | Banner de cookies / consentimiento | ☐ | [BLOQUEA] |
| 11.4 | Consentimiento de la encuesta de empresas registrado con timestamp | ☐ | [BLOQUEA] |
| 11.5 | Marca "Alquimia" verificada en IMPI o nombre alternativo decidido | ☐ | [BLOQUEA] antes de promoción masiva |
| 11.6 | Scrapers documentados como solo-fuentes-públicas | ☐ | [BLOQUEA] |

---

## 12 · Operación del lanzamiento

| # | Ítem | Estado | Nota |
|---|---|---|---|
| 12.1 | Sentry capturando errores en frontend | ☐ | Shipped, verificar DSN configurado |
| 12.2 | Variables de entorno completas en Render y Vercel | ☐ | [BLOQUEA] |
| 12.3 | Dominio `alquimiaplatform.com` apunta al deploy correcto | ☐ | |
| 12.4 | Plan de soporte: cómo responde un consultor que reporta un bug | ☐ | |
| 12.5 | Material de promoción para consultores locales listo | ☐ | Tu canal de distribución |

---

## Resumen de bloqueadores de lanzamiento

Antes de mostrar Alquimia a un consultor o municipio real, estos deben estar en ✅:

1. Login y bridge JWT funcionando con `CLERK_SECRET_KEY` en Render (2.1, 2.4, 2.7)
2. Módulos con datos del tenant y sellos de origen, sin hardcoded SLP (3.1, 3.4, 3.5)
3. Upload + procesamiento de documentos funcional (4.1)
4. Scrapers solo sobre fuentes públicas, confirmado (5.6, 11.6)
5. Consentimiento explícito en la encuesta de empresas (6.2, 6.9)
6. Aislamiento de tenants verificado (10.4)
7. Aviso de privacidad, términos, cookies publicados (11.1, 11.2, 11.3)
8. Flujo end-to-end probado entero una vez (10.2)
9. Marca verificada en IMPI o alternativa decidida (11.5)

Todo lo demás puede lanzarse parcial y completarse después.

---

## La línea que protege el lanzamiento

La encuesta de empresas y los scrapers son tus armas más potentes. Lo único que las vuelve riesgo en vez de activo es la transparencia. Empresa que sabe qué llena y qué recibe = activo legal y retentivo. Scraper sobre Periódico Oficial = inteligencia legítima. Mantén esos dos en transparente y tienes producto defensible. La versión opaca es la única que te explota en la cara cuando tu cliente es el gobierno.

---

*ALQUIMIA RELEASE CHECKLIST · 10 junio 2026*
