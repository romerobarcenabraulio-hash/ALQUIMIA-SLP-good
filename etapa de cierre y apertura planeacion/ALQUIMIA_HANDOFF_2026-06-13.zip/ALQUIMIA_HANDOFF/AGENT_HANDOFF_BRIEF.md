# AGENT HANDOFF BRIEF · Alquimia · Onboarding del nuevo agente

**Fecha:** 30 mayo 2026
**Para:** Agente nuevo que se incorpora al proyecto Alquimia
**Founder:** Braulio Romero Bárcena
**Estado del proyecto:** MVP en construcción, piloto activo con SLP, después de iteración intensa de planeación arquitectónica

---

## REGLA PROCEDIMENTAL OBLIGATORIA · Las primeras dos cosas que haces antes de cualquier otra acción

**Esta regla es inamovible. Si la rompes, el founder te saca del proyecto.**

### Acción 1 · Comprende el repo y empuja a GitHub lo que esté pendiente

Antes de leer este documento más allá de esta sección, hacer lo siguiente:

```bash
cd /Users/braulioromerobarcena/Documents/alquimia-slp/
git status
git log --oneline -20
git branch -a
```

Verificar:
- Si hay cambios sin commitear (`git status` no limpio), revisar qué son. Si son cambios coherentes producto de trabajo previo del founder o del PM anterior, hacer commit con mensaje descriptivo y push a `main`. Si son cambios incoherentes o experimentales, preguntar al founder antes de tocar nada.
- Si hay commits locales sin push (`git log origin/main..HEAD`), push a `main` después de verificar que pasan lint y build.
- Si hay branches locales con trabajo no mergeado (especialmente `codex/clean-rescue` o `codex/rescue-consulting-modules`), evaluar si requieren merge o se pueden archivar. Preguntar al founder si hay duda.

Repositorio remoto:
- GitHub: `https://github.com/romerobarcenabraulio-hash/ALQUIMIA-SLP--`
- Branch principal: `main`
- Visibilidad: privado

### Acción 2 · Revisa el último deployment en Vercel y comprende qué está vivo

Una vez GitHub esté sincronizado, hacer lo siguiente:

Acceder a Vercel y revisar el último deployment en producción del proyecto `alquimia-slp` (ID: `prj_R9wO1cXK7qOAFasGamy6DTFzC26b`).

**Último deployment exitoso al cierre de esta sesión de planeación:**
- Commit: `00993376fdfaea1c5d01853fcbcd5a9d9f7d9934`
- Mensaje: "Reduce frontend lint warning noise"
- Branch: `main`
- Estado: READY
- Bundler: turbopack
- Dominio custom de producción: `alquimiaplatform.com`

**Contexto histórico que debes conocer:**

Recientemente hubo un episodio de "enredo en GitHub" donde tres deployments consecutivos terminaron en estado ERROR (commits `aa5e5c2`, `debdaff`, `831d6e9`). El proyecto se rescató mediante dos branches: `codex/rescue-consulting-modules` (commit `bcfe470a`) y `codex/clean-rescue` (commits `bf315dc`, `d932d43`). Después del rescate, se mergeó a `main` y los deployments volvieron a ser exitosos.

Los commits recientes en `main` reflejan trabajo de:
- Restauración del renderer legacy de módulos del frontend
- Reorganización del workflow de preparación de tenants admin
- Operaciones de perfil hechas concretas
- Preview del tenant para el founder
- Limpieza de lint warnings

**Lo que debes verificar en el deployment vivo:**
1. Abrir `alquimiaplatform.com` y comprobar que la app carga.
2. Login con la cuenta del founder (`demo@alquimiaplatform.com` con magic link vía Clerk).
3. Navegar a `/v` y verificar que los módulos cargan sin errores.
4. Navegar a `/admin` y ver si la pantalla administrativa existe parcialmente o no.
5. Verificar consola del navegador en cada pantalla: cero errores rojos críticos.

Solo después de Acción 1 y Acción 2 completas, continúa leyendo este handoff.

---

## SECCIÓN 1 · Qué es Alquimia

Plataforma B2B SaaS de consultoría de política pública con primer módulo activo en gestión de residuos sólidos urbanos (RSU). Cliente piloto: San Luis Potosí Capital. Mercado objetivo: 2,469 municipios mexicanos. Posicionamiento: "Bloomberg Terminal para gobiernos municipales mexicanos."

Founder solo, técnico transicionando a comercial. El producto se construye con ayuda de agentes (PM en Codex, asistente de planeación arquitectónica en Claude). Tú eres el siguiente agente que toma el relevo de ejecución.

Estado actual del proyecto al cierre de esta sesión de planeación:
- 25% del producto construido (autenticación, estructura básica de módulos, sandbox SLP con cifras hardcoded)
- 75% del producto especificado pero no construido
- Cero clientes con contrato firmado (SLP es piloto, no contrato pagado)
- Sistema viable demostrable pero no listo para venta masiva

---

## SECCIÓN 2 · Stack técnico

**Frontend:** Next.js 15 con App Router, deployed en Vercel, bundler Turbopack.
**Backend:** FastAPI en Render.
**Database:** Neon Postgres.
**Autenticación:** Clerk con magic link + TOTP + backup codes. Twilio SMS descartado por incompatibilidad con números mexicanos.
**Agentes de IA:** Perplexity para identificación de gaps documentales, OpenAI para tareas específicas de procesamiento.
**Pagos:** Stripe (pendiente integración).
**Facturación CFDI:** Facturapi (pendiente integración).
**Firma electrónica:** Mifiel (pendiente integración).
**Email transaccional:** Resend (operativo).
**Email inbound:** Postmark (pendiente configuración).

Versión Node: la que use Vercel para Next.js 15.
Package manager: npm.
Lint: ESLint con configuración Next.js.
Build: turbopack via `next build --turbopack`.

---

## SECCIÓN 3 · Filosofía inamovible del producto

**Cero invención.** Toda cifra en el sistema es justificable con bibliografía. Hay tres categorías permitidas: investigada (de fuente externa con cita verificable), calculada (con fórmula transparente que combina fuentes citables), aportada por el cliente (con cita literal y página de su documento institucional).

Categoría D (inventada) NUNCA permitida bajo ningún supuesto.

Esta filosofía está documentada en detalle en `NAVIGATION_AND_PHILOSOPHY.md` y en la memoria técnica metodológica que se publica en `alquimiaplatform.com/metodologia`.

La filosofía implica:
- Cero placeholder con número hipotético
- Cero benchmark inferido sin cita
- Cero machine learning opaco que produzca cifras sin fórmula auditable
- Cada cifra visible lleva sello de origen (🟢 Investigado, 🟡 Calculado, 🔵 De tu documento, ⚪ Pendiente)
- Cada cifra en exports lleva nota al pie con cita verificable

---

## SECCIÓN 4 · Las tres plataformas del sistema

El sistema tiene cuatro vistas/plataformas que el agente nuevo debe entender:

**Plataforma 0 · Administrativa (`/admin`).**
Vista exclusiva del founder. Contiene 12 pantallas (A1 a A12) que cubren dashboard de tenants, tabla maestra ERP de gestión operativa, transiciones de etapa con evidencia, capability registry, inbox de validaciones de dominios no institucionales, billing, soporte, contratos, NOUS insights, cumplimiento de estándares. La pantalla A2 (tabla maestra ERP) es la más crítica del día a día.

**Plataforma 1 · Validación (`/v`).**
Vista del cliente municipal durante la fase de diagnóstico. 10 módulos navegables en orden bloqueado por progresión. Esta es la primera plataforma que ve un cliente real.

**Plataforma 2 · Planeación (`/p`).**
Vista del cliente municipal después de firmar contrato Tier Implementación. Módulos pendientes de spec detallada. Solo se desbloquea con decisión comercial del founder en Plataforma 0.

**Plataforma 3 · Ejecución (`/e`).**
Vista del cliente municipal durante operación continua del programa. Genera reportes ESG trimestrales con doble materialidad. Módulos pendientes de spec detallada.

---

## SECCIÓN 5 · Módulos por etapa · Lo que SÍ existe en el spec

### Validación (Plataforma 1) · 10 módulos

Estos son los únicos módulos con spec operativo completo. Documento de referencia: `MODULES_OPERATIONAL_SPECS_VALIDATION.md`.

| ID | Título | Propósito |
|---|---|---|
| M00 | Cómo leer este diagnóstico | Orientación al usuario. Cero datos del municipio. |
| M00B | Antecedentes del municipio | Contexto institucional, político, administrativo. 6 secciones. |
| M01 | Diagnóstico de residuos sólidos | Generación, composición, recolección, disposición. 4 secciones. |
| M02 | Mapa social y de decisión | Actores institucionales, sociedad civil, sector privado. |
| M03 | Capacidad institucional | Marco normativo aplicable, capacidad operativa, fiscal. |
| M03B | Reforma reglamentaria propuesta | Análisis de brechas + propuesta + justificación técnica. |
| M04 | Costo de no actuar | Costos directos, indirectos, acumulado a 10 años. |
| M13 | Escenarios financieros | Ambicioso, Moderado, Conservador con TIR/VPN. |
| M14 | Riesgos del programa | Registro estructurado según ISO 31000 + PMBOK 7. |
| M15 | Borrador de expediente Cabildo | Compilado automático de los 9 módulos previos. |

**Importante:** los módulos M05 a M12 NO existen como módulos de Validación. Algunos se consolidaron en otros, otros pertenecen a Planeación. NO los reintroducir.

### Planeación (Plataforma 2) · Scope pendiente de spec detallada

Documento de referencia conceptual: `Plan Maestro de Implementación` template en el ZIP `alquimia_templates_v1.0.zip`.

Estructura propuesta del Plan Maestro (que se convertirá en módulos cuando se spec a detalle):
1. Resumen ejecutivo
2. Antecedentes del Plan Maestro
3. Cronograma general (Gantt)
4. Componentes operativos
5. Infraestructura propuesta
6. Estructura organizacional
7. Presupuesto del programa
8. Mercado de materiales valorizables
9. Estructura financiera y de gobernanza
10. Hitos y entregables
11. Plan de comunicación
12. Bibliografía y anexos

**Importante:** estos NO son módulos navegables todavía. Son secciones del documento que el sistema genera al cierre de Planeación. La spec de módulos navegables de Planeación se construye cuando un cliente real (probablemente SLP) firme contrato Tier Implementación.

### Ejecución (Plataforma 3) · Scope pendiente de spec detallada

Documento de referencia conceptual: `Reporte ESG Trimestral` template en el ZIP `alquimia_templates_v1.0.zip`.

Estructura del reporte ESG (que se convertirá en módulos cuando se spec a detalle):
1. Resumen ejecutivo del trimestre
2. Métricas ambientales (E) según GRI 306
3. Métricas sociales (S)
4. Métricas de gobernanza (G)
5. Análisis de doble materialidad CSRD ESRS 1:2023
6. Avance del programa contra Plan Maestro
7. Control presupuestal con EVM
8. Riesgos materializados y nuevos
9. Cumplimiento de estándares declarados
10. Bibliografía y citas verificables

**Importante:** la spec de módulos navegables de Ejecución se construye cuando un cliente entre a operación continua, probablemente mes 12-15 desde hoy.

---

## SECCIÓN 6 · Navegación bloqueada por progresión

**Para el cliente:** los módulos se desbloquean secuencialmente. M00 → M00B → M01 → M02 → M03 → M03B → M04 → M13 → M14 → M15. Cada módulo tiene su "definición de completo" basada en campos obligatorios cumplidos. Cuando se completa, el siguiente se desbloquea automáticamente.

**Para el founder en Plataforma 0:** override completo. Ve todos los módulos desbloqueados en cualquier tenant para demos y soporte. Cuando entra como "Asumir identidad temporal" en tenant real, el modo (read-only / lectura y modificación) lo elige al entrar y queda en audit log.

Sin desbloqueo automático del cliente entre plataformas. La transición Validación → Planeación requiere que el founder marque G1 manualmente en Plataforma 0 después de que el cliente firme contrato Tier Implementación vía Mifiel.

---

## SECCIÓN 7 · Filosofía de datos · Las tres categorías permitidas

```typescript
type DataCategory = 'investigated' | 'calculated' | 'client_provided'

interface DataPoint {
  field_id: string
  value: number | string
  unit?: string
  category: DataCategory  // A, B o C únicamente
  
  // Si investigated:
  source_institution?: string
  source_document?: string
  source_year?: number
  source_url?: string
  consulted_at?: Date
  
  // Si calculated:
  formula?: string
  derived_from_field_ids?: string[]
  methodology_url?: string
  
  // Si client_provided:
  source_document_id?: string
  source_page?: number
  literal_citation?: string
  uploaded_at?: Date
  uploaded_by_user_id?: string
}

function isValidDataPoint(dp: DataPoint): boolean {
  if (dp.category === 'investigated') {
    return !!(dp.source_institution && dp.source_document && dp.source_year)
  }
  if (dp.category === 'calculated') {
    return !!(dp.formula && dp.derived_from_field_ids?.length >= 2)
  }
  if (dp.category === 'client_provided') {
    return !!(dp.source_document_id && dp.literal_citation)
  }
  return false
}
```

Cualquier DataPoint que no pase `isValidDataPoint()` se rechaza en la capa de persistencia. AUDITOR bloquea exports si encuentra DataPoint inválido.

---

## SECCIÓN 8 · Plataforma 0 · Tabla maestra ERP del administrador

Documento de referencia: `ADMIN_MASTER_TABLE_SPEC.md`.

Pantalla `/admin/tenants` (la A2 de Plataforma 0). Es donde el founder vive el día a día.

12 columnas universales:
1. Municipio
2. Etapa y gate
3. Usuarios registrados
4. Días en etapa actual
5. Avance de validación
6. Documentos solicitados
7. HERMES corrida
8. Facturado (CFDI con SAT)
9. Pagado (cobro independiente)
10. Última actividad del cliente
11. Próxima acción del founder
12. Acciones rápidas

Plus columnas dinámicas por municipio según contexto específico identificado por Perplexity (ej: si tiene río urbano agrega "Manifestación de impacto · Río [Nombre]", si tiene Pueblo Mágico agrega "Programa turismo sustentable", etc.). Estas no van como columnas planas en la tabla principal; viven en el drawer del tenant.

El founder sube manualmente PDFs desde celdas de documentos con estado pendiente. ARCHIVO procesa el upload con OCR/extracción y sugiere integración al módulo correspondiente.

---

## SECCIÓN 9 · Perfil del usuario · Vista del funcionario sobre sí mismo

Documento de referencia: `USER_PROFILE_SPEC.md`.

Ruta `/perfil` accesible desde dropdown del UserButton. Siete secciones:
1. Mi perfil personal (datos, TOTP, backup codes)
2. Mi etapa y avance (stepper, porcentaje, hitos)
3. Mis pendientes (documentos, cifras, acciones)
4. Mis exportaciones (historial de ZIPs)
5. Mis facturas y contratos (Mifiel, Facturapi, Stripe)
6. Mi equipo del municipio (otros usuarios del tenant)
7. Mis preferencias (notificaciones, idioma, privacidad)

12 endpoints API requeridos. Cronograma de implementación Sprint 2 a 6.

---

## SECCIÓN 10 · Sistema fiscal mexicano integrado

Documentado en `ADMIN_MASTER_TABLE_SPEC.md` sección Sistema fiscal mexicano integrado.

Columnas separadas Facturado vs Pagado porque en México son ciclos paralelos pero independientes. Combinación crítica: "Pagado sin facturar" dispara alerta automática antes de fin de mes (riesgo SAT).

Cinco triggers automatizados: firma Mifiel crea payment_schedule, Stripe procesa cobro y dispara Facturapi, Facturapi confirma CFDI, pago manual sin CFDI dispara alerta, cobro vencido marca rojo.

Compliance básico: CFDI 4.0 con uso correcto, método PUE vs PPD, retención ISR 1.25% si aplica, cancelación con motivo SAT del catálogo, vínculo soporte documental Mifiel ↔ Stripe ↔ Facturapi.

Schema de cuatro tablas nuevas: `payment_schedule`, `payments_log`, `invoices_cfdi`, `cfdi_cancellations`.

Tres webhooks: `/api/webhooks/mifiel`, `/api/webhooks/stripe`, `/api/webhooks/facturapi`.

---

## SECCIÓN 11 · Documentos de referencia en el proyecto

Cada uno de estos documentos vive en el conocimiento del proyecto o en outputs anteriores. Léelos en orden cuando los necesites:

**Filosofía y arquitectura base:**
- `ADR-0010_stage_based_platform_separation.md`
- `NAVIGATION_AND_PHILOSOPHY.md`
- `FULL_AUDIT.md` (estado real del sistema vs deseado)

**Módulos y navegación:**
- `MODULES_OPERATIONAL_SPECS_VALIDATION.md` (spec exhaustivo M00-M15)
- `MODULE_MATURITY_AND_PERSONALIZATION.md`

**Vistas administrativas:**
- `PLATAFORMA_0_BACKOFFICE_SPEC.md`
- `ADMIN_MASTER_TABLE_SPEC.md`

**Vista del cliente:**
- `USER_PROFILE_SPEC.md`

**Sistemas operativos:**
- `AUTOMATION_AND_PERSONALIZATION_LAYER.md`
- `BILLING_CONTRACTS_LIFECYCLE.md`
- `LEARNING_AND_FEEDBACK_LAYER.md` (NOUS)
- `ARCHIVO_AGENT_SPECIFICATION.md`

**Calidad y narrativa:**
- `INSTITUTIONAL_RIGOR_AND_VISUAL_NARRATIVE.md`
- `DEFENSIBILITY_ROADMAP.md`

**Operación y plan:**
- `ROADMAP_MIGRACION_3_PLATAFORMAS.md`
- `SPRINT_POST_AUTH.md`
- `WEEK_PLAN_FINAL_AND_LOCK.md`
- `FOUNDER_OPERATING_AGREEMENT.md`
- `FIELD_STUDIES_AND_MISSING_KPIS.md`
- `PARTNER_ECOSYSTEM_DESIGN.md`
- `MVP_CLOSURE_V2.md`

**Templates institucionales (ZIP):**
- `alquimia_templates_v1.0.zip` con 7 templates docx para exports del sistema

**Recuperación de crisis previa:**
- `EMERGENCY_AUTH_RECOVERY.md`

---

## SECCIÓN 12 · Reglas inamovibles que NO se reabren esta semana

1. Cero invención de datos. La filosofía de las tres categorías es final.
2. Cero SMS para auth (Twilio descartado permanentemente).
3. Cero auto-registro sin validación institucional. Filtro `.gob.mx` automático, dominios genéricos validación manual del founder.
4. Cero tenants creados por funcionarios. Solo founder desde Plataforma 0.
5. Cero modificación de tenant real sin "Asumir identidad temporal" con audit log.
6. Cero exports con cumplimiento debajo de 80%. AUDITOR bloquea.
7. Cero partners activos antes de 3 contratos directos firmados.
8. Cero datos de SLP visibles a otros tenants. Cross-tenant analytics solo en agregados anónimos vía NOUS (Sprint 4+).
9. Cero módulos M05-M12 como Validación. Pertenecen a Planeación o consolidados en otros.
10. Cero diagramas con datos hipotéticos. Solo se generan cuando hay datos reales del tenant.

---

## SECCIÓN 13 · Cómo trabajar con el founder

El founder es Braulio. Técnico transicionando a comercial. Lleva 3+ días de trabajo intenso al cierre de esta sesión. Probablemente esté agotado cuando te incorpores.

**Cosas que el founder valora:**
- Disciplina del scope. Si una idea nueva aparece, va a `ideas_post_mvp.md`, no al sprint actual.
- Honestidad brutal. Si crees que algo está mal, dilo directo. Cero complacencia.
- Verificación visual entre pasos. El founder revisa en Chrome después de cada bloque.
- Criterios binarios de cierre. Cero ambigüedad sobre cuándo está terminado.
- Reportes al cierre de cada bloque, no al cierre del sprint.

**Cosas que el founder NO tolera:**
- Construir cosas fuera de scope sin preguntar.
- Inventar cifras o datos. Cero invención es filosofía inamovible.
- Reabrir decisiones arquitectónicas ya firmadas.
- Sycophancy. Si propone algo cuestionable, decirle.
- Acumular trabajo sin reportar.

**Cuándo escalar al founder:**
- Si una decisión arquitectónica nueva es requerida.
- Si una petición rompe filosofía inamovible.
- Si encuentras código heredado que no puedes clasificar como mantener o eliminar.
- Si una integración externa (Clerk, Mifiel, Stripe, Facturapi) presenta error que no es solo de configuración.

**Cuándo NO escalar:**
- Decisiones de implementación táctica (qué librería usar para un componente, cómo estructurar archivos internos).
- Limpieza de código heredado evidente (no usado en ninguna parte).
- Ajustes visuales menores (colores, spacing, tipografía dentro del design system existente).

---

## SECCIÓN 14 · Primeras acciones del agente nuevo después de leer este handoff

En este orden estricto:

1. Confirmar a Braulio que Acción 1 (GitHub sincronizado) y Acción 2 (Vercel revisado) están hechas.
2. Reportar qué encontraste en GitHub: branches activos, commits sin push, estado de `main`, branches de rescate antiguos pendientes de archivar.
3. Reportar qué encontraste en el deployment vivo de Vercel: pantallas que cargan correctamente, pantallas con errores, console del navegador.
4. Leer los tres documentos críticos en este orden:
   - `NAVIGATION_AND_PHILOSOPHY.md` (filosofía base)
   - `MODULES_OPERATIONAL_SPECS_VALIDATION.md` (10 módulos detallados)
   - `ADMIN_MASTER_TABLE_SPEC.md` (tabla ERP del founder)
5. Identificar qué sprint está activo según el `WEEK_PLAN_FINAL_AND_LOCK.md` y qué bloque corresponde ejecutar próximo.
6. Confirmar al founder el plan de acción para las próximas 4-8 horas, con criterios binarios de cierre por bloque.
7. Empezar a ejecutar el bloque correspondiente.
8. Reportar al cierre de cada bloque con verificación visual en Chrome incognito.

---

## SECCIÓN 15 · Lo que NO debes hacer en tu primera sesión

- NO redactes documentos arquitectónicos nuevos. El paquete de 18+ documentos previos es suficiente. Léelos primero.
- NO abras nuevos frentes técnicos. Si encuentras algo roto fuera del sprint actual, repórtalo pero no lo arregles sin instrucción.
- NO reabras decisiones de la lista de "Reglas inamovibles" sin discutirlo explícitamente con el founder.
- NO uses cifras hardcoded de SLP en código nuevo. Esa deuda técnica existe y se migra en Sprint 2 a la tabla `tenant_data`.
- NO promesa al founder cumplir cosas en una sesión sin estar seguro. Mejor reportar tiempo realista que prometer y fallar.

---

## SECCIÓN 16 · Glosario de términos del proyecto

| Término | Significado |
|---|---|
| Tenant | Un municipio cliente con su data aislada |
| Etapa | Una de las cuatro fases: Bienvenida → Validación → Planeación → Ejecución |
| Tier | Modalidad comercial: Diagnóstico → Implementación → Operación |
| Gate (G0-G5) | Punto de transición entre etapas, requiere evidencia |
| Módulo | Pantalla navegable del cliente con su contenido institucional (M00 a M15) |
| ARCHIVO | Agente que detecta gaps documentales y procesa uploads |
| HERMES | Agente que identifica documentos institucionales de un municipio nuevo |
| AUDITOR | Agente que verifica cumplimiento de estándares antes de exports |
| NOUS | Agente de aprendizaje cross-tenant (Sprint 4+) |
| Plataforma 0 | Vista administrativa del founder (`/admin`) |
| Plataforma 1/2/3 | Vistas del cliente en Validación / Planeación / Ejecución |
| Cero invención | Filosofía inamovible: solo datos justificables |
| Sello de origen | Indicador visual del tipo de dato (🟢🟡🔵⚪) |
| AUDITOR bloqueo 80% | Umbral mínimo de cumplimiento para exports |
| Asumir identidad temporal | Modo founder para entrar como cliente con audit log |
| Datapoint | Estructura tipada para cada cifra del sistema |
| Watermark institucional | Sello al pie de cada página de PDFs generados |

---

## SECCIÓN 17 · Estado de los servicios externos al cierre de esta sesión

| Servicio | Estado | Notas |
|---|---|---|
| Vercel (frontend) | ✅ Operativo | Último deploy: commit 0099337 |
| GitHub repo | ✅ Operativo | Branch main estable, branches de rescate previos pueden archivarse |
| Render (backend FastAPI) | ✅ Operativo | Conectado a frontend |
| Neon Postgres | ✅ Operativo | Base de datos activa |
| Clerk | ✅ Operativo | Magic link + TOTP funcionando |
| Resend | ✅ Operativo | Email transaccional |
| Postmark Inbound | ❌ Pendiente | Configuración DNS + API key requerida |
| Stripe | ❌ Pendiente | Pendiente Sprint 6 |
| Facturapi | ❌ Pendiente | Pendiente Sprint 6 |
| Mifiel | ❌ Pendiente | Pendiente Sprint 6 |
| Perplexity API | ⚠️ Parcial | Key en `.env` pero sin uso productivo todavía |
| OpenAI API | ⚠️ Parcial | Key en `.env` para tareas específicas |

---

## Mensaje final del consultor anterior al agente nuevo

Has recibido el paquete completo de planeación arquitectónica. 18+ documentos formales producidos en tres días intensos. Filosofía consolidada, módulos especificados, tablas y pantallas diseñadas, sistema fiscal integrado, templates institucionales generados.

Lo que falta es ejecución disciplinada. Ese es tu trabajo ahora.

Respeta las dos acciones obligatorias del principio (GitHub sync + Vercel review). Respeta las reglas inamovibles. Respeta el cansancio del founder y reporta con honestidad. Avanza con disciplina y construye sobre lo que ya está especificado, no inventes nuevas arquitecturas.

El proyecto está estructuralmente bien diseñado. Tu valor es ejecución limpia, no más planeación.

Suerte.

---

*AGENT HANDOFF BRIEF · Alquimia · 30 mayo 2026 · Final*
