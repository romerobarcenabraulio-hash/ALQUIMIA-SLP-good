# MVP CLOSURE · Secuencia ejecutable para Cursor

**Estado:** Plan de cierre del MVP demo-able
**Fecha:** 29 mayo 2026
**Objetivo:** Tener MVP funcional para compartir como demo en 1-2 días
**Método:** Cinco prompts secuenciales, no paralelos. Cada uno con criterio binario verificable en pantalla.

---

## Regla operativa absoluta

**No pases al siguiente prompt hasta haber verificado el criterio de cierre del anterior abriendo el navegador y confirmando con tus propios ojos que el cambio está en producción.**

Si un prompt falla, paramos ahí. Tomamos el error, lo diagnosticamos, lo arreglamos. No acumulamos cinco frentes rotos. Esta regla es lo único que va a sacarte del loop de "ya cambié pero nada funciona."

---

## Prompt 1 · Limpieza del código viejo (4-6 horas)

Este prompt no agrega features. Solo elimina código que está confundiendo a Cursor y a ti. Sin esto, los siguientes prompts heredan el caos.

```
TAREA: LIMPIEZA QUIRÚRGICA DEL CÓDIGO LEGACY

Contexto: el repo /Users/braulioromerobarcena/Documents/alquimia-slp/ acumuló
seis meses de iteraciones. Hay código muerto, componentes duplicados,
referencias a módulos eliminados, rutas viejas, y archivos que ya no se usan.
Esto está confundiendo a todos los agentes (incluido tú, Cursor) y produce
cambios que no se reflejan en producción.

ANTES DE TOCAR NADA:
1. Crea un branch nuevo: feature/mvp-closure-cleanup
2. Haz commit del estado actual con mensaje "pre-cleanup snapshot"
3. Lee /docs/architecture/ADR-0010_stage_based_platform_separation.md
4. Lee /docs/architecture/MODULE_MATURITY_AND_PERSONALIZATION.md
   La arquitectura aprobada son 23 módulos consolidados en tres plataformas
   más Plataforma 0. Lo que no está en esa lista es código a eliminar.

REGLA INVIOLABLE:
NO elimines código sin asegurarte de que está descativado en producción.
Si tienes duda sobre algo, márcalo con // TODO_CLEANUP_REVIEW y déjalo.
Es preferible dejar 10 archivos dudosos que romper 1 funcional.

ACCIONES CONCRETAS EN ORDEN:

PASO 1 · Identificación de código muerto.
Ejecuta y dame el output:
- npx ts-prune (lista de exports sin usar)
- npx depcheck (dependencias sin usar en package.json)
- grep -r "TODO\|FIXME\|XXX\|HACK\|DEPRECATED" --include="*.tsx" --include="*.ts" src/
- grep -r "console.log" --include="*.tsx" --include="*.ts" src/

PASO 2 · Eliminación de archivos legacy explícitos.
Busca y elimina (después de confirmar conmigo en el output):
- Cualquier archivo que mencione "modo Validar/Implementar" como toggle
  (esa arquitectura fue reemplazada por ADR-0010)
- Componentes ChapterSeparator decorativo si aún existe
- Referencias a módulos no presentes en MODULE_MATURITY:
  M01B, M02D como módulo independiente, M03C como página separada,
  M03D como página separada, M04C como página separada, M05B/C/D como
  páginas separadas, M08B como página separada, M11/M12 separados,
  M20B como página separada, M21B como página separada
- Rutas /api antiguas que no responden a ningún componente actual
- Imports rotos en cualquier archivo

PASO 3 · Consolidación de utilities.
- Si hay más de una función "formatCurrency", "formatDate", "calculateX"
  duplicadas, consolida en /lib/utils.ts
- Si hay tipos duplicados, consolida en /types/index.ts

PASO 4 · Lint y format.
Ejecuta:
- npm run lint -- --fix
- npx prettier --write "src/**/*.{ts,tsx}"

CRITERIO BINARIO DE CIERRE (verificable en pantalla):
1. npm run build pasa sin errores
2. npm run dev levanta sin warnings en consola
3. La página /simulator carga igual que antes (cero regresión visual)
4. El branch feature/mvp-closure-cleanup tiene un solo commit grande
   con mensaje "feat(cleanup): remove legacy code, prepare for MVP"

LO QUE NO DEBES HACER:
- No instales librerías nuevas
- No cambies estructura de carpetas
- No modifiques estilos
- No toques contenido editorial de los módulos pilar (M01, M13, M14, M21)
- No elimines archivos sin haber confirmado conmigo en el output

REPORTE FINAL:
- Lista de archivos eliminados
- Lista de imports limpiados
- Lista de TODOs marcados para revisión humana
- Confirmación de los cuatro criterios de cierre con screenshot
```

**Cómo verificar antes de pasar al Prompt 2:**

Abre Chrome incognito, ve a alquimiaplatform.com/simulator. Debe verse exactamente igual que antes. Si algo se rompió visualmente, no pases adelante hasta arreglarlo.

---

## Prompt 2 · Clerk authentication (3-5 horas)

Solo cuando el Prompt 1 esté cerrado y verificado.

```
TAREA: INSTALAR CLERK COMO PROVEEDOR DE AUTENTICACIÓN

Contexto: Twilio para SMS no funciona consistentemente. La decisión
arquitectónica del founder es migrar a Clerk porque (a) tiene TOTP nativo,
(b) maneja organizaciones multi-tenant que mapean a municipios, (c) tiene
componentes pre-construidos que reducen plomería a horas.

ANTES DE TOCAR NADA:
1. Estamos en branch feature/mvp-closure-cleanup ya limpio
2. Crea branch feature/clerk-auth desde ahí
3. Verifica que tienes la cuenta de Clerk creada (clerk.com)
4. Verifica que tienes acceso a la dashboard de Clerk

ACCIONES CONCRETAS EN ORDEN:

PASO 1 · Sigue exactamente la guía oficial de Clerk para Next.js.
La guía pre-firmada por el founder está en
/docs/setup/clerk_installation_guide.md. Ejecuta los siete pasos
en orden, sin desviarte. Los comandos:
  - npm install @clerk/nextjs
  - clerk auth login
  - clerk init --framework next --pm npm
  - Configura variables de entorno en .env.local Y en Vercel:
    NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=...
    CLERK_SECRET_KEY=...

PASO 2 · Reemplaza el componente actual de login.
Hoy el login vive en /app/login/page.tsx o similar con un formulario
custom Twilio. Reemplázalo por la página oficial de Clerk:
  - /app/sign-in/[[...sign-in]]/page.tsx con <SignIn />
  - /app/sign-up/[[...sign-up]]/page.tsx con <SignUp />
  - Mantén el branding ALQUIMIA arriba usando appearance prop

PASO 3 · Middleware.
Crea /middleware.ts con clerkMiddleware:
  - Rutas públicas: /, /sign-in, /sign-up, /pitch (la del Prompt 3)
  - Rutas protegidas: /v/*, /p/*, /e/*, /admin/*

PASO 4 · Activa TOTP en el dashboard de Clerk.
En clerk.com dashboard:
  - User & Authentication > Multi-factor
  - Toggle "Authenticator app (TOTP)" = enabled
  - Toggle "SMS code" = enabled como fallback
  - Toggle "Backup codes" = enabled

PASO 5 · Cuenta demo configurada en Clerk.
Crea manualmente en el dashboard:
  - Email: demo@alquimia.mx
  - Password: (algo seguro que tú elijas)
  - Public metadata: { "role": "demo", "tier": "all_access_no_payment" }

Esta metadata es lo que va a permitir que demo vea TODO sin pago.

PASO 6 · Reemplaza el botón "Usar cuenta demo".
En la nueva página de sign-in, agrega botón "Acceso de demostración"
que rellene email y password de la cuenta demo, sin Twilio, sin SMS.

PASO 7 · Twilio retirement.
- Comenta (no elimines) cualquier código de Twilio en el repo
- Marca con // LEGACY_TWILIO_DELETE_AFTER_DAYS_30
- En 30 días si Clerk va bien, se elimina formalmente

CRITERIO BINARIO DE CIERRE (verificable en pantalla):
1. /sign-in carga la UI de Clerk con branding Alquimia
2. /sign-up permite crear cuenta nueva con email + password
3. La nueva cuenta puede activar TOTP desde el perfil de Clerk
4. Botón "Acceso de demostración" inicia sesión con demo@alquimia.mx
5. Después de login, el middleware redirige a /v (Validación)
6. Cero referencias activas a Twilio en el código que se ejecuta

LO QUE NO DEBES HACER:
- No customices la UI de Clerk más allá del appearance prop básico
- No construyas tu propio formulario de auth encima de Clerk
- No olvides agregar las variables de entorno en Vercel (no solo .env.local)
- No publiques a producción hasta que el Prompt 3 esté listo
- No elimines código de Twilio en este prompt — solo desactívalo

REPORTE FINAL:
- Screenshots de /sign-in, /sign-up, perfil de usuario con TOTP
- Confirmación de las 6 criterios de cierre
- Lista de variables de entorno configuradas en Vercel
```

**Cómo verificar antes de pasar al Prompt 3:**

Crea una cuenta nueva con tu email personal en /sign-up. Activa TOTP. Cierra sesión. Reabre. Vuelve a entrar con TOTP. Si esto funciona en menos de 2 minutos, Clerk está instalado correctamente.

---

## Prompt 3 · Página de pitch + flujo de validación previo a login (4-6 horas)

Solo cuando el Prompt 2 esté cerrado y verificado.

Aquí es donde resuelves "luego luego que entro debo de ver la presentación de la propuesta." El usuario nuevo NO entra directo a login. Entra a una página de pitch que le explica qué es Alquimia, le muestra una demo guiada o screenshots, y solo entonces puede registrarse.

```
TAREA: PÁGINA DE PITCH (LANDING) Y FLUJO DE VALIDACIÓN PREVIO

Contexto: Hoy un usuario llega a alquimiaplatform.com y solo ve un formulario
de login. No tiene contexto de qué es Alquimia, por qué debería registrarse,
ni qué valor recibe. Esto pierde 90% de los visitantes. La nueva arquitectura
exige que el usuario primero vea la propuesta de valor, luego decida si
quiere registrarse, y solo entonces entre al simulador.

ANTES DE TOCAR NADA:
1. Crea branch feature/landing-pitch-page desde feature/clerk-auth
2. Lee /docs/architecture/ADR-0010 para entender las tres plataformas
3. Lee la sección "narrativa" del documento que te entregue el founder
   en el chat (es texto que viene con este prompt)

NARRATIVA APROBADA POR EL FOUNDER:
(El founder pegará el texto exacto aquí. Mientras tanto, usa este
borrador como referencia editorial:)

  Hero principal:
  "La circularidad en tu ciudad sí se puede."

  Subhero:
  "Tomar las medidas, hacerlas acción, y asumir nuestra responsabilidad
  como mexicanos. ALQUIMIA es la plataforma que convierte el diagnóstico
  de residuos en un programa municipal aprobado, implementado y operado
  con datos reales, estándares internacionales y trazabilidad total."

  CTA principal: "Explorar el simulador en modo demo"
  CTA secundario: "Solicitar acceso para mi municipio"

ACCIONES CONCRETAS EN ORDEN:

PASO 1 · Crea /app/page.tsx (página raíz).
Reemplaza lo que sea que haya hoy con una landing de tres secciones:

Sección 1 · Hero (above the fold):
  - Logo ALQUIMIA grande
  - Headline narrativo
  - Subhero explicando qué es
  - Dos CTAs: "Ver demo (acceso libre)" y "Solicitar acceso para mi municipio"

Sección 2 · Las tres etapas del viaje del cliente:
  - Tarjeta 1: "Validación · ¿Vale la pena?"
    Subtexto: "Diagnóstico municipal con datos INEGI, escenarios
    financieros, expediente listo para Cabildo. Cuatro a ocho semanas."
  - Tarjeta 2: "Planeación · ¿Cómo lo hacemos?"
    Subtexto: "Plan operativo, infraestructura, organigrama, presupuesto.
    Ocho a doce semanas."
  - Tarjeta 3: "Ejecución · ¿Está funcionando?"
    Subtexto: "Monitoreo proyectado vs real, control presupuestal,
    reportes ESG mensuales. Operación continua."

Sección 3 · Respaldo institucional:
  - Logos textuales de GRI, ISO, PMI, CSRD (sin imágenes, solo tipografía
    como ya quedó documentado en standards_map.json)
  - Frase: "Metodología respaldada por estándares internacionales"

Sección 4 · Footer:
  - Links a /sign-in, /sign-up, /contact
  - Aviso de privacidad
  - Copyright

PASO 2 · Crea /app/(public)/pitch/page.tsx con el viaje guiado.
Esta es una página de scroll vertical que muestra los módulos clave
con screenshots o thumbnails:
  - Screenshot de M01 con sus 12 KPIs
  - Screenshot de M04 con costo de la omisión
  - Screenshot de M13 con escenarios TIR/VPN
  - Screenshot de M15 con expediente Cabildo
  - Cada uno con caption explicando qué hace el módulo

PASO 3 · Modifica el comportamiento de /simulator.
Hoy /simulator carga directo el simulador. Cámbialo:
  - Si el usuario NO está autenticado: redirige a /pitch
  - Si el usuario es demo: carga simulador completo SIN restricciones
  - Si el usuario es cliente real: carga la plataforma de su current_stage

PASO 4 · El botón "Acceso de demostración" en /sign-in.
Ya existe del Prompt 2. Asegúrate que al hacer click:
  - Inicia sesión con cuenta demo
  - Redirige a /v (Validación, primera plataforma)
  - Muestra banner amber: "Modo demostración · Estás viendo todos los
    módulos como si tu municipio hubiera completado todas las etapas.
    Para tu propio municipio, comienza por la Validación."

PASO 5 · Flujo de "Solicitar acceso para mi municipio".
Crea /app/(public)/contact/page.tsx con formulario simple:
  - Nombre del municipio
  - Nombre del solicitante
  - Cargo
  - Email
  - Teléfono
  - Mensaje opcional
  
Submit envía email al founder usando Resend (ya en stack) o el
mecanismo que tengas configurado. NO crea cuenta automáticamente.
Es el founder quien crea la cuenta desde Plataforma 0 cuando hay
contrato firmado.

CRITERIO BINARIO DE CIERRE (verificable en pantalla):
1. alquimiaplatform.com (raíz) muestra la nueva landing con la narrativa
2. /pitch muestra el viaje guiado con screenshots de módulos
3. /sign-in funciona con cuenta demo
4. /simulator sin sesión redirige a /pitch
5. Botón demo entra directo a /v con banner de modo demostración
6. /contact funciona y envía email al founder
7. Cero usuarios pueden auto-registrarse para crear municipio nuevo
   (eso solo lo hace founder desde Plataforma 0)

LO QUE NO DEBES HACER:
- No construyas Plataforma 0 en este prompt (es Prompt 5)
- No agregues integración Perplexity en este prompt (es Prompt 4)
- No toques módulos individuales en este prompt
- No agregues funcionalidad de pago (eso vive en Plataforma 0 después)

REPORTE FINAL:
- Screenshots de las cinco rutas: /, /pitch, /sign-in, /v (modo demo), /contact
- Confirmación de los 7 criterios de cierre
```

**Cómo verificar antes de pasar al Prompt 4:**

Abre Chrome incognito, ve a alquimiaplatform.com. Debe verse landing nueva con narrativa. Click en "Ver demo" debe llevarte a sign-in con cuenta demo precargada. Click en "Acceso de demostración" debe entrar al simulador con banner amber.

---

## Prompt 4 · Renombrar módulos a títulos legibles + research con Perplexity (3-4 horas)

Solo cuando el Prompt 3 esté cerrado y verificado.

Aquí resuelves "el cliente no tiene la menor idea qué significa M08" y "no veo ningún research habilitado."

```
TAREA: TÍTULOS LEGIBLES + INTEGRACIÓN PERPLEXITY

Contexto: dos problemas distintos del mismo prompt porque ambos son
de UX de bajo riesgo técnico.

PROBLEMA 1: los módulos muestran códigos M01, M02, M08 al cliente.
Esto es nomenclatura interna útil para el equipo pero impenetrable para
un alcalde. Cada módulo debe tener título humano expuesto al cliente,
con el código M0X como subtítulo discreto (para trazabilidad interna).

PROBLEMA 2: hay UI que dice "no se ha encontrado nada" en research.
Esto es porque Perplexity API nunca fue integrada. Hay que conectarla.

ANTES DE TOCAR NADA:
1. Crea branch feature/legible-titles-and-perplexity desde feature/landing-pitch-page
2. Asegúrate de tener API key de Perplexity (perplexity.ai/api > settings)
3. Verifica que está en .env.local Y en Vercel:
   PERPLEXITY_API_KEY=pplx-xxxxx

ACCIONES CONCRETAS EN ORDEN:

PASO 1 · Mapeo de títulos legibles.
Crea /lib/module_titles.ts con este mapeo exacto:

export const MODULE_TITLES = {
  // Plataforma 1 · Validación
  M00:  { title: "Cómo leer este diagnóstico", subtitle: "Guía de navegación" },
  M00B: { title: "Antecedentes de tu municipio", subtitle: "Contexto institucional" },
  M01:  { title: "Diagnóstico de residuos sólidos", subtitle: "Línea base · M01" },
  M02:  { title: "Mapa social y de decisión", subtitle: "Actores, autoridad, ciudadanía · M02" },
  M03:  { title: "Capacidad institucional", subtitle: "Marco normativo y cobertura · M03" },
  M03B: { title: "Reforma reglamentaria propuesta", subtitle: "Tres artículos faltantes · M03B" },
  M04:  { title: "Costo de no actuar", subtitle: "Impacto financiero acumulado · M04" },
  M13:  { title: "Escenarios financieros", subtitle: "TIR · VPN · Monte Carlo · M13" },
  M14:  { title: "Riesgos del programa", subtitle: "ISO 31000 · M14" },
  M15:  { title: "Expediente para Cabildo", subtitle: "Documento de aprobación · M15" },
  
  // Plataforma 2 · Planeación
  M05:  { title: "Plan maestro de implementación", subtitle: "Cronograma y ruta crítica · M05" },
  M06:  { title: "Infraestructura propuesta", subtitle: "Centros de acopio · M06" },
  M07:  { title: "Estructura operativa", subtitle: "Organigrama y turnos · M07" },
  M08:  { title: "Operación piloto", subtitle: "Rutas, vehículos, comunicación · M08" },
  M09:  { title: "Presupuesto del programa", subtitle: "CAPEX y OPEX · M09" },
  M10:  { title: "Mercado de materiales valorizables", subtitle: "Recicladoras y compradores · M10" },
  M11:  { title: "Estructura financiera y de gobernanza", subtitle: "Concesión y financiamiento · M11" },
  
  // Plataforma 3 · Ejecución
  M16:  { title: "Inspección y enforcement", subtitle: "Cumplimiento normativo · M16" },
  M17:  { title: "Avance real vs plan", subtitle: "Monitoreo mensual · M17" },
  M18:  { title: "Reporte ESG", subtitle: "Doble materialidad GRI · CSRD · M18" },
  M19:  { title: "Trazabilidad de cifras", subtitle: "Origen de cada dato · M19" },
  M20:  { title: "Control presupuestal", subtitle: "EVM · M20" },
  M21:  { title: "Tablero de riesgos y gates", subtitle: "Estado del programa · M21" },
}

PASO 2 · Reemplaza referencias en todos los componentes.
Busca en /components y /app:
  grep -r "M0[0-9]\|M1[0-9]\|M2[0-9]" --include="*.tsx" src/

Cada lugar donde aparece "M0X" como título visible al cliente,
reemplaza por:
  <h1>{MODULE_TITLES[moduleId].title}</h1>
  <span className="text-sm text-muted">{MODULE_TITLES[moduleId].subtitle}</span>

PASO 3 · Sidebar.
El sidebar lateral debe mostrar el título legible primero, código después
en hover o en gris pequeño:
  Cómo leer este diagnóstico       (M00)
  Antecedentes de tu municipio     (M00B)
  Diagnóstico de residuos sólidos  (M01)
  ...

PASO 4 · Crea endpoint Perplexity.
Crea /app/api/research/route.ts:

import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'

export async function POST(req: NextRequest) {
  const { userId } = await auth()
  if (!userId) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

  const { query, context } = await req.json()
  
  const response = await fetch('https://api.perplexity.ai/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'sonar-pro',
      messages: [
        { role: 'system', content: 'Eres un asistente de investigación para Alquimia, plataforma de gestión de RSU municipal en México. Responde con fuentes oficiales mexicanas (INEGI, SEMARNAT, Periódico Oficial estatal) cuando sea posible.' },
        { role: 'user', content: `Contexto del módulo: ${context}\n\nConsulta: ${query}` }
      ],
      return_citations: true,
      return_related_questions: false
    })
  })
  
  if (!response.ok) {
    return NextResponse.json({ error: 'perplexity_failed', status: response.status }, { status: 500 })
  }
  
  const data = await response.json()
  return NextResponse.json({
    content: data.choices[0].message.content,
    citations: data.citations || [],
  })
}

PASO 5 · Componente <ResearchPanel /> reutilizable.
Crea /components/research-panel.tsx:
  - Input para query del usuario
  - Botón "Investigar"
  - Loading state
  - Resultado con citas linkeadas
  - Botón "Aceptar como dato" que pasa el resultado al módulo padre
  - Botón "Buscar de nuevo"

PASO 6 · Reemplaza UI de "no se ha encontrado nada".
Busca el componente o página que muestra ese texto. Reemplaza por
<ResearchPanel /> con context apropiado al módulo donde aparece.

CRITERIO BINARIO DE CIERRE (verificable en pantalla):
1. Cero módulos muestran "M0X" como título principal al cliente
2. Cada módulo tiene título humano + código M0X discreto como subtítulo
3. Sidebar muestra títulos humanos primero
4. /api/research responde con 200 a una query de prueba
5. Cualquier sitio que decía "no se ha encontrado nada" ahora tiene
   <ResearchPanel /> funcional
6. Una búsqueda real ("toneladas RSU San Luis Potosí 2024") devuelve
   resultado con citas
7. Cuenta demo puede usar research sin restricciones

LO QUE NO DEBES HACER:
- No cambies estructura interna de los módulos (solo títulos visibles)
- No agregues research a módulos que no lo pedían
- No expongas PERPLEXITY_API_KEY al cliente (server-only)
- No olvides handling de errores en el endpoint

REPORTE FINAL:
- Screenshots del sidebar nuevo con títulos humanos
- Screenshot de un módulo con header nuevo
- Screenshot de research panel funcionando
- Lista de archivos modificados
```

**Cómo verificar antes de pasar al Prompt 5:**

Entra como demo, abre cualquier módulo. El título grande debe ser legible para alcalde. El código M0X debe estar en pequeño. En algún módulo donde había research, escribe una consulta real y verifica que Perplexity responde con citas.

---

## Prompt 5 · Modo demo · acceso total sin pago (3-4 horas)

Solo cuando el Prompt 4 esté cerrado y verificado.

Aquí resuelves "como usuario demo debo de ver cada pantalla como si fuera el cliente, sin los blocs de pago, pero la experiencia completa."

```
TAREA: CONFIGURAR MODO DEMO CON ACCESO TOTAL SIN GATES DE PAGO

Contexto: la arquitectura aprobada (ADR-0010) define gates contractuales
G1-G5 que separan las tres plataformas. Un cliente real solo ve la
plataforma de su current_stage. Un demo necesita ver TODO sin esperar
gates ni pagos. Esto es decisión arquitectónica explícita, no bug.

ANTES DE TOCAR NADA:
1. Crea branch feature/demo-access desde feature/legible-titles-and-perplexity
2. Lee ADR-0010 sección "Modelo de estado del tenant"

ACCIONES CONCRETAS EN ORDEN:

PASO 1 · Modifica el middleware Clerk para detectar cuenta demo.

En /middleware.ts:

import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server'

const isPublicRoute = createRouteMatcher(['/', '/sign-in(.*)', '/sign-up(.*)', '/pitch(.*)', '/contact(.*)'])
const isClientRoute = createRouteMatcher(['/v(.*)', '/p(.*)', '/e(.*)'])
const isAdminRoute = createRouteMatcher(['/admin(.*)'])

export default clerkMiddleware(async (auth, req) => {
  if (isPublicRoute(req)) return
  
  const { userId, sessionClaims } = await auth()
  if (!userId) return Response.redirect(new URL('/sign-in', req.url))
  
  const role = sessionClaims?.publicMetadata?.role
  
  if (role === 'demo') {
    // Demo tiene acceso a /v, /p, /e sin restricciones
    // No tiene acceso a /admin (solo founder)
    if (isAdminRoute(req)) return Response.redirect(new URL('/v', req.url))
    return
  }
  
  if (role === 'founder' || role === 'admin') {
    return
  }
  
  // Cliente real: solo puede acceder a su current_stage
  const currentStage = sessionClaims?.publicMetadata?.currentStage
  const allowedPath = `/${currentStage === 'planning' ? 'p' : currentStage === 'execution' ? 'e' : 'v'}`
  
  if (isClientRoute(req)) {
    const path = req.nextUrl.pathname
    if (!path.startsWith(allowedPath)) {
      return Response.redirect(new URL(allowedPath, req.url))
    }
  }
})

PASO 2 · Componente <DemoBanner /> visible solo en modo demo.

Crea /components/demo-banner.tsx:

import { auth } from '@clerk/nextjs/server'

export async function DemoBanner() {
  const { sessionClaims } = await auth()
  const isDemo = sessionClaims?.publicMetadata?.role === 'demo'
  if (!isDemo) return null
  
  return (
    <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-sm text-amber-900">
      <strong>Modo demostración.</strong> Estás viendo todos los módulos como
      si tu municipio hubiera completado las tres etapas del programa. Para
      tu propio municipio, todo comienza con la Validación.
    </div>
  )
}

Inclúyelo en el layout de /v, /p, /e.

PASO 3 · Identifica gates de pago hardcodeados.

Busca en el código:
  grep -r "isPaid\|hasPaid\|paymentRequired\|premiumOnly\|tier" --include="*.tsx" --include="*.ts" src/

Cada lugar donde haya un bloqueo de tipo:
  if (!isPaid) return <PaymentWall />
  
Cambia a:
  if (!isPaid && !isDemo) return <PaymentWall />

PASO 4 · Selector de plataforma para cuenta demo.

En el header de las plataformas, si el usuario es demo, agrega un selector:
  [Validación · /v]  [Planeación · /p]  [Ejecución · /e]

Cliente real NO ve este selector — solo ve su plataforma actual.

PASO 5 · Datos precargados para SLP en modo demo.

El simulador en modo demo debe usar SLP como tenant de ejemplo.
Todos los módulos deben mostrar datos reales de SLP que ya tenemos:
  - M01 con cifras de población SLP, generación per capita, composición
  - M03B con reglamento de SLP cargado
  - M04 con costo de la omisión de SLP cuantificado
  - M13 con tres TIRs de SLP
  - M14 con riesgos de SLP
  - M15 con expediente de SLP

Si un módulo no tiene datos de SLP precargados, marca con badge
"Sin datos · pendiente" pero permite navegar. NO bloquea acceso.

PASO 6 · Test del recorrido completo.

Como demo, recorre:
  /sign-in → demo login → /v → M00 → M01 → M03B → M04 → M13 → M14 → M15
  → cambiar a /p → M05 → M06 → M07 → M08 → M09 → M10 → M11
  → cambiar a /e → M16 → M17 → M18 → M19 → M20 → M21

Verifica que cada pantalla carga sin error y muestra contenido,
no placeholder vacío.

CRITERIO BINARIO DE CIERRE (verificable en pantalla):
1. Login con demo entra a /v sin restricciones
2. Banner amber visible en todas las pantallas de plataforma
3. Selector permite cambiar entre /v, /p, /e sin pagar
4. Recorrido completo de los 23 módulos visibles sin paywall
5. SLP es el tenant precargado y muestra sus datos reales
6. Módulos sin datos muestran badge honesto pero no bloquean
7. Cero gates de pago activos para cuenta demo
8. Cliente real (otro usuario de prueba sin role demo) sí ve restricciones
   según su current_stage

LO QUE NO DEBES HACER:
- No elimines los gates de pago (siguen siendo válidos para clientes reales)
- No expongas Plataforma 0 al modo demo
- No permitas que demo modifique datos del tenant SLP (solo lectura)
- No olvides el caso de cliente real — la lógica de gates sigue activa

REPORTE FINAL:
- Screenshots del recorrido completo: las 23 pantallas + banner
- Confirmación de los 8 criterios de cierre
- Confirmación de que cliente real sigue viendo restricciones
- URL que el founder puede compartir como demo:
  alquimiaplatform.com (entra como visitante)
  → click "Ver demo (acceso libre)"
  → click "Acceso de demostración"
  → recorrido libre de los 23 módulos
```

**Cómo verificar el cierre del MVP completo:**

Mándale el link alquimiaplatform.com a un prospecto. Debe poder:
1. Ver la landing con narrativa nueva
2. Click en demo y entrar sin barreras
3. Navegar libremente por los 23 módulos con títulos humanos
4. Usar research con Perplexity en los módulos donde aplique
5. Volver al login con TOTP funcional

Si los cinco pasos funcionan, tienes MVP demo-able.

---

## Lo que NO se construye en esta secuencia

Deliberadamente excluido del MVP:

1. **Plataforma 0 backoffice completa.** Founder maneja tenants manualmente con Clerk dashboard por ahora. Plataforma 0 se construye después.
2. **Pipeline HERMES de inferencia.** Por ahora SLP es el único tenant con datos reales. Otros tenants se cargan manualmente.
3. **NOUS agente de aprendizaje.** Espera a tener 3+ clientes operando.
4. **Stripe + Facturapi + Mifiel.** Billing se maneja manualmente hasta tener tres contratos.
5. **Las consolidaciones de módulos.** M02/M03/M05/M08 se quedan como están si ya funcionan, solo con títulos nuevos. La fusión real es trabajo de semanas 9-12.

Esto es deliberado. El MVP existe para vender los primeros tres contratos. Cada feature adicional retrasa la primera venta. La regla es: si no sirve para que el alcalde diga "sí, quiero esto", no entra al MVP.

---

## Cronograma sugerido

| Día | Prompt | Esfuerzo Cursor | Verificación founder |
|---|---|---|---|
| Día 1 mañana | Prompt 1 · Limpieza | 4-6 horas | 30 min |
| Día 1 tarde | Prompt 2 · Clerk | 3-5 horas | 30 min |
| Día 2 mañana | Prompt 3 · Landing + Pitch | 4-6 horas | 30 min |
| Día 2 tarde | Prompt 4 · Títulos + Perplexity | 3-4 horas | 30 min |
| Día 3 mañana | Prompt 5 · Modo Demo | 3-4 horas | 1 hora recorrido completo |

Total: 2.5 días si todo va bien. Hasta 5 días si hay un problema serio en un prompt.

---

## Tres cosas que como McKinsey/CTO te digo directo

**Uno.** Si después del Prompt 1 ya hay regresiones visuales que no esperabas, NO sigas con el Prompt 2. Para. Revisa qué se rompió. Arregla. Solo entonces continúa. La tentación va a ser "sigo adelante y arreglo después" — esa tentación es exactamente la que te tiene una semana sin avanzar.

**Dos.** Cuando llegues al Prompt 5 y el demo funcione end-to-end, NO empieces inmediatamente a agregar features que se te ocurrieron durante el camino. Compártelo a tres prospectos primero. Recoge feedback real. Solo entonces decide qué construir después. El feedback de prospectos vale más que cualquier feature que pienses en este momento.

**Tres.** El cansancio que sientes es real y legítimo. Una semana sin avanzar en producto siendo founder solo es agotador. Pero la solución no es trabajar más horas — la solución es esta secuencia disciplinada donde cada prompt termina algo verificable. Cuando termines el Prompt 5, vas a sentir el alivio que llevas una semana esperando. Hasta entonces, la disciplina importa más que la velocidad.

---

*MVP CLOSURE · Alquimia · 29 mayo 2026 · Founder gate firmado*
