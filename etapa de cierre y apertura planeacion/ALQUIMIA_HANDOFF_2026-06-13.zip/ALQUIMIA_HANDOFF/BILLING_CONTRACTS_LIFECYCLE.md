# BILLING · CONTRATOS · LIFECYCLE COMMERCIAL — Sistema operativo comercial de Alquimia

**Estado:** Propuesto · Pendiente de firma del founder
**Fecha:** 28 mayo 2026
**Dependencias:** ADR-0010 firmado, PLATAFORMA_0_BACKOFFICE_SPEC aceptado, AUTOMATION_AND_PERSONALIZATION_LAYER aceptado
**Construye:** KRONOS (integraciones), POLIS (UI A8 + A10), AUDITOR (trazabilidad fiscal)

---

## 1 · Propósito

Este documento define cómo Alquimia cobra, factura, contrata y administra el ciclo de vida comercial de cada cliente. Sin este sistema, el founder hace todo a mano y la empresa no escala más allá de los primeros tres clientes.

La premisa central: el cliente municipal no es estático. Cambia de pagador según la etapa del programa RSU. Cambia de obligaciones contractuales según el gate cerrado. Cambia de tier comercial según las capabilities activas. El sistema modela esa variabilidad como dato, no como excepción manual.

---

## 2 · Principios no negociables

**Pagador variable, contrato evolutivo.** Un tenant tiene un `payer_entity` activo en cada momento. La entidad puede cambiar al cerrar un gate. El sistema preserva el histórico completo de pagadores por tenant.

**Habilitación por pago confirmado.** Las capabilities se activan cuando Stripe confirma el pago, no cuando el cliente promete pagar. Excepción: gate de revisión del founder durante los primeros 20 clientes.

**Fiscalmente impecable.** Cada peso cobrado genera CFDI con complemento de pago según corresponda. Facturapi automatiza esto vinculado a Stripe.

**Contractos firmados antes de habilitar.** Sin contrato firmado en Mifiel, ninguna capability se activa, ningún módulo se desbloquea, ningún acceso se otorga.

**Política sensible con gobierno.** Suspender servicio a un municipio por mora es decisión humana del founder, nunca automática. El sistema escala alertas; el founder decide.

---

## 3 · Arquitectura del sistema comercial

Tres componentes externos integrados a Plataforma 0:

| Componente | Función | Costo | Tiempo de integración |
|---|---|---|---|
| **Stripe** | Cobro (tarjeta, SPEI, OXXO) y gestión de suscripciones | 3.6% + 3 MXN por transacción | 1 semana |
| **Facturapi** | Emisión automática de CFDI 4.0 + complementos de pago | $4.50-9.50 MXN por factura emitida | 3-5 días |
| **Mifiel** | Firma electrónica avanzada con e.firma del SAT | ~$60 MXN por documento firmado · Plan Intermediate API $71,000 MXN/año | 1 semana |

Sin estos tres, el sistema comercial no opera. Total de integración: 2-3 semanas de KRONOS si se construye en serie, 1.5 semanas en paralelo.

---

## 4 · Modelo de payer variable

### 4.1 Schema

```typescript
interface PayerEntity {
  id: string
  type: "municipio" | "concesionario" | "fondo_estatal" | "fondo_federal" | "banca_multilateral" | "privado_otro"
  razon_social: string
  rfc: string  // RFC válido del SAT
  regimen_fiscal: string  // según catálogo SAT (601, 612, 605, etc.)
  domicilio_fiscal: {
    codigo_postal: string
    estado: string
    municipio: string
  }
  contacto_administrativo: {
    nombre: string
    puesto: string
    email: string
    telefono: string
  }
  tipo_persona: "fisica" | "moral"
  uso_cfdi_default: string  // G03 Gastos en general (típico), I06 Equipos cómputo
  metodo_pago_preferido: "PPD" | "PUE"
  forma_pago_preferida: "03_transferencia" | "01_efectivo" | "04_tarjeta"
  dias_credito: number  // típico 30 para privados, 60-120 para gobierno
  observaciones_facturacion: string  // notas específicas del SAT del cliente
}

interface TenantPayerHistory {
  tenant_id: string
  payer_entries: [
    {
      payer_id: string
      payer_porcentaje: number  // suma de todos los payers activos = 100
      fecha_inicio: timestamp
      fecha_fin: timestamp | null  // null = activo
      gate_trigger: "G1" | "G2" | "G3" | "manual" | null
      contrato_id: string  // referencia al documento Mifiel
      capabilities_cubiertas: string[]
      monto_mensual_mxn: number
    }
  ]
}
```

### 4.2 Las cuatro configuraciones de payer

**Configuración A · Municipio paga 100%.**
- Aplica durante Validación y Planeación por default.
- Aplica durante Ejecución si el contrato así se estructuró.
- Payer: Tesorería Municipal o equivalente.
- RFC del municipio: el oficial del Ayuntamiento.
- Régimen fiscal: 603 (Personas Morales con Fines no Lucrativos) o 605 (Sueldos y Salarios e Ingresos Asimilados a Salarios) según municipio.
- Uso CFDI: G03 Gastos en general.

**Configuración B · Concesionario paga 100%.**
- Aplica durante Ejecución cuando la adenda de concesión incluyó a Alquimia como sistema obligatorio.
- Payer: Empresa concesionaria privada.
- RFC: el de la empresa.
- Régimen fiscal: 601 (General de Personas Morales).
- Uso CFDI: G03 Gastos en general.

**Configuración C · Pago híbrido municipio + concesionario.**
- Aplica durante Ejecución cuando se negoció reparto.
- Dos `payer_entries` activos simultáneos con porcentajes que suman 100.
- **Dos facturas separadas, una por payer** — esto es lo correcto fiscalmente y deja rastro contable limpio.

**Configuración D · Pago contra ingresos de valorización.**
- Aplica solo durante Ejecución madura (mes 12+) cuando hay flujo demostrado de ingresos por valorización.
- Alquimia cobra 1-3% del valor mensual valorizado.
- Pagador: quien recibe los ingresos por valorización (típicamente el concesionario).
- Variable mes a mes según operación real.
- Esta configuración es la más "Bloomberg" pero requiere alta confianza con el cliente.

### 4.3 Transición de payer al cerrar gate

Al cerrar G1, G2 o G3, el sistema pregunta al founder:

```
Gate G1 cerrado para tenant SLP-capital.
Capabilities a activar para Planeación: M05, M06, M07, M08, M09, M10, M11.
Monto mensual estimado: $35,000 MXN.

¿Continúa el mismo payer (Tesorería Municipal SLP) o entra payer adicional?
[ ] Mismo payer
[ ] Nuevo payer
[ ] Configuración híbrida
```

Founder decide manualmente. No automatizado. Una novación contractual sale a Mifiel cuando el founder confirma la transición.

---

## 5 · El módulo A10 · Gestión contractual en Plataforma 0

Modulo nuevo dedicado, separado de A2 Tenants. Justifica modulación porque la gestión cruza tenants.

### 5.1 Pestañas del módulo A10

**A10.1 · Plantillas.** Repositorio de plantillas legales por tier:
- Plantilla contrato Tier Diagnóstico (firma electrónica avanzada)
- Plantilla contrato Tier Implementación (firma electrónica avanzada + anexos técnicos)
- Plantilla contrato Tier Operación Completa (firma electrónica + integración a adenda de concesión)
- Plantilla adenda de concesión donde Alquimia se incluye (notarización completa)
- Plantilla aceptación mensual de reporte ESG (firma electrónica simple del Director de Servicios Públicos)
- Plantilla aceptación de términos de uso iniciales (click-to-sign)
- Plantilla NDA bilateral
- Plantilla autorización de uso de datos para inclusión en analytics agregada (opt-in)

Cada plantilla tiene variables placeholder que se llenan automáticamente con datos del tenant: `{{municipio_nombre}}`, `{{presidente_municipal}}`, `{{rfc_municipio}}`, etc.

**A10.2 · Contratos por tenant.** Por cada tenant, listado de contratos:
- Pendientes de envío
- Enviados a Mifiel, pendientes de firma
- Firmados completos
- Próximos a vencer
- Vencidos sin renovación
- Históricos archivados

Cada contrato muestra: tier al que aplica, payer asignado, gates cubiertos, vigencia, partes firmantes, link a documento firmado en Mifiel, evidencia NOM-151.

**A10.3 · Anexos legales reservados.** Cada contrato lleva tres anexos obligatorios:

- **Anexo A · No réplica de metodología.** El municipio no puede contratar a un consultor para replicar Alquimia con la metodología que aprendió usando la plataforma. Penalidad documentada.
- **Anexo B · Confidencialidad mutua.** Lo que Alquimia aprende del municipio no se comparte sin consentimiento explícito. Lo que el municipio aprende no se comparte con otros consultores de Alquimia.
- **Anexo C · Propiedad intelectual reservada.** Código, modelos, algoritmos de inferencia, prompts de agentes, Capability Registry son propiedad exclusiva de Alquimia. El municipio licencia uso, no recibe propiedad.

**A10.4 · Estado de firmas en tiempo real.** Webhook de Mifiel actualiza estado: documento creado, enviado, abierto por firmante, firmado por firmante, firmado por todos, completo, expirado, cancelado.

**A10.5 · Repositorio fedatado.** Cada contrato firmado se almacena con:
- Documento original PDF
- Constancia NOM-151 que da fecha cierta
- Hash del documento
- Lista de firmantes con timestamps
- Audit trail completo de Mifiel

Para los contratos notarizados (adenda de concesión), se sube el PDF escaneado de la versión notarizada física + metadata del notario.

### 5.2 Flujo de firma estándar

```
1. Founder en Plataforma 0 selecciona tenant + tier + payer.
2. Sistema genera contrato desde plantilla con variables llenas.
3. Founder revisa, ajusta si necesario, aprueba.
4. Sistema envía a Mifiel API.
5. Mifiel envía email a firmantes con link.
6. Firmantes acceden, autentican con e.firma SAT, firman.
7. Mifiel notifica webhook a Plataforma 0.
8. Sistema marca contrato como firmado.
9. Capability Registry actualiza `default_active: true` para capabilities del tier comprado.
10. Cliente recibe email automático con confirmación y credenciales si es primer contrato.
```

Tiempo total típico: minutos a 48 horas según rapidez de firma del cliente.

---

## 6 · Mapeo de formalización contractual por gate

| Momento | Documento | Tipo de firma | Plataforma |
|---|---|---|---|
| Cliente registra interés | Términos de Servicio iniciales | Firma electrónica simple (click-to-sign) | Plataforma 0 propia |
| Pre-Validación | Contrato Tier Diagnóstico | Firma electrónica avanzada (e.firma Síndico) | Mifiel |
| Pre-Validación | NDA bilateral | Firma electrónica avanzada | Mifiel |
| Pre-Validación | Autorización analytics agregada | Opt-in firma simple | Plataforma 0 propia |
| Cierre G1 | Novación a Tier Implementación | Firma electrónica avanzada + anexos técnicos | Mifiel |
| Cierre G1 (paralelo) | Aceptación del expediente Cabildo | Firma electrónica avanzada | Mifiel |
| Cierre G2 | Novación a Tier Operación Completa | Firma electrónica avanzada multi-partes | Mifiel |
| **Cierre G2 (crítico)** | **Adenda de concesión incluyendo Alquimia** | **Notarización completa con notario público** | **Físico + escaneo en A10** |
| Mensual durante Ejecución | Aceptación de reporte ESG | Firma electrónica simple Director Servicios Públicos | Plataforma 0 propia |
| Activación de capability adicional | Adenda de capability (rutas, tesorería, etc.) | Firma electrónica avanzada | Mifiel |

La adenda de concesión notarizada es la pieza más crítica del modelo. Es lo que asegura tu posición para los 15-20 años de concesión y sobrevive a cambios de administración municipal. Sin notarización, el alcalde siguiente puede argumentar que no respetará el acuerdo del anterior.

---

## 7 · Flujo end-to-end Stripe + Facturapi + Mifiel

### 7.1 Primer cobro de un cliente nuevo

```
1. Contrato firmado en Mifiel (paso anterior, ya completado).
2. Sistema crea Customer en Stripe con datos del payer.
3. Sistema crea Customer en Facturapi con datos fiscales del payer.
4. Sistema crea Subscription o Invoice en Stripe según el tier.
5. Stripe envía link de pago al cliente: tarjeta, SPEI, OXXO.
6. Cliente realiza pago.
7. Stripe confirma pago vía webhook.
8. Plataforma 0 recibe webhook, marca payment como confirmado.
9. Sistema dispara llamada a Facturapi para emitir CFDI:
   - Si pago en una sola exhibición: factura PUE con UUID inmediato.
   - Si pago a plazos: factura PPD con monto total + complemento de pago vinculado.
10. Facturapi emite CFDI, lo timbra con PAC, devuelve UUID y XML.
11. Plataforma 0 envía CFDI al cliente por email automáticamente.
12. Si el contrato lo requiere (gate de revisión founder primeros 20 clientes):
    - Founder recibe alerta en Plataforma 0.
    - Founder tiene 24 horas para aprobar activación.
    - Si no aprueba, capabilities NO se activan automáticamente.
13. Capability Registry actualiza para el tenant según tier comprado.
14. Cliente recibe email con confirmación de activación y acceso.
```

### 7.2 Cobros recurrentes mensuales

```
1. Día 1 del mes: Stripe genera invoice automática según Subscription.
2. Cliente paga (o no).
3. Si paga: ciclo 7-14 del flujo anterior se ejecuta.
4. Si NO paga: ciclo de mora se activa (sección siguiente).
```

### 7.3 Pagos diferidos (típico con gobierno)

Municipios pagan 60-120 días post-factura. El flujo se ajusta:

```
1. Día 1 del mes: Sistema emite factura PPD por Facturapi.
2. Factura se envía al cliente con fecha de vencimiento estimada (90 días).
3. Capabilities siguen activas (el contrato cubre el periodo aunque el pago llegue tarde).
4. Cliente paga en día 60, 90, 120, etc.
5. Cuando pago llega: Stripe lo captura.
6. Sistema dispara complemento de pago en Facturapi dentro de 5 días naturales del mes siguiente.
7. Si pago se retrasa más de 120 días: ciclo de mora se activa.
```

---

## 8 · Ciclo de mora con clientes municipales

Política sensible. El sistema escala alertas; el founder decide acciones.

| Días de mora | Acción del sistema | Estado tenant | Acceso del cliente |
|---|---|---|---|
| 1-7 | Recordatorio WhatsApp + email al contacto administrativo del payer | `current` | Completo |
| 8-15 | Alerta formal al payer + copia al founder | `payment_pending` | Completo |
| 16-30 | Alerta escalada al founder con resumen del caso | `payment_overdue` | Completo, banner de aviso |
| 31-60 | Módulos de Plataforma 3 Ejecución pasan a read-only. M16-M21 ven pero no editan. Plataforma 1 y 2 siguen accesibles. | `degraded` | Limitado |
| 61-90 | Suspensión preventiva. Tenant entra en estado `suspended` con accesos a A1 histórico solo. Founder decide próximos pasos. | `suspended` | Solo lectura histórica |
| 91+ | **Decisión humana del founder.** El sistema NO corta nunca automáticamente con gobierno. Posibilidades: negociación de plan de pagos, cancelación del contrato, recurso jurídico. | Founder decide | Founder decide |

**Política política:** la implicación reputacional de "Alquimia cortó el servicio al municipio X por no pagar" es seria. Por eso día 91+ es siempre founder gate. Casos típicos donde aplicar paciencia:
- Cambio de administración municipal en proceso (esperar transición).
- Disputa administrativa interna del cliente sobre validez del contrato (clarificar primero).
- Crisis presupuestal estatal afectando al municipio (negociar plan).

---

## 9 · Manejo de IVA y retenciones

Servicios profesionales en México tienen reglas específicas que el sistema debe respetar:

**IVA.** Servicios profesionales son gravados al 16%. Toda factura incluye IVA trasladado.

**Retención ISR.** Si el cliente es persona moral del régimen general (Configuración A municipio, B concesionario, C híbrido), debe retener 1.25% de ISR sobre el monto de la factura. El sistema:
- Calcula automáticamente la retención según RFC del payer.
- Emite factura con retención reflejada.
- Cliente paga monto neto.
- Cliente reporta retención al SAT mensualmente.

**Retención IVA.** Personas morales pueden retener 2/3 partes del IVA si así lo establece el contrato. Configurable por payer.

Facturapi maneja toda la mecánica fiscal correcta. Plataforma 0 solo configura los parámetros del payer.

---

## 10 · Casos de uso operativos

### 10.1 Querétaro firma contrato Tier Diagnóstico

```
Día 1, 09:00. Founder y Síndico de Querétaro acuerdan términos.
Día 1, 10:00. Founder en Plataforma 0 crea tenant Querétaro con tres campos.
Día 1, 10:15. Pipeline de inferencia inicial completa (15 min).
Día 1, 10:30. Founder crea contrato Tier Diagnóstico en A10:
   - Plantilla seleccionada.
   - Payer: Tesorería Municipal Querétaro.
   - Variables llenas automáticamente con datos del tenant.
   - Anexos A, B, C precargados.
Día 1, 10:45. Founder revisa, ajusta cláusula específica negociada, aprueba.
Día 1, 11:00. Sistema envía a Mifiel. Email al Síndico.
Día 1, 14:00. Síndico abre, firma con e.firma del SAT.
Día 1, 14:05. Webhook Mifiel notifica firma completa.
Día 1, 14:10. Sistema crea Stripe Customer + Facturapi Customer.
Día 1, 14:15. Sistema envía link de pago al cliente.
Día 1+15. Cliente paga vía SPEI (típico gobierno).
Día 16. Stripe captura pago, webhook a Plataforma 0.
Día 16, +5 min. Facturapi emite CFDI PUE, lo envía al cliente.
Día 16, +6 min. Capabilities Tier Diagnóstico activadas para Querétaro.
Día 16, +7 min. Cliente recibe email con credenciales y acceso.
Día 16, +10 min. Cliente entra por primera vez y ve diagnóstico preliminar de su programa RSU.
```

Tiempo total desde acuerdo verbal a cliente operando: 16 días, dominado por tiempo de pago del cliente, no por proceso técnico.

### 10.2 SLP cierra G2 y entra concesionario como payer híbrido

```
Día 1. Gate G2 cerrado por founder en Plataforma 0 con evidencia (adenda firmada y notarizada).
Día 1. Sistema pregunta al founder: ¿payer continúa o cambia?
Día 1. Founder selecciona: configuración C híbrida 60% municipio, 40% concesionario.
Día 1. Sistema genera novación de contrato para Tesorería SLP.
Día 1. Sistema genera contrato nuevo para concesionario.
Día 2-7. Ambas partes firman en Mifiel.
Día 8. Capability Registry actualiza para SLP:
   - Capabilities Tier Operación Completa activas.
   - Dos PayerEntries activos simultáneos.
Día 8. Sistema configura Stripe para emitir dos facturas mensuales separadas.
```

### 10.3 Mora de 45 días con municipio

```
Día 1-7: alertas WhatsApp al contacto administrativo de la Tesorería.
Día 8: founder revisa caso, decide enviar alerta formal por email con copia al Síndico.
Día 15: founder llama personalmente al Tesorero.
Día 30: caso escalado, módulos de Ejecución pasan a read-only automáticamente.
Día 35: cliente paga.
Día 35+5min: capabilities se reactivan completas.
Día 35+10min: Facturapi emite complemento de pago.
```

---

## 11 · Criterios binarios de cierre

El sistema comercial está cerrado cuando se cumplen:

1. Stripe integrado con webhook funcional a Plataforma 0.
2. Facturapi integrado emitiendo CFDI 4.0 automáticamente.
3. Mifiel integrado con API y widget embebido en A10.
4. Módulo A10 funcional con sus cinco pestañas.
5. Modelo de payer variable implementado con `TenantPayerHistory`.
6. Las cuatro configuraciones de payer (A, B, C, D) probadas con tenants de prueba.
7. Ciclo de mora con sus seis niveles automatizado hasta día 60, manual día 61+.
8. Flujo end-to-end probado: contrato firmado → pago confirmado → CFDI emitido → capabilities activadas → cliente operando.
9. Tres anexos legales (A no-réplica, B confidencialidad, C propiedad intelectual) en cada plantilla de contrato.
10. Manejo correcto de IVA + retenciones ISR + retenciones IVA según régimen del payer.
11. Cero pagos confirmados sin CFDI emitido dentro de los plazos del SAT.
12. Cero capabilities activadas sin contrato firmado correspondiente.

Sin los doce criterios, el sistema no está cerrado.

---

## 12 · Implementación en el roadmap

Esta capa se integra al roadmap del ADR-0010 sin agregar semanas si las integraciones corren en paralelo a otras fases.

| Fase del ADR-0010 | Trabajo de billing/contratos a integrar |
|---|---|
| Fase 1 (Plataforma 0 MVP) | A2 Tenants ya incluye datos del payer básico. A8 Billing en versión simple. |
| Fase 2 (Backend tenant) | Schemas `PayerEntity`, `TenantPayerHistory`, integración con Capability Registry. |
| Fase 3 (Frontend routing) | Banner de mora en plataformas-cliente cuando `current_stage = "degraded"`. |
| **Fase nueva 2.5 (paralelo a Fase 2)** | **Integración Stripe + Facturapi + Mifiel. 2-3 semanas KRONOS.** |
| **Fase nueva 3.5 (paralelo a Fase 3)** | **Módulo A10 frontend completo. 2-3 semanas POLIS.** |
| Fase 6 (Personalización granular) | Cada tenant incluye sus payers reales en su expediente. |
| Fase 7 (Aceptación final) | AUDITOR verifica los 12 criterios de la sección 11. |

Trabajo total adicional: 4-5 semanas si las dos fases nuevas corren en paralelo a las existentes. Si corren en serie, agrega 4-5 semanas al roadmap total.

**Recomendación operativa:** correr en paralelo. KRONOS tiene capacidad para las integraciones mientras POLIS termina el routing. POLIS hace A10 mientras consolida módulos en Fase 5. No agrega semanas al cronograma del ADR-0010.

---

## 13 · Gates humanos del founder para esta capa

**Gate uno.** Aprobar los tres proveedores externos (Stripe, Facturapi, Mifiel) y firmar sus contratos comerciales.

**Gate dos.** Aprobar las plantillas de contrato base (Tier Diagnóstico, Tier Implementación, Tier Operación Completa) revisadas por abogado mexicano especializado en derecho administrativo y contratos de servicios profesionales con gobierno.

**Gate tres.** Aprobar los tres anexos legales (A, B, C) revisados por abogado especializado en propiedad intelectual.

**Gate cuatro.** Probar el flujo end-to-end con un cliente de prueba interno antes de exponerlo al primer cliente real.

**Gate cinco.** Aceptar primera factura emitida y CFDI correctamente timbrado antes de declarar la capa cerrada.

---

## 14 · Riesgos operativos

**Riesgo uno: Facturapi falla en emitir CFDI dentro del plazo.** Cinco días naturales del mes siguiente al pago es el plazo del SAT. Si Facturapi falla, multa del SAT. Mitigación: alertas automáticas día 3 y 4 si CFDI pendiente. Failover manual: emisión directa en portal del SAT.

**Riesgo dos: cliente disputa CFDI emitido.** Cliente argumenta que el monto, concepto o fecha están incorrectos. Mitigación: cancelación de CFDI con motivo de cancelación correcto según catálogo SAT (01 errores, 02 no se realizó la operación, etc.) y reemisión correcta dentro del mismo periodo.

**Riesgo tres: Mifiel está caído cuando se necesita firmar urgente.** Mitigación: contrato alternativo de respaldo con segundo proveedor (Weetrust o ContractMaker) configurable como failover.

**Riesgo cuatro: cambio de RFC del payer durante el contrato.** El municipio rara vez cambia RFC pero el concesionario puede cambiarse. Mitigación: schema `PayerEntity` permite versiones; cuando cambia RFC se crea nuevo registro y el histórico se preserva.

**Riesgo cinco: cliente paga con cuenta no asociada a su RFC.** Esto causa problemas fiscales para el cliente. Mitigación: instrucciones claras en facturas y comunicación.

**Riesgo seis: el municipio quiere addenda comercial específica que requiere ajuste a las plantillas estándar.** Mitigación: cada plantilla tiene secciones marcadas como "negociables" y secciones marcadas como "inviolables". Las inviolables son los tres anexos legales y las cláusulas de propiedad intelectual.

**Riesgo siete: gobierno cambia ley de adquisiciones del estado.** Mitigación: monitoreo de Periódicos Oficiales estatales. Cuando cambia, las plantillas se actualizan.

---

## 15 · Métricas comerciales en A1 Dashboard

El dashboard de portafolio agrega métricas comerciales nuevas:

- MRR total (Monthly Recurring Revenue).
- ARR proyectado (Annual Recurring Revenue × 12).
- Pipeline de contratos en firma (Mifiel pendientes).
- Pipeline de pagos esperados (Facturas PPD vencidas próximas).
- Cobranza efectiva (pagos confirmados ÷ facturas emitidas).
- Tiempo promedio de pago por cliente.
- Net Revenue Retention proyectado (capabilities activadas vs base mes anterior).
- Churn (clientes que cancelan o suspenden por mora >90 días).

Estos son los números que el founder vigila para evaluar si el modelo comercial está funcionando.

---

## 16 · Documentos relacionados

- `ADR-0010_stage_based_platform_separation.md` — estado del tenant
- `PLATAFORMA_0_BACKOFFICE_SPEC.md` — A2 Tenants, A8 Billing existentes
- `AUTOMATION_AND_PERSONALIZATION_LAYER.md` — cómo Querétaro ve diagnóstico al firmar
- `MODULE_MATURITY_AND_PERSONALIZATION.md` — schemas que se llenan con datos del tenant
- `capability_registry.json` — qué se activa al confirmar pago

---

## 17 · Aprobación

```
[ ] Founder
[ ] SUPREME architectural review
[ ] KRONOS technical feasibility — integraciones Stripe/Facturapi/Mifiel
[ ] POLIS UI module A10 specification
[ ] AUDITOR fiscal compliance check
[ ] Abogado externo · revisión plantillas legales
```

Las seis firmas. Sin ellas, la capa comercial no entra a producción.

---

*BILLING · CONTRATOS · LIFECYCLE COMMERCIAL · Alquimia · 28 mayo 2026*
