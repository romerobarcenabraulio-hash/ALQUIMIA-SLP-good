# SPRINT POST-AUTH · Selector de tenant, switcher admin/cliente, módulo de justificación, revisión visual

**Estado:** Founder ya entra con Clerk · pendiente experiencia operativa completa
**Fecha:** 30 mayo 2026
**Objetivo:** Founder puede simular experiencia de cliente con cambio de municipio + acceso admin + visual limpio
**Tiempo estimado:** 4-6 horas de trabajo de PM
**No es:** documento arquitectónico · No agregar features nuevas · No expandir scope

---

## Reglas inviolables

1. NO agregues features nuevas fuera de lo listado.
2. NO toques flujo de auth (ya funciona).
3. NO modifiques narrativa de módulos.
4. Cada bloque se valida antes de pasar al siguiente.
5. Si algo falla, reportar al founder antes de improvisar.

---

## Bloque 1 · Switcher admin/cliente para founder · 60-90 minutos

**Contexto.** Founder tiene cuenta `demo@alquimiaplatform.com` con role founder en Clerk. Hoy entra y va directo a la plataforma del cliente. Necesita poder cambiar entre vista administrativa y vista de cliente desde el header.

**Implementación:**

Crea componente `/components/view-switcher.tsx`:

```typescript
'use client'
import { useUser } from '@clerk/nextjs'
import { useRouter, usePathname } from 'next/navigation'
import { useState } from 'react'

export function ViewSwitcher() {
  const { user } = useUser()
  const router = useRouter()
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  
  const role = user?.publicMetadata?.role as string
  if (role !== 'founder' && role !== 'admin') return null
  
  const currentView = pathname?.startsWith('/admin') ? 'admin' : 'client'
  
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="text-sm px-3 py-1 border border-border-subtle rounded">
        Vista: {currentView === 'admin' ? 'Administrativa' : 'Cliente'} ⌄
      </button>
      {open && (
        <div className="absolute right-0 mt-1 w-64 bg-bg-primary border border-border-subtle rounded shadow-md z-50">
          <button onClick={() => { router.push('/admin'); setOpen(false) }}
            className="w-full text-left px-4 py-2 hover:bg-bg-secondary">
            Vista administrativa
          </button>
          <div className="border-t border-border-subtle px-4 py-2 text-xs text-text-tertiary">
            Ver como cliente:
          </div>
          <button onClick={() => { router.push('/v?tenant=municipio-demo'); setOpen(false) }}
            className="w-full text-left px-4 py-2 hover:bg-bg-secondary">
            Municipio Demo (sandbox)
          </button>
          <button onClick={() => { router.push('/v?tenant=slp-capital'); setOpen(false) }}
            className="w-full text-left px-4 py-2 hover:bg-bg-secondary">
            San Luis Potosí Capital
          </button>
        </div>
      )}
    </div>
  )
}
```

Inclúyelo en `/components/header.tsx` o equivalente, lado derecho junto al UserButton.

**Criterio binario:** Founder loggeado ve botón "Vista: [actual] ⌄" en header. Click abre menú con opciones. Click en cada opción redirige correctamente.

---

## Bloque 2 · Sandbox Municipio Demo precargado · 90-120 minutos

**Contexto.** Para que founder pueda simular experiencia cliente sin tocar datos reales de SLP, necesita tenant ficticio precargado con datos realistas pero inventados.

**Implementación:**

Crear seed script `/scripts/seed-demo-tenant.ts`:

```typescript
import { db } from '@/lib/db'

async function seedMunicipioDemo() {
  await db.tenants.upsert({
    where: { id: 'municipio-demo' },
    update: {},
    create: {
      id: 'municipio-demo',
      municipio: { nombre: 'Municipio Demo', estado: 'Estado Demo', inegi_clave: 'DEMO-001' },
      current_stage: 'validation',
      tier_comercial: 'diagnostico',
      tenant_status: 'official', // sin watermark
      data_marked_as_demo: true,
      visible_only_to_roles: ['founder', 'admin'],
      created_at: new Date(),
    }
  })
  
  // Precarga datos realistas pero ficticios
  await db.tenant_data.upsert({
    where: { tenant_id: 'municipio-demo' },
    update: {},
    create: {
      tenant_id: 'municipio-demo',
      poblacion: { value: 425000, confidence: 'verified_official', source: 'Datos de ejemplo' },
      generacion_per_capita: { value: 0.85, confidence: 'inferred_high', unit: 'kg/dia' },
      composicion: {
        organicos: 45, papel_carton: 18, plasticos: 12,
        vidrio: 4, metales: 3, otros: 18,
        confidence: 'inferred_medium'
      },
      costo_omision_10_anos: { value: 230000000, unit: 'MXN', confidence: 'inferred_medium' },
      presidente: { nombre: 'María Hernández', partido: 'Demo', periodo: '2024-2027' },
      reglamento_vigente: { titulo: 'Reglamento Demo de Limpia', publicado: '2018-03-15' },
    }
  })
}

seedMunicipioDemo().catch(console.error)
```

Ejecuta: `npm run db:seed-demo`

**Criterio binario:** Founder navega a `/v?tenant=municipio-demo`, ve M01 con cifras del Municipio Demo, M04 con costo de omisión, M00B con presidente ficticio. Banner discreto: "Estás viendo Municipio Demo · datos de ejemplo."

---

## Bloque 3 · Restituir módulo de Justificación Técnica como sub-sección de M03B · 60-90 minutos

**Contexto.** El módulo de "justificación técnica de los adendos" existía antes en otra versión del producto. Debe restituirse como sub-sección de M03B (Reforma reglamentaria propuesta), no como módulo independiente.

**Implementación:**

En el archivo del módulo M03B (`/app/v/m03b/page.tsx` o equivalente):

1. Mantén la sección actual de "Propuesta de los tres artículos faltantes."
2. Justo debajo, agrega nueva sección:

```tsx
<section className="mt-12 border-t border-border-subtle pt-12">
  <h2 className="text-2xl font-serif text-text-primary mb-2">
    Justificación técnica de los adendos
  </h2>
  <p className="text-sm text-text-secondary mb-8">
    Por qué cada artículo propuesto cierra una brecha específica del marco vigente
  </p>
  
  <JustificacionTecnicaAdendos moduleId="M03B" tenantId={tenantId} />
</section>
```

Crea componente `/components/justificacion-tecnica-adendos.tsx`. Si existe versión legacy en el repo (busca con `grep -r "justificacion.*adend\|justificacion.*tecnic" --include="*.tsx" src/`), reutiliza esa lógica. Si no existe, créala con estructura:

- Para cada artículo propuesto, una tarjeta con:
  - Texto del artículo propuesto
  - "Brecha que cierra" (referencia a LGPGIR o ley estatal)
  - "Precedente en otros municipios"
  - "Riesgo si no se reforma"

**Criterio binario:** M03B muestra ambas secciones (Propuesta + Justificación) en orden correcto. Justificación visible debajo de Propuesta. Cero módulo separado de Justificación.

---

## Bloque 4 · Revisión visual de módulos pilar · 90-120 minutos

**Contexto.** Founder reporta dos problemas visuales recurrentes: textos sin centrar donde deberían estarlo, y cuadros (borders) innecesarios alrededor de bloques de texto.

**Acciones:**

1. Audita módulos pilar (M01, M04, M13, M14, M21) buscando:

```bash
grep -rn "className=.*border.*\(border-2\|border-4\|rounded-lg.*border\)" src/app/v src/app/p src/app/e --include="*.tsx"
```

2. Para cada match encontrado, evalúa:
- Si el border NO añade jerarquía visual (separa secciones que de otro modo se confundirían), elimínalo.
- Si el border es decorativo, elimínalo.
- Si el border es informativo (banner amber, tarjeta de KPI), consérvalo.

3. Para textos centrados:

```bash
grep -rn "text-center\|text-left\|text-right" src/app/v --include="*.tsx"
```

Revisa cada caso:
- Títulos principales H1, H2 de módulo: centrados está bien si el bloque entero está centrado.
- Párrafos de body: NUNCA centrados. Siempre alineados izquierda.
- Cifras grandes (KPIs): centradas dentro de su contenedor está bien.
- Tablas y datos: alineación según naturaleza del dato (números a la derecha, texto izquierda).

4. Auditoría tipográfica:

```bash
grep -rn "text-shadow\|gradient.*text" src/ --include="*.tsx" --include="*.css"
```

Cualquier text-shadow o gradiente en tipografía: eliminar. Estos son patrones de UI poco serio que dañan credibilidad institucional.

**Criterio binario:** Founder revisa M01, M04, M13, M14, M21 después del cambio. Reporta cero borders innecesarios y cero textos mal alineados.

---

## Bloque 5 · Verificación de diagramas existentes · 30-60 minutos

**Contexto.** Founder reporta que no ve los diagramas que se mencionaron en el documento de rigor institucional. Verificar qué está implementado y qué falta.

**Acciones:**

1. Buscar en el repo:

```bash
grep -rn "Sankey\|recharts\|d3\|chart" src/components --include="*.tsx"
grep -rn "<svg" src/components --include="*.tsx"
ls -la public/diagrams 2>/dev/null || echo "Carpeta no existe"
```

2. Reportar al founder:
- Cuántos componentes de gráficas existen
- Cuántos diagramas estáticos SVG existen en `/public/diagrams`
- En qué módulos se renderizan actualmente

3. NO implementar diagramas nuevos en este sprint. Solo inventariar.

Los cinco diagramas críticos especificados en `INSTITUTIONAL_RIGOR_AND_VISUAL_NARRATIVE.md` (M01 flujo Sankey, M04 árbol de decisión, M13 comparativo escenarios, M14 matriz de riesgos, M21 Gantt) son trabajo de Sprint 2 dedicado, no de este bloque.

**Criterio binario:** Reporte enviado al founder con inventario actual. Cero implementación nueva en este bloque.

---

## Bloque 6 · Smoke test final · 30 minutos

**Contexto.** Antes de cerrar este sprint, verificación end-to-end de la experiencia del founder.

**Acciones (founder ejecuta, PM acompaña):**

1. Founder cierra sesión, vuelve a entrar con `demo@alquimiaplatform.com`
2. Verifica: ve el switcher en header
3. Click switcher → "Vista administrativa" → debe ir a `/admin`
4. Click switcher → "Municipio Demo" → debe ir a `/v` con datos del demo
5. Navega M01, M03B, M04, M13, M14, M15 dentro de Municipio Demo
6. Verifica que M03B tiene Justificación Técnica como sub-sección
7. Verifica que cero borders innecesarios visibles
8. Cierra sesión, intenta entrar con email genérico (gmail) → debe rebotar a /pendiente-validacion (esto verifica que el filtro institucional sigue funcionando)

**Criterio binario:** los 8 puntos pasan sin errores. Si alguno falla, identifica cuál y reporta.

---

## Reporte final al founder

Después de cerrar los 6 bloques:

1. Captura de cada paso del smoke test
2. Lista de archivos modificados
3. Lista de bloques completados / con errores
4. Tiempo real consumido vs estimado
5. Pendientes detectados para sprint siguiente

---

*SPRINT POST-AUTH · Alquimia · 30 mayo 2026*
