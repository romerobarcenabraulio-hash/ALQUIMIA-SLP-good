# 01 · ALQUIMIA · STATE OF THE SYSTEM (Día 0)

**Fecha:** 13 junio 2026
**Para:** founder (vibe coding solo estos ~10 días) + futuros 1-2 programadores
**Propósito:** foto honesta de lo que EXISTE hoy, verificada contra el deployment real. No es la visión; es el punto de partida.

---

## Regla de lectura

Este documento dice lo que hay, no lo que queremos. Lo que queremos está en los documentos 03-05. Si algo aquí dice "no existe", es trabajo por hacer, no una crítica.

---

## Stack confirmado en producción

| Capa | Tecnología | Estado |
|---|---|---|
| Frontend | Next.js 15, Turbopack | ✅ deploy READY en Vercel |
| Backend | FastAPI (Python) | ✅ en Render |
| DB | Neon Postgres | ✅ activa |
| Cache | Redis | ✅ (Sprint 19, distributed cache con fallback in-memory) |
| Auth | Clerk magic link + TOTP | ✅ |
| Auth bridge | Clerk → backend JWT (`/auth/clerk-exchange`) | ✅ (commit c592588) |
| Email | Resend | ✅ transaccional |
| Error monitoring | Sentry (frontend) | ⚠️ shipped, verificar DSN |
| Dominio | alquimiaplatform.com | ✅ |
| Repo | github.com/romerobarcenabraulio-hash/ALQUIMIA-SLP-- (privado) | ✅ main estable |

**Último deploy de producción exitoso:** commit `b3bcde9` (seed script demo end-to-end).

---

## Features confirmados como SHIPPED (verificados en historial de deploys)

### Plataforma del cliente / hub
- Hub municipal (`/hub`, `/hub/plan-maestro`, `/hub/reporte-esg`)
- Perfil de usuario (`/perfil`) con bridge automático
- Notificaciones (`/notifications`)
- Simulador con persistencia, versionado, comparación de versiones, restauración (Sprints 7-9)
- Generación de reportes HTML/JSON (Sprint 8) — **casero, marcar para upgrade a PDF serio**
- Sistema de ayuda con 6 tópicos (Sprint 8)

### Plataforma 0 / admin (la tabla maestra)
- AdminMasterTable con 12 columnas (Sprint 11)
- Custom hook `useAdminMasterTable` (search, filter, sort, pagination)
- Virtual scrolling para listas grandes (Sprint 14, ~90% menos DOM nodes)
- Multi-select + bulk operations (Sprint 12)
- Bulk export a ZIP (Sprint 12) y bulk document upload (Sprint 13)
- Excel export de la tabla con 15 columnas formateadas (Sprint 11 Phase 2)
- Quick filters (urgentes, vencidos, pendientes) (Sprint 11)
- AdminTenantDrawer con tab de usuarios
- Métricas reales calculadas desde TenantCapability y TenantDocumentDraft (Sprint 10)
- HERMES status calculado desde LogisticsDailySummary
- Audit logging en uploads e invitaciones (compliance)

### Gestión de usuarios y tenants
- Invitación de usuarios al tenant con roles (funcionario, coordinador, director, observer, admin) (Sprint 11, 21)
- Temp password generation, verification status, last login tracking

### Phase D (el bloque grande reciente)
- **Generador registry** (CRUD) con 10 tipos (empresa, hospital, etc.)
- **Decision tree tool** con clasificación sectorial ISIC — 4 árboles (construcción, hospital, comercio, restaurante), preguntas condicionales, estimación de residuos con confidence score
- **Web scrapers reales** (aiohttp + BeautifulSoup): DOF, SEMARNAT, COFEMER, INEGI, ASF con dedup por hash de PDF
- **Scheduler** con retry/backoff, disable tras 3 fallos
- **Residue tracking** por generador con outlier detection (IQR + Z-score), validación de composición, trend analysis, proyecciones
- **Municipal aggregator** (rollups diarios/semanales/mensuales con % completitud)

### Inteligencia
- **Propuesta engine** personalizada por municipio (Sprint 24): población INEGI, perfil de residuos SEMARNAT, empresas DENUE, gap de circularidad, 3 tiers con precio MXN. Preview público sin auth (`/propuesta/public/{nombre}`)
- **NOUS v1** (Sprint 43-45): 6 patrones rule-based (recovery potential, valor económico, compliance, progresión)
- **Partners** (Sprint 46-48): registro recicladoras/compradores ancla SLP ZM, link estatus
- **BANOBRAS evaluación** (Sprint 46-48): 7 criterios ponderados → score 0-100 → 4 niveles de elegibilidad

### Logística
- LogisticsDailySummary (tracking/contabilización) — **es tracking, NO optimización de rutas todavía**

---

## Lo que NO existe (verdad honesta)

| Falta | Notas |
|---|---|
| Optimización de rutas real (VRP) | Solo hay tracking. Falta el solver. (Doc 02 → OR-Tools) |
| Sellos de origen visibles por cifra | La filosofía cero invención no está renderizada en UI todavía |
| Reproducibilidad / provenance de cálculos | Crítico para auditoría, no construido |
| Versionado de metodología | Documentos firmados no son reproducibles con su fórmula histórica |
| FOD IPCC para emisiones | Probablemente factor plano hoy |
| Monte Carlo en financieros | Punto único de TIR/VPN |
| Sankey de flujo de materiales | No existe |
| Mapa de calor georreferenciado | No existe |
| Cola asíncrona de procesamiento de docs | OCR síncrono = riesgo en campaña masiva |
| pgvector / búsqueda semántica | No activado |
| PDF formal de calidad imprenta | Solo HTML report casero |
| LISTENER_ORCHESTRATOR (la entrevista que arma UI) | Conceptualizado en docs Supermind, NO construido |
| Sector Packs como módulos prefabricados | Patrón diseñado, no implementado en Alquimia |
| Voz (ElevenLabs salida / transcripción entrada) | No integrado |
| Pagos / facturación (Stripe/Facturapi/Mifiel) | No construido |
| Encuesta de empresas con consentimiento | Decision-tree existe, falta el wrapper de encuesta + consentimiento |
| Aislamiento de tenants verificado a nivel query | Existe filtrado, falta auditoría/test que lo garantice |
| Rate limiting en endpoints públicos | El preview público está expuesto |
| Aviso de privacidad / términos / cookies | No publicados |
| Backup automático de DB | Verificar en Neon |

---

## Lectura estratégica de este estado

Tienes una columna vertebral real construida por un fundador solo: simulador, admin table de nivel producto, scrapers funcionando, Phase D (generadores + residue tracking + agregación), propuesta engine, NOUS, partners, BANOBRAS. Eso es mucho y es genuino.

Tu exposición no es cantidad de features — es **profundidad defendible**. Los cálculos que un perito de banca o un regidor de oposición auditarán primero (carbono, finanzas, rutas, aislamiento de datos) son los que hay que volver inatacables antes de cobrarle a alguien serio.

El siguiente documento (02) lista exactamente qué instalar para cerrar esos huecos sin reinventar nada.

---

*01 · STATE OF THE SYSTEM · Alquimia · 13 junio 2026*
