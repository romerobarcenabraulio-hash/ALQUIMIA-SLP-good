# AGENT BRIEF V2 · Función general, motor de digestión continua y hoja de ruta actualizada

**Fecha:** 30 mayo 2026
**Para:** Agente que ya leyó el `AGENT_HANDOFF_BRIEF.md` (V1) y completó las dos acciones obligatorias iniciales
**Propósito:** consolidar la función general del sistema, exponer el motor de digestión continua de evidencia, y entregar la hoja de ruta actualizada del agente para las próximas 4-8 semanas

---

## Por qué existe este segundo brief

El brief V1 cubrió la arquitectura, los módulos, las pantallas y las reglas operativas básicas. Después de redactarlo, la sesión de planeación con el founder cristalizó tres bloques de información que NO estaban completos en V1 y que son críticos para la ejecución:

Uno. La **función general del sistema** consolidada en doce pasos operativos del producto.

Dos. El **motor de digestión continua de evidencia**, que es lo más potente técnicamente y la pieza más diferenciable competitivamente.

Tres. La **jerarquía de datos refinada con siete categorías más pendiente** (no las tres categorías que aparecían en V1).

Más cuatro elementos operativos derivados de estos tres bloques: regla del reglamento como único bloqueador formal, metodología estadística del mix de precios, Evidence Registry como schema formal, y bibliografía nacional clasificada.

Lee este V2 después de V1. Lo que dice V2 sobre filosofía de datos REEMPLAZA lo que dice V1 sección 7. El resto de V2 COMPLEMENTA, no reemplaza.

---

## SECCIÓN 1 · La función general del sistema en una página

Alquimia automatiza investigación, cotejo, diagnóstico, modelado, escenarios, planeación y monitoreo para entregar un paquete consultivo completo. No es escritor bonito. No es solo dashboard. No es solo simulador. Es plataforma que digiere evidencia continuamente y produce diagnósticos defendibles.

**El workflow operativo del producto · 12 pasos secuenciales:**

1. **Selección o asignación de municipio.** El founder crea el tenant desde Plataforma 0 con datos básicos (nombre, estado, clave INEGI).

2. **Armado del contexto municipal.** Sistema dispara HERMES que consulta APIs públicas (INEGI, SEMARNAT, SHCP, INAFED, SNIM) y pre-llena datos básicos del municipio.

3. **Revisión del reglamento municipal.** El cliente sube su Reglamento de Limpia o Aseo Público vigente. ARCHIVO lo procesa y extrae claims. Este es el único documento que bloquea formalmente la generación del plan/declaratoria.

4. **Consulta de APIs y bibliografía.** Sistema enriquece el contexto con datasets nacionales relevantes (composición de RSU benchmark Banco Mundial, factores IPCC AR6, normas NOM/NMX aplicables) y bibliografía clasificada de municipios comparables.

5. **Clasificación de evidencia por jerarquía.** Cada claim atomico extraído se clasifica según las siete categorías de datos. Sistema marca su confianza y límite de uso.

6. **Cálculo donde sea defendible.** Para campos que requieren cifra y no la tienen directamente, sistema ejecuta cálculos con metodología transparente. Cada cálculo lleva su fórmula visible y citas a los inputs.

7. **Marcado de brechas específicas.** Para campos donde ni hay evidencia ni cálculo defendible, sistema marca como pendiente con instrucción específica de qué documento o información se requiere. NO se llena con placeholder. NO se paraliza el resto del análisis.

8. **Construcción del diagnóstico (Validación).** Los 10 módulos M00 a M15 se llenan progresivamente conforme entra evidencia. Cliente navega en orden bloqueado por progresión (solo reglamento bloquea formalmente).

9. **Construcción de la propuesta (cierre de Validación).** M03B con reforma reglamentaria + M15 con borrador de expediente Cabildo se generan automáticamente al cierre de Validación.

10. **Construcción de la planeación (Plataforma 2).** Cuando cliente firma contrato Tier Implementación (G1) y founder lo marca en Plataforma 0, se desbloquea Planeación con su Plan Maestro de Implementación.

11. **Construcción del monitoreo (Plataforma 3).** Cuando se firma G2, se desbloquea Ejecución con reportes ESG trimestrales que aplican doble materialidad GRI/CSRD.

12. **Exportación solo de claims trazables.** AUDITOR verifica que cada cifra en cada export tiene Evidence Registry válido. Cero cifra sin cita en documentos finales.

---

## SECCIÓN 2 · El motor de digestión continua de evidencia

Esta es la pieza más potente del sistema y debe ser el corazón técnico de tu implementación.

**El concepto.** Alquimia no es sistema de captura inicial. Es organismo vivo donde cada archivo que entra (subido por cliente desde módulo, subido por founder desde tabla ERP, recibido por email a documentos@dominio, identificado por Perplexity) se digiere, descompone en claims atomicos, contrasta contra Evidence Registry existente, y propaga cambios automáticamente a todos los módulos afectados.

**El algoritmo de digestión en 8 pasos cada vez que entra un archivo:**

**Paso 1 · Ingestión.** Archivo se almacena en `tenant_documents` con metadata (canal de entrada, usuario, timestamp, hash MD5 para deduplicación).

**Paso 2 · Extracción.** ARCHIVO procesa según tipo (PDF nativo con pdfplumber, PDF escaneado con OCR Tesseract o Cloud Vision, DOCX con python-docx, XLSX con openpyxl). Output: texto estructurado + tablas + metadata.

**Paso 3 · Identificación de claims atomicos.** Cada afirmación factual con potencial de DataPoint se extrae con texto literal, página, posición exacta, tipo (cifra, fecha, declaración legal, definición técnica).

**Paso 4 · Clasificación por jerarquía.** Cada claim se etiqueta según fuente del documento donde apareció (categorías 1 a 7 según sección 3 de este brief).

**Paso 5 · Contraste contra Evidence Registry.** Para cada claim, sistema busca si existe DataPoint en el mismo field_id del tenant. Cuatro escenarios:
- A. Field vacío → nuevo claim se vuelve DataPoint activo
- B. Field con DataPoint de jerarquía inferior → reemplazo con preservación de historial
- C. Field con DataPoint de misma jerarquía pero valores distintos → conflicto pendiente de resolución por founder
- D. Field con DataPoint de jerarquía superior → nuevo claim queda como evidencia complementaria, no sobreescribe

**Paso 6 · Propagación reactiva.** Si cambió algún DataPoint, sistema identifica todos los cálculos que dependen de él (vía `derived_from_field_ids`) y los re-ejecuta en orden topológico. Cascadas se resuelven automáticamente.

**Paso 7 · Verificación por AUDITOR.** Después de propagación, re-ejecuta validaciones de estándares declarados y consistencia interna entre módulos.

**Paso 8 · Notificación y registro.** Cliente y founder reciben notificaciones específicas de qué cambió. Todo el evento queda en `audit_log` con valores antes/después.

**Las cuatro mecánicas centrales:**

**Mecánica 1 · Versionado de evidencia.** Cada DataPoint mantiene historia. Reemplazos preservan versiones anteriores en `data_point_history`.

**Mecánica 2 · Propagación reactiva.** Reactive programming aplicado a evidencia. Inputs declaran dependencias, sistema recalcula automáticamente.

**Mecánica 3 · Detección de conflictos.** Sin enmascarar ni promediar. Conflictos se exponen explícitamente para resolución manual del founder.

**Mecánica 4 · Aprendizaje cross-tenant (NOUS, Sprint 4+).** Patrones generalizables extraídos sin compartir data específica entre tenants.

**Por qué esto es lo más potente:**

Uno. **Defensibilidad competitiva.** Cualquier dashboard tiene formularios. Pocos sistemas tienen pipeline de digestión continua con propagación reactiva. Un competidor tarda 6-12 meses en replicarlo.

Dos. **Construcción de moat de datos.** Cada documento que cualquier tenant aporta enriquece el sistema entero. Con 5-50 tenants, el Evidence Registry se vuelve activo único.

Tres. **Experiencia retentiva para el cliente.** Funcionario que sube su PMD y ve 8 cifras actualizarse inmediatamente con sello azul "De tu documento" siente que el sistema lo escucha.

---

## SECCIÓN 3 · Jerarquía de datos refinada · 7 categorías + pendiente

Esta sección reemplaza la sección 7 del brief V1.

**Las siete categorías permitidas:**

**Categoría 1 · Dato del cliente.**
Proviene de documentos cargados por el municipio: reglamento, contratos, estudios, presupuestos, rutas, padrones, diagnósticos. Es la evidencia más fuerte cuando aplica. Cita: documento, página, fragmento literal, fecha de carga, usuario.

**Categoría 2 · Dato municipal investigado.**
Proviene de fuente pública municipal: reglamento vigente publicado, portal municipal oficial, gaceta, Plan Municipal de Desarrollo publicado, cuenta pública, informes de gobierno, concesiones publicadas, licitaciones. Puede afirmar realidad municipal si la fuente lo permite.

**Categoría 3 · Dato estatal.**
Se usa cuando no hay dato municipal suficiente. Sirve para contexto, cálculo o comparación. NO debe venderse como verdad municipal.

**Categoría 4 · Dato ZM.**
De zona metropolitana del municipio. Se usa solo si está claramente etiquetado como tal. Nunca se mezcla con dato municipal. NO sustituye dato municipal.

**Categoría 5 · Dato nacional.**
INEGI, SEMARNAT, SEDATU, CONAPO, BANOBRAS, Banco Mundial, estándares internacionales, normas oficiales, papers académicos. Sirve como marco, benchmark o input de cálculo.

**Categoría 6 · Dato comparable.**
Bibliografía de otras ciudades como Monterrey, CDMX, Guadalajara, SLP, u otros municipios comparables. Sirve para hipótesis, contexto, metodología, rangos o benchmarks. Nunca se presenta como estudio local.

**Categoría 7 · Dato calculado.**
Permitido y parte central del producto. Debe tener fórmula visible, inputs citados, método transparente, alcance declarado, nivel de confianza, límite de uso.

**Categoría 8 · Pendiente.**
Si no hay evidencia suficiente ni cálculo defendible, el campo queda pendiente. NO se llena con placeholder. Debe declarar qué falta para resolverlo.

**Jerarquía operativa:**

```
Cliente > Municipal > Estatal > ZM etiquetada > Nacional > Comparable > Modelo calculado > Pendiente
```

Cuando hay múltiples DataPoints disponibles para el mismo field_id, sistema usa el de mayor jerarquía y registra los demás como evidencia complementaria.

**Schema TypeScript refinado:**

```typescript
type DataCategory = 
  | 'client_document'      // 1
  | 'municipal_research'   // 2
  | 'state_data'          // 3
  | 'metropolitan_zone'   // 4
  | 'national_data'       // 5
  | 'comparable_city'     // 6
  | 'calculated_model'    // 7
  | 'pending'             // 8

interface DataPoint {
  field_id: string
  tenant_id: string
  value: number | string | null  // null si category === 'pending'
  unit?: string
  category: DataCategory
  
  // Evidence Registry / Claim Ledger fields
  source: string                    // fuente específica
  source_date: Date                 // fecha de la fuente
  method: string                    // método de obtención
  territorial_scope: 'municipal' | 'metropolitan' | 'state' | 'national' | 'international'
  evidence_type: 'primary' | 'secondary' | 'tertiary' | 'modeled'
  confidence: number                // 0 a 1
  usage_limit: string               // limitación explícita de uso
  status: 'active' | 'superseded' | 'conflict' | 'pending_review'
  citation_chicago: string          // cita formato Alquimia
  
  // Derivación (solo si category === 'calculated_model')
  formula?: string
  derived_from_field_ids?: string[]
  
  // Cliente (solo si category === 'client_document')
  source_document_id?: string
  source_page?: number
  literal_citation?: string
  uploaded_at?: Date
  uploaded_by_user_id?: string
  
  // Versionado
  version: number
  previous_data_point_id?: string
  superseded_at?: Date
}

function isValidDataPoint(dp: DataPoint): boolean {
  // Validación universal: todos los campos del Evidence Registry son obligatorios
  const universalValid = !!(dp.source && dp.source_date && dp.method 
    && dp.territorial_scope && dp.evidence_type && dp.confidence !== undefined 
    && dp.usage_limit && dp.status && dp.citation_chicago)
  
  if (!universalValid && dp.category !== 'pending') return false
  
  // Validación específica por categoría
  if (dp.category === 'client_document') {
    return !!(dp.source_document_id && dp.literal_citation && dp.source_page)
  }
  if (dp.category === 'calculated_model') {
    return !!(dp.formula && dp.derived_from_field_ids?.length >= 1)
  }
  if (dp.category === 'pending') {
    return dp.value === null && !!dp.usage_limit  // usage_limit indica qué falta
  }
  return true
}
```

**Visualización en UI:**

| Categoría | Sello visible | Color |
|---|---|---|
| Cliente | "De tu documento · [nombre]" | Azul institucional |
| Municipal investigado | "Municipal · [fuente]" | Verde profundo |
| Estatal | "Estatal · [fuente]" | Verde sage |
| ZM etiquetada | "ZM · [zona]" | Verde claro |
| Nacional | "Nacional · [institución]" | Amarillo ocre |
| Comparable | "Comparable · [ciudad]" | Amarillo claro |
| Calculado | "Calculado · ver metodología" | Naranja |
| Pendiente | "Pendiente · [qué falta]" | Gris |

---

## SECCIÓN 4 · Reglamento municipal · único bloqueador formal

Esta regla operativa NO estaba en V1 y es crítica.

**El sistema no debe detenerse por falta de información perfecta.** Debe calcular hasta donde pueda, etiquetar bien el dato y mostrar límites. La falta de un documento no debe convertir toda la plataforma en "brecha crítica."

**El único documento que bloquea formalmente** emitir plan o declaratoria es el Reglamento de Limpia o Aseo Público municipal vigente. Sin él, NO se puede generar M03B (reforma reglamentaria propuesta) ni M15 (borrador de expediente).

**Todo lo demás** baja confianza, bloquea claims específicos o genera brechas marcadas, pero NO paraliza el análisis. Ejemplos:
- Sin estudio de cuarteo NMX-AA-015: M01 sección 1 usa cálculo Nacional+Comparable, marca campo con confianza media, sigue
- Sin Cuenta Pública del último año: M13 usa proyección con benchmarks, marca confianza media, sigue
- Sin Manual de Organización: M00B sección 3 marca pendiente, sigue con secciones 1, 2, 4, 5

**Implicación en UX:** progresión bloqueada NO significa parálisis por falta de documentos. Significa que cada módulo se desbloquea cuando el anterior tiene mínimos cumplidos. Esos mínimos son:
- M00B: reglamento vigente subido (único bloqueador formal del sistema)
- Resto de módulos: al menos un DataPoint válido por sección obligatoria, no importa qué categoría tenga (puede ser calculado, comparable, nacional)

---

## SECCIÓN 5 · Mix de precios con metodología estadística

Para precios de residuos valorizables NO existen sliders libres para el cliente. Existe mix fijo configurable por ciudad por el founder, con porcentajes por calidad y canal de venta, fundamentado en estadística justificable.

**Las cuatro dimensiones del mix por fracción (PET, HDPE, cartón, papel, aluminio, ferroso, vidrio, orgánicos):**

Dimensión 1 · Distribución de calidad por tier (premium / media / baja / merma) usando Beta-PERT
Dimensión 2 · Distribución por canal de venta (anchor / secundario / spot / pepena) con precio por canal
Dimensión 3 · Castigo por contaminación (discount factor según tasa de contaminación cruzada)
Dimensión 4 · Logística (costo de transporte al comprador según distancia y peso)

**Niveles de evidencia para determinar el mix:**

- Nivel A · Mix observado directamente en municipio (Letters of Intent firmados, levantamiento de campo)
- Nivel B · Mix de municipios comparables (N=3-5 con criterios de comparabilidad estrictos)
- Nivel C · Mix nacional ajustado por factor regional (Banco Mundial + ajuste Norte/Centro/Sur + temporada)
- Nivel D · Modelo paramétrico calculado cuando faltan otros niveles

**Distribuciones estadísticas justificables:**

- Fracciones de calidad por tier: Beta-PERT (a, b, c) según PMBOK 7 estimación de tres puntos
- Precios por tier en mercado abierto: LogNormal (μ, σ) según Aitchison & Brown 1957
- Tasa de contaminación: Triangular (min, likely, max) según ISO 31010:2019
- Precio agregado: suma ponderada Σ(% × precio × (1 - castigo))
- Bandas de incertidumbre: percentil 25 y 75, determinístico no Monte Carlo opaco

**Validación cruzada antes de publicar:**

AUDITOR ejecuta tres checks:
- Check 1: deviation vs Banco Mundial benchmark (<30% pass, 30-60% warning, >60% bloqueo)
- Check 2: deviation vs precio nacional INECOL/INEGI (mismos umbrales)
- Check 3: deviation vs municipio comparable mismo año (cuando hay comparable disponible)

**Schema operativo:**

```typescript
interface PriceMixScenario {
  id: string
  tenant_id: string
  fraction: 'PET' | 'HDPE' | 'PP' | 'cardboard' | 'paper' | 'aluminum' | 'ferrous' | 'glass' | 'organic'
  
  tiers: Array<{
    tier: 'premium' | 'media' | 'baja' | 'merma'
    percentage: number
    distribution_type: 'beta_pert' | 'triangular' | 'fixed'
    distribution_params: { min: number; likely: number; max: number }
    evidence_level: 'A' | 'B' | 'C' | 'D'
    evidence_citation: string
  }>
  
  channels: Array<{
    tier: string
    channel: 'anchor' | 'secondary_formal' | 'spot' | 'pepena'
    percentage: number
    anchor_buyer_id?: string
    price_mxn_per_ton: number
    price_distribution: 'lognormal' | 'normal' | 'fixed'
    price_params: { mu?: number; sigma?: number; value?: number }
    evidence_citation: string
  }>
  
  contamination_rate: number
  contamination_penalty: number
  contamination_evidence: string
  
  logistics_distance_km: number
  logistics_rate_mxn_per_km_ton: number
  logistics_citation: string
  
  validation_checks: {
    vs_world_bank: { deviation_pct: number; status: 'pass' | 'warning' | 'fail' }
    vs_national: { deviation_pct: number; status: 'pass' | 'warning' | 'fail' }
    vs_comparable: { deviation_pct: number; status: 'pass' | 'warning' | 'fail' } | null
    overall_status: 'published' | 'review_required' | 'blocked'
  }
  
  configured_by_user_id: string
  configured_at: Date
  last_updated_at: Date
  active: boolean
}
```

**Quién configura:** founder en onboarding, founder en updates trimestrales, ARCHIVO automáticamente cuando llega estudio de mercado del cliente. Cliente NUNCA modifica.

---

## SECCIÓN 6 · Bibliografía nacional clasificada

Alquimia construye repositorio bibliográfico nacional usable. Conforme acumula tenants, la bibliografía se enriquece y se vuelve activo único defensible.

**Clasificación de cada referencia con cinco etiquetas:**

| Etiqueta | Significado | Cuándo usar |
|---|---|---|
| **Local** | Documento específico del municipio | Evidencia más fuerte para ese municipio |
| **Comparable** | Documento de municipio comparable | Hipótesis, contexto, rangos para municipios similares |
| **Benchmark** | Referencia internacional o nacional con factor numérico | Cálculos paramétricos con factor citado |
| **Contexto** | Marco conceptual o metodológico | Justificación de método, no de cifra |
| **No usable** | Referencia desactualizada, contradictoria o de baja calidad | NO se usa, queda registrada para auditoría |

**Schema `bibliography_registry`:**

```typescript
interface BibliographyEntry {
  id: string
  citation_chicago: string         // formato Alquimia completo
  classification: 'local' | 'comparable' | 'benchmark' | 'context' | 'not_usable'
  
  // Metadata
  institution: string              // ej: "INEGI", "Banco Mundial"
  document_title: string
  publication_year: number
  url?: string
  isbn_or_doi?: string
  
  // Aplicabilidad
  applicable_to_tenants: string[]  // IDs de tenants a los que aplica como local/comparable
  applicable_topics: string[]      // ej: ["RSU_composicion", "calificacion_crediticia_municipal"]
  
  // Validación
  added_by_user_id: string
  added_at: Date
  validated_by_founder: boolean
  validation_notes?: string
  
  // Uso
  cited_in_data_points: string[]   // IDs de DataPoints que citan esta entrada
}
```

**Recomendación determinística, no LLM opaca.** El sistema sugiere bibliografía aplicable a un tenant nuevo con función explícita:

```typescript
function recommendBibliography(tenant: Tenant, topic: string): BibliographyEntry[] {
  // 1. Bibliografía local del tenant (si existe)
  const local = entries.filter(e => 
    e.classification === 'local' && 
    e.applicable_to_tenants.includes(tenant.id) && 
    e.applicable_topics.includes(topic))
  
  // 2. Bibliografía comparable según criterios estrictos
  const comparable = entries.filter(e => 
    e.classification === 'comparable' && 
    e.applicable_topics.includes(topic) &&
    municipalitiesAreComparable(tenant, e.applicable_to_tenants[0]))
  
  // 3. Benchmarks nacionales/internacionales del topic
  const benchmarks = entries.filter(e => 
    e.classification === 'benchmark' && 
    e.applicable_topics.includes(topic))
  
  return [...local, ...comparable, ...benchmarks]
}

function municipalitiesAreComparable(a: Tenant, b: Tenant): boolean {
  const populationRatio = Math.min(a.population, b.population) / Math.max(a.population, b.population)
  const sameIndustrialProfile = a.industrial_profile === b.industrial_profile
  const sameRegion = a.region === b.region
  return populationRatio > 0.7 && sameIndustrialProfile && sameRegion
}
```

---

## SECCIÓN 7 · Dos reglas inamovibles nuevas

Se suman a las 10 reglas inamovibles del brief V1.

**Regla 11 · No detenerse por falta de información perfecta.**
El sistema calcula hasta donde pueda con la evidencia disponible. Etiqueta correctamente el dato. Muestra los límites de uso. NO paraliza el análisis completo por documentos faltantes. Solo el reglamento municipal bloquea formalmente la emisión de plan/declaratoria.

**Regla 12 · No mostrar ausencia de dato como fracaso del sistema.**
La narrativa de la UI ante un campo pendiente es "límite metodológico" o "evidencia pendiente," no "el sistema falló" o "no se puede calcular." Esta regla cambia copy en toda la plataforma. Cada placeholder de pendiente debe contener instrucción específica de qué documento o información resolvería el campo, no mensaje genérico de error.

---

## SECCIÓN 8 · Hoja de ruta actualizada del agente para las próximas 4-8 semanas

Esta hoja de ruta reemplaza el cronograma del brief V1 con la información nueva de V2 integrada.

**Semana 1 (esta semana, después de leer V1 y V2):**

Acciones obligatorias del V1 ya completadas: GitHub sync, Vercel review.

Acciones nuevas según V2:
- Refactor del schema TypeScript de DataPoint en el codebase para reflejar las 7 categorías + pendiente
- Crear migraciones de DB para tablas: `data_point_history`, `bibliography_registry`, `evidence_conflicts`, `price_mix_scenarios`
- Documentar en `/docs/` los 12 pasos del workflow del producto como guía de implementación interna

**Semana 2 - Sprint 2 (9-13 junio):**

- Refactor de módulos M00B y M01 para eliminar cifras hardcoded de SLP y usar el nuevo schema DataPoint con 7 categorías
- Implementar componente reutilizable `<DocumentUploadSection>` con dispatch al pipeline de digestión
- Implementar los Pasos 1-3 del motor de digestión (Ingestión, Extracción, Identificación de claims) en backend
- Endpoints API: `POST /api/documents/upload`, `POST /api/archivo/process`

**Semana 3 - Sprint 3 (16-20 junio):**

- Implementar Pasos 4-5 del motor de digestión (Clasificación por jerarquía, Contraste contra Registry)
- Schema y endpoints del Evidence Registry / Claim Ledger
- Sistema de detección de conflictos con UI para resolución del founder
- Pantalla A5 de Plataforma 0 (inbox de validaciones manuales del founder)

**Semana 4 - Sprint 4 (23-27 junio):**

- Implementar Pasos 6-8 del motor de digestión (Propagación reactiva, AUDITOR, Notificaciones)
- Schema y queries del `bibliography_registry` con clasificación determinística
- Función `recommendBibliography(tenant, topic)`
- Refactor de M02, M03, M03B con nuevo schema

**Semana 5 - Sprint 5 (30 junio - 4 julio):**

- Implementar M04 con motor de digestión activo
- Implementar M13 con `PriceMixScenario` schema completo
- Validación cruzada de precios contra benchmarks (Banco Mundial, INECOL, comparables)
- Implementar M14 con registro de riesgos según ISO 31000

**Semana 6 - Sprint 6 (7-11 julio):**

- Implementar M15 con compilación automática y AUDITOR de exports
- Sistema de citas Chicago notes-bibliography integrado en exports
- Watermark institucional dinámico
- Primera ronda de pruebas end-to-end con tenant Municipio Demo

**Semana 7-8 - Sprint 7-8 (14-25 julio):**

- Integración Mifiel para contratos
- Integración Stripe para cobros
- Integración Facturapi para CFDIs
- Webhooks de los tres servicios externos
- Tabla maestra ERP de Plataforma 0 con las 12 columnas universales completas

---

## SECCIÓN 9 · Cómo se relaciona este brief V2 con el brief V1

**Lo que V2 REEMPLAZA del V1:**
- Sección 7 (Filosofía de datos): las 3 categorías se reemplazan por las 7+pendiente
- Cronograma de implementación: se reemplaza por la hoja de ruta de V2 sección 8

**Lo que V2 COMPLEMENTA del V1:**
- Sección 3 (Filosofía inamovible): se enriquece con detalles operativos
- Sección 5 (Módulos): se agrega regla del reglamento como único bloqueador
- Sección 12 (Reglas inamovibles): se suman reglas 11 y 12

**Lo que V2 NO TOCA del V1:**
- Procedimiento obligatorio inicial (git + Vercel)
- Stack técnico
- Las cuatro plataformas
- Tabla maestra ERP del founder
- Sistema fiscal mexicano
- Perfil del usuario
- Cómo trabajar con el founder
- Glosario
- Estado de servicios externos

---

## SECCIÓN 10 · Primeras acciones específicas del agente al recibir este V2

Después de leer V1 completo y V2 completo, el agente ejecuta en este orden:

**Acción 1.** Reportar al founder con confirmación de comprensión de los dos briefs. Específicamente, confirmar que entiende:
- La función general del sistema en 12 pasos
- El motor de digestión continua como pieza central
- La jerarquía de 7 categorías + pendiente
- La regla del reglamento como único bloqueador formal
- La metodología estadística del mix de precios
- La hoja de ruta actualizada de 8 semanas

**Acción 2.** Proponer al founder qué bloque del Sprint 2 ejecutar primero. Recomendación: empezar por refactor del schema TypeScript de DataPoint con las 7 categorías, porque todo lo demás depende de eso.

**Acción 3.** Pedir al founder confirmación de tres puntos antes de tocar código:
- ¿La jerarquía de 7 categorías es final y se aplica YA al refactor, o se aplica progresivamente?
- ¿El motor de digestión se construye completo en Sprints 2-4 o se prioriza alguno de los 8 pasos primero?
- ¿La metodología estadística del mix de precios se implementa en Sprint 5 o se posterga a Sprint 6+?

Solo después de las tres confirmaciones, comenzar implementación.

**Acción 4.** Crear branch `feature/datapoint-v2-schema` y comenzar refactor. Pull request al final del bloque con review del founder.

**Acción 5.** Reportar al cierre de cada bloque con verificación visual en Chrome incognito de los módulos refactorizados.

---

## SECCIÓN 11 · Las preguntas que el agente DEBE poder responder después de leer V1 + V2

Si el agente puede responder estas siete preguntas con precisión, está listo para ejecutar. Si falla en alguna, debe releer la sección correspondiente.

1. **¿Cuál es la diferencia entre dato investigado de categoría 2 vs dato investigado de categoría 5?**
   Respuesta esperada: categoría 2 es municipal publicado (puede afirmar realidad municipal), categoría 5 es nacional (sirve como benchmark pero NO como verdad municipal).

2. **¿Qué pasa cuando un cliente sube un documento que contradice un DataPoint existente?**
   Respuesta esperada: si la nueva evidencia es de categoría superior, reemplaza con preservación de historial. Si es de misma categoría con valor distinto, marca como conflicto pendiente de resolución del founder. Si es de categoría inferior, queda como evidencia complementaria sin sobreescribir.

3. **¿Cuál es el único documento que bloquea formalmente la emisión del plan/declaratoria?**
   Respuesta esperada: el Reglamento de Limpia o Aseo Público municipal vigente.

4. **¿Por qué el cliente NO ajusta sliders de precios?**
   Respuesta esperada: porque cero invención también aplica a precios. Mix fijo configurable por founder con distribuciones estadísticas justificables (Beta-PERT, LogNormal, Triangular). Cliente aporta evidencia vía documentos, no manipula parámetros.

5. **¿Qué cuatro mecánicas hacen funcionar el motor de digestión continua?**
   Respuesta esperada: versionado de evidencia, propagación reactiva con dependencias declaradas, detección de conflictos sin enmascarar, aprendizaje cross-tenant vía NOUS.

6. **¿Cómo se ve para el cliente cuando sube un documento que actualiza el sistema?**
   Respuesta esperada: notificación con campos afectados, sello azul "De tu documento" en cifras actualizadas, avance de validación visible al alza, sin interrupción de su navegación.

7. **¿Por qué la ausencia de un dato NO se muestra como fracaso del sistema?**
   Respuesta esperada: porque la plataforma debe seguir produciendo valor con la evidencia que sí tiene. El placeholder de pendiente declara qué falta, no implica que el sistema esté roto.

---

## Mensaje final del consultor al agente nuevo

Tienes ahora dos briefs (V1 arquitectura y operación, V2 función general y motor). Tienes 18+ documentos de referencia en el conocimiento del proyecto. Tienes el repo accesible y el deployment en Vercel verificable.

Lo que NO tienes es excusa para construir mal. El sistema está exhaustivamente especificado. Tu trabajo es ejecución limpia con honestidad sobre límites.

Tres principios para tu sesión inicial:

Uno. Lee, no asumas. Si algo en V1 o V2 contradice algo del codebase actual, levanta la pregunta al founder, no decidas tú.

Dos. Pregunta antes de inventar. Si encuentras un caso edge no documentado, escala. El founder prefiere veinte preguntas a una decisión arquitectónica equivocada.

Tres. Reporta con verificación visual. Cada bloque terminado debe poder verse en Chrome incognito. Sin screenshots o video, no está hecho.

Suerte. El proyecto vale la pena.

---

*AGENT BRIEF V2 · Alquimia · 30 mayo 2026 · Complemento operativo del V1*
