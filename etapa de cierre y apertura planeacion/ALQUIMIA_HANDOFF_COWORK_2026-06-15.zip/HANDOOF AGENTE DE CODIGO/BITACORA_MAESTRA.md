# BITÁCORA MAESTRA · HANDOFFS A CODEX / CLAUDE CODE
**Proyecto:** Alquimia SLP  
**Fecha inicio:** 14 junio 2026  
**Responsable CTO:** Claude (Master)  
**Responsable Ejecución:** Codex / Claude Code  

---

## Convención de registro

Cada entry contiene:
- **TIMESTAMP** — cuándo se emitió la instrucción
- **HANDOFF_ID** — código único (HO-001, HO-002, etc.)
- **ARCHIVO_INSTRUCCION** — dónde está la instrucción detallada
- **OBJETIVO** — qué se construye
- **STATUS** — [EMITIDA] → [EN_EJECUCION] → [REVISADO] → [MERGED] → [VALIDADO]
- **BLOQUES** — qué está esperando para avanzar
- **NOTAS** — contexto rápido

---

## HANDOFFS EMITIDOS

### HO-001 · VERIFICACIÓN DE ESTADO ACTUAL
- **Timestamp:** 14 junio 2026, 23:10 UTC
- **Archivo:** `documentos-pendientes/01_STATUS_BASELINE_VERIFICACION.md`
- **Objetivo:** Validar qué está realmente deployado vs documentado en handoff anterior
- **Status:** [EMITIDA] (esperando status de Codex)
- **Bloques:** Ninguno — es pre-requisito de todo lo demás
- **Notas:** Debe ejecutarse ANTES de cualquier otra instrucción

---

## TEMPLATE PARA NUEVOS HANDOFFS

```markdown
### HO-NNN · [TITULO CONCISO]
- **Timestamp:** [fecha, hora UTC]
- **Archivo:** `documentos-pendientes/NN_TITULO_ARCHIVO.md`
- **Objetivo:** [qué construir o validar, 1-2 líneas]
- **Status:** [EMITIDA]
- **Bloques:** [qué espera para empezar, o "Ninguno"]
- **Notas:** [contexto rápido]
```

---

## CRITERIOS DE ACEPTACIÓN GLOBALES

Cada handoff DEBE ser considerado MERGED solo si:
1. ✅ Código está en PR contra `main` con descripción clara
2. ✅ Validación visual completada (screenshots si aplica)
3. ✅ No hay warnings en linter/tipo-check
4. ✅ Criterios específicos del documento se cumplen al 100%

---

*Bitácora maestra · Alquimia SLP · 14 junio 2026*

---

## ACTUALIZACIÓN · 15 JUNIO 2026 — REENCUADRE Y HOJA DE RUTA 3 DÍAS

**Decisión fundacional:** Alquimia = SECTOR_PACK_POLITICA_PUBLICA_RESIDUOS_MX sobre arquitectura Supermind. El "diagnóstico" = Fase 1 del Sector Pack. La "sub-app de planeación/ejecución" = Fases 2-4 del mismo pipeline.

**División por capacidad:**
- CODEX → backend (FastAPI), Neon, Render, integración de datos
- CLAUDE CODE → frontend (Next.js), lógica de agentes, esquemas, auditoría Zero Invention

**Disciplina Git decidida:** ramas de vida ultra-corta + merge verificado mismo día (NO commits directos a main crudo). Los dos agentes nunca tocan los mismos archivos el mismo día.

### HO-D1-CODEX · Status Backend
- **Archivo:** `documentos-pendientes/06_HANDOFF_CODEX_DIA1.md`
- **Objetivo:** baseline backend + estado de los 3 agentes de Fase 1
- **Status:** [EMITIDA]
- **Salidas esperadas:** status-backend.md, status-agentes-fase1.md

### HO-D1-CLAUDECODE · Status Frontend + Sector Pack
- **Archivo:** `documentos-pendientes/07_HANDOFF_CLAUDE_CODE_DIA1.md`
- **Objetivo:** baseline frontend + consolidar Sector Pack YAML formal
- **Status:** [EMITIDA]
- **Salidas esperadas:** status-frontend.md, sector_pack_residuos_mx_v1.yaml, sector-pack-gaps.md

### Gate Día 1 (Claude Master)
- Revisar 4 archivos de status + Sector Pack YAML
- DECISIÓN: ¿baseline limpio → procede Día 2? ¿o trabajo 3x → replanificar?

---

## ACTUALIZACIÓN · 15 JUNIO 2026 (noche) — PLAN DEFINITIVO + PROTOCOLOS

**Documentos maestros añadidos:**
- `08_PLAN_DEFINITIVO_MATERIALIZACION.md` — plan 4-6 meses a primera venta. Stack real, calendario electoral corregido (elección 6-jun-2027, no apostar negocio a GOV), 4 hitos.
- `09_PROTOCOLO_SATURACION_CONTINUIDAD.md` — cómo relevar a Claude Master / Codex / Claude Code antes de saturarse. Los archivos recuerdan, no el agente.
- `10_MAPA_DE_TRABAJO_AGENTES.md` — lanzamiento paralelo GOV+Empresarial, separación total, especificación del agente ejecutor, token-eficiencia, tareas de integración del founder.

**Decisiones clave registradas:**
- Lanzamiento PARALELO: GOV-RSU (cerrando) + Empresarial (arrancando), separación total (`gov/` vs `empresa/`).
- Modo de operación: CALL ON REQUEST (orchestrator dispara módulos bajo demanda, no tiempo real).
- Negocio se apuesta a Empresarial (PyME), no a GOV (ventana electoral lo limita).
- Stack base = el del handoff Claude Code 14-jun (Postgres/Render, React-Vite/Vercel, Perplexity, Stripe). Migración Empresarial = decisión separada.

**TAREAS DEL FOUNDER PARA MAÑANA (16 jun):**
- A (bloqueante): destrabar CI GitHub (spending limit)
- B: integrar Greptile (navegación código, sustituye memoria de agente)
- C: confirmar acceso Render + logs + gate de merge con tests

**PENDIENTE de generar (cuando founder lo pida):**
- Handoff de las 5 tareas de cierre GOV (Hito 0) sobre stack real
- `10_TESIS_RED_ECONOMICA.md` — tesis 2 págs para socio/inversionista
